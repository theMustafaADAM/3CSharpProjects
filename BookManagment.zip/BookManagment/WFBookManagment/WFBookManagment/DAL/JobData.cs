﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFBookManagment.DAL
{
    public class clsJobData
    {
        public static bool GetJobByID(int jobid, ref int depID, ref string jobname)
        {
            bool isFound = false;
            string cs = clsDataAccess.getConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(cs))
                {
                    connection.Open();
                    string query = @"SELECT TbJobs.jobID as 'ت', TbJobs.depID,TbDepartments.depName as 'القسم', 
	                                TbJobs.jobName as 'الوظيفة' FROM TbJobs INNER JOIN TbDepartments 
	                                ON TbJobs.depID = TbDepartments.depID 
	                                WHERE TbJobs.jobID =@id ORDER BY TbJobs.jobName";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@id", jobid);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read()) isFound = false;
                            else
                            {
                                isFound = true;
                                jobname = Convert.ToString(reader["القسم"]);
                                depID = Convert.ToInt16(reader["depID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string SourceName = "WFLibrary_System", SourceTitle = "Application";
                if (!EventLog.SourceExists(SourceName))
                    EventLog.CreateEventSource(SourceName, SourceTitle);

                EventLog.WriteEntry(SourceName, $"Error : {ex.Message}", EventLogEntryType.Error);
                isFound = false;
            }

            return isFound;
        }

        public static bool GetJobByName(ref int jobid, ref int depid, string jobname)
        {
            bool isFound = false;
            string cs = clsDataAccess.getConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(cs))
                {
                    connection.Open();
                    string query = @"SELECT TbJobs.jobID as 'ت', TbJobs.depID, TbDepartments.depName as 'القسم', 
	                                TbJobs.jobName as 'الوظيفة' FROM TbJobs INNER JOIN TbDepartments 
	                                ON TbJobs.depID = TbDepartments.depID 
	                                WHERE TbJobs.jobName =@jn ORDER BY TbJobs.jobName";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@jn", jobname);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read()) isFound = false;
                            else
                            {
                                isFound = true;
                                jobid = Convert.ToInt16(reader["ت"]);
                                depid = Convert.ToInt16(reader["depID"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string SourceName = "WFLibrary_System", SourceTitle = "Application";
                if (!EventLog.SourceExists(SourceName))
                    EventLog.CreateEventSource(SourceName, SourceTitle);

                EventLog.WriteEntry(SourceName, $"Error : {ex.Message}", EventLogEntryType.Error);
                isFound = false;
            }

            return isFound;
        }
    }
}
