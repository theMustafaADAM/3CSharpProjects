﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFBookManagment.DAL
{
    public class clsDepartmentData
    {

        public static bool GetDepartmentByID(int id, ref string depname)
        {
            bool isFound = false;
            string cs = clsDataAccess.getConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(cs))
                {
                    connection.Open();
                    string query = @"SELECT TbDepartments.depID as 'ت',
	                                    TbDepartments.depName as 'القسم' 
	                                    FROM TbDepartments WHERE depID =@id 
                                        ORDER BY depName";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("%" + "@id" + "%", id);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read()) isFound = false;
                            else
                            {
                                isFound = true;
                                depname = Convert.ToString(reader["القسم"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string SourceName = "WFLibrary_System", SourceTitle = "Application";
                if (!EventLog.SourceExists(SourceName))
                    EventLog.CreateEventSource(SourceName, SourceTitle);

                EventLog.WriteEntry(SourceName, $"Error : {ex.Message}", EventLogEntryType.Error);
                isFound = false;
            }

            return isFound;
        }

        public static bool GetDepartmentByName(ref int depid, string depname)
        {
            bool isFound = false;
            string cs = clsDataAccess.getConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(cs))
                {
                    connection.Open();
                    string query = @"SELECT TbDepartments.depID as 'ت',
	                                    TbDepartments.depName as 'القسم' 
	                                    FROM TbDepartments WHERE depName Like '%' + @dn + '%' 
                                        ORDER BY depName";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@dn", depname);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read()) isFound = false;
                            else
                            {
                                isFound = true;
                                depid = Convert.ToInt16(reader["ت"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string SourceName = "WFLibrary_System", SourceTitle = "Application";
                if (!EventLog.SourceExists(SourceName))
                    EventLog.CreateEventSource(SourceName, SourceTitle);

                EventLog.WriteEntry(SourceName, $"Error : {ex.Message}", EventLogEntryType.Error);
                isFound = false;
            }

            return isFound;
        }
    }
}
