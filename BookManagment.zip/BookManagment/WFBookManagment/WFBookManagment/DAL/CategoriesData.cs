﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.BLL;

namespace WFBookManagment.DAL
{
    public class clsCategoriesData
    {
        public static bool GetCategoryByID(int catID, ref string category)
        {
            bool isFound = false;
            string cs = clsDataAccess.getConnectionString();
            try
            {
                using (SqlConnection connection = new SqlConnection(cs))
                {
                    connection.Open();

                    string query = "SELECT * FROM TbCategories WHERE Id LIKE @id";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("%" + "@id" + "%", catID);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {

                            if (!reader.Read()) isFound = false;
                            else
                            {
                                isFound = true;
                                category = Convert.ToString(reader["Category"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string SourceName = "WFLibrary_System", SourceTitle = "Application";
                if (!EventLog.SourceExists(SourceName))
                    EventLog.CreateEventSource(SourceName, SourceTitle);

                EventLog.WriteEntry(SourceName, $"Error : {ex.Message}", EventLogEntryType.Error);
                isFound = false;
            }

            return isFound;
        }
    }
}
