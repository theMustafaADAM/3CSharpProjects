﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WFBookManagment.DAL
{
    public class clsDataAccess
    {
        static SqlConnection conn = new SqlConnection();

        public clsDataAccess()
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;
            AttachDbFilename=|DataDirectory|\DBLibrary.mdf;
            Integrated Security=True";
            conn = new SqlConnection(connectionString);
        }

        public static void Open()
        {
            if (conn.State == ConnectionState.Closed) conn.Open();
        }

        public static void Close()
        {
            if (conn.State == ConnectionState.Open) conn.Close();
        }



        // To Get Data as DataTable
        public static DataTable ReadData(String strore, SqlParameter[] pr)
        {
            /*
            // Get Command
            SqlCommand command = new SqlCommand();

            // Get Command Connection and Open Connection
            command.Connection = conn; Open();

            // Get Command Type = Stored Procedure
            command.CommandType = CommandType.StoredProcedure;

            // Get Command Text as String Store
            command.CommandText = strore;

            // Get Parameters
            if (pr != null) command.Parameters.AddRange(pr);

            // Get Data Adapter with Command
            SqlDataAdapter adapter = new SqlDataAdapter(command);

            // Get Data Table & Fill it with adapter
            DataTable data = new DataTable();
            adapter.Fill(data);

            // Close Connection
            Close();

            // Return The Data Table
            return data;*/

            using (var cnn = new SqlConnection(conn.ConnectionString))
            {
                using (var commnd = new SqlCommand(strore, cnn))
                {
                    commnd.CommandType = CommandType.StoredProcedure;

                    if (pr != null) commnd.Parameters.AddRange(pr);

                    using (var adpter = new SqlDataAdapter(commnd))
                    {
                        using (var dt = new DataTable())
                        {
                            adpter.Fill(dt);
                            return dt;
                        }
                    }

                }
            }
        }

        // Send Execute (Insert, Update, Delete)
        public static Boolean ExecuteNonQuery(String strore, SqlParameter[] pr)
        {
            /*
            // Get Command
            SqlCommand command = new SqlCommand();

            // Get Command Connection and Open
            command.Connection = conn; Open();

            // Get Command Type = Stored Procedure
            command.CommandType = CommandType.StoredProcedure;

            // Get Command Text as String Store
            command.CommandText = strore;

            // Get Parameters
            if (pr != null) command.Parameters.AddRange(pr);

            // to Execute if return rows affected > 0
            if (command.ExecuteNonQuery() > 0)
            {
                Close();
                //return true;
            }
            Close();
            //return false;*/

            using (var cnn = new SqlConnection(conn.ConnectionString))
            {
                using (var commnd = new SqlCommand(strore, cnn))
                {
                    cnn.Open();
                    
                    commnd.CommandType = CommandType.StoredProcedure;

                    if (pr != null) commnd.Parameters.AddRange(pr);

                    if (commnd.ExecuteNonQuery() > 0) return true;

                    else return false;
                }
            }
        }

        public static string getConnectionString()
        {
            return conn.ConnectionString;
        }

        public static bool EmailCheck(string email)
        {
            // returns true if the input is a valid email
            return Regex.IsMatch(email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }
    }
}
