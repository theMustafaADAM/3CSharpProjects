﻿namespace WFBookManagment.PRL
{
    partial class formMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formMain));
            this.panelSideBar = new System.Windows.Forms.Panel();
            this.labelPermission = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.buttonSideBarCategory = new System.Windows.Forms.Button();
            this.pBuImage = new System.Windows.Forms.PictureBox();
            this.buttonSideBarUsers = new System.Windows.Forms.Button();
            this.buttonSideBarBarrow = new System.Windows.Forms.Button();
            this.buttonCallaps = new System.Windows.Forms.Button();
            this.buttonSideBarSales = new System.Windows.Forms.Button();
            this.buttonSideBarStudents = new System.Windows.Forms.Button();
            this.buttonSideBarBooks = new System.Windows.Forms.Button();
            this.buttonSideBarHome = new System.Windows.Forms.Button();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.labelMainState = new System.Windows.Forms.Label();
            this.buttonLock = new System.Windows.Forms.Button();
            this.buttonInfo = new System.Windows.Forms.Button();
            this.buttonMinimize = new System.Windows.Forms.Button();
            this.buttonMaximize = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.dataGridViewMain = new System.Windows.Forms.DataGridView();
            this.panelMainBottom = new System.Windows.Forms.Panel();
            this.buttonMainDetails = new System.Windows.Forms.Button();
            this.buttonMainDelete = new System.Windows.Forms.Button();
            this.buttonMainUpdate = new System.Windows.Forms.Button();
            this.buttonMainAdd = new System.Windows.Forms.Button();
            this.panelMainTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxFind = new System.Windows.Forms.TextBox();
            this.panelContainer = new System.Windows.Forms.Panel();
            this.panelHome = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.buttonAddUser = new System.Windows.Forms.Button();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.buttonAddBorrow = new System.Windows.Forms.Button();
            this.buttonAddSale = new System.Windows.Forms.Button();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.buttonAddBook = new System.Windows.Forms.Button();
            this.panelUserPox = new System.Windows.Forms.Panel();
            this.labelCountUsers = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panelBorrowsPox = new System.Windows.Forms.Panel();
            this.labelCountBorrows = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelCategoriesPox = new System.Windows.Forms.Panel();
            this.labelCountCategories = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panelStudentsPox = new System.Windows.Forms.Panel();
            this.labelCountStudents = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panelSalesPox = new System.Windows.Forms.Panel();
            this.labelCountSales = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panelBooksPox = new System.Windows.Forms.Panel();
            this.labelCountBooks = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonReports = new System.Windows.Forms.Button();
            this.panelSideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBuImage)).BeginInit();
            this.panelTitleBar.SuspendLayout();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).BeginInit();
            this.panelMainBottom.SuspendLayout();
            this.panelMainTop.SuspendLayout();
            this.panelContainer.SuspendLayout();
            this.panelHome.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelUserPox.SuspendLayout();
            this.panelBorrowsPox.SuspendLayout();
            this.panelCategoriesPox.SuspendLayout();
            this.panelStudentsPox.SuspendLayout();
            this.panelSalesPox.SuspendLayout();
            this.panelBooksPox.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideBar
            // 
            this.panelSideBar.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelSideBar.Controls.Add(this.labelPermission);
            this.panelSideBar.Controls.Add(this.labelUsername);
            this.panelSideBar.Controls.Add(this.buttonSideBarCategory);
            this.panelSideBar.Controls.Add(this.pBuImage);
            this.panelSideBar.Controls.Add(this.buttonSideBarUsers);
            this.panelSideBar.Controls.Add(this.buttonSideBarBarrow);
            this.panelSideBar.Controls.Add(this.buttonCallaps);
            this.panelSideBar.Controls.Add(this.buttonSideBarSales);
            this.panelSideBar.Controls.Add(this.buttonSideBarStudents);
            this.panelSideBar.Controls.Add(this.buttonSideBarBooks);
            this.panelSideBar.Controls.Add(this.buttonSideBarHome);
            this.panelSideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideBar.Location = new System.Drawing.Point(0, 0);
            this.panelSideBar.Name = "panelSideBar";
            this.panelSideBar.Size = new System.Drawing.Size(200, 750);
            this.panelSideBar.TabIndex = 0;
            // 
            // labelPermission
            // 
            this.labelPermission.AutoSize = true;
            this.labelPermission.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.labelPermission.Font = new System.Drawing.Font("Cairo", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPermission.ForeColor = System.Drawing.Color.SandyBrown;
            this.labelPermission.Location = new System.Drawing.Point(66, 140);
            this.labelPermission.Name = "labelPermission";
            this.labelPermission.Size = new System.Drawing.Size(0, 23);
            this.labelPermission.TabIndex = 10;
            this.labelPermission.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.BackColor = System.Drawing.Color.Orange;
            this.labelUsername.Font = new System.Drawing.Font("Cairo", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsername.ForeColor = System.Drawing.Color.DarkRed;
            this.labelUsername.Location = new System.Drawing.Point(102, 105);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(0, 26);
            this.labelUsername.TabIndex = 9;
            this.labelUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonSideBarCategory
            // 
            this.buttonSideBarCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarCategory.FlatAppearance.BorderSize = 0;
            this.buttonSideBarCategory.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarCategory.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarCategory.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarCategory.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarCategory.Image = global::WFBookManagment.Properties.Resources.categories;
            this.buttonSideBarCategory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarCategory.Location = new System.Drawing.Point(0, 470);
            this.buttonSideBarCategory.Name = "buttonSideBarCategory";
            this.buttonSideBarCategory.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarCategory.TabIndex = 8;
            this.buttonSideBarCategory.Text = "فئــــــــــات";
            this.buttonSideBarCategory.UseVisualStyleBackColor = true;
            this.buttonSideBarCategory.Click += new System.EventHandler(this.buttonSideBarCategory_Click);
            // 
            // pBuImage
            // 
            this.pBuImage.BackColor = System.Drawing.Color.Bisque;
            this.pBuImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pBuImage.Image = global::WFBookManagment.Properties.Resources.MUser100;
            this.pBuImage.Location = new System.Drawing.Point(65, 5);
            this.pBuImage.Name = "pBuImage";
            this.pBuImage.Size = new System.Drawing.Size(130, 130);
            this.pBuImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBuImage.TabIndex = 7;
            this.pBuImage.TabStop = false;
            // 
            // buttonSideBarUsers
            // 
            this.buttonSideBarUsers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarUsers.Enabled = false;
            this.buttonSideBarUsers.FlatAppearance.BorderSize = 0;
            this.buttonSideBarUsers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarUsers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarUsers.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarUsers.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarUsers.Image = global::WFBookManagment.Properties.Resources.Users;
            this.buttonSideBarUsers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarUsers.Location = new System.Drawing.Point(0, 530);
            this.buttonSideBarUsers.Name = "buttonSideBarUsers";
            this.buttonSideBarUsers.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarUsers.TabIndex = 6;
            this.buttonSideBarUsers.Text = "أمـــنـــــاء";
            this.buttonSideBarUsers.UseVisualStyleBackColor = true;
            this.buttonSideBarUsers.Click += new System.EventHandler(this.buttonSideBarUsers_Click);
            // 
            // buttonSideBarBarrow
            // 
            this.buttonSideBarBarrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarBarrow.Enabled = false;
            this.buttonSideBarBarrow.FlatAppearance.BorderSize = 0;
            this.buttonSideBarBarrow.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarBarrow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarBarrow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarBarrow.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarBarrow.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarBarrow.Image = global::WFBookManagment.Properties.Resources.Borrow_Book;
            this.buttonSideBarBarrow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarBarrow.Location = new System.Drawing.Point(0, 410);
            this.buttonSideBarBarrow.Name = "buttonSideBarBarrow";
            this.buttonSideBarBarrow.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarBarrow.TabIndex = 5;
            this.buttonSideBarBarrow.Text = "إعــــــــارة";
            this.buttonSideBarBarrow.UseVisualStyleBackColor = true;
            this.buttonSideBarBarrow.Click += new System.EventHandler(this.buttonSideBarBarrow_Click);
            // 
            // buttonCallaps
            // 
            this.buttonCallaps.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCallaps.FlatAppearance.BorderSize = 0;
            this.buttonCallaps.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonCallaps.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonCallaps.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCallaps.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCallaps.ForeColor = System.Drawing.Color.Chocolate;
            this.buttonCallaps.Image = global::WFBookManagment.Properties.Resources.list2;
            this.buttonCallaps.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonCallaps.Location = new System.Drawing.Point(1, 1);
            this.buttonCallaps.Name = "buttonCallaps";
            this.buttonCallaps.Size = new System.Drawing.Size(50, 40);
            this.buttonCallaps.TabIndex = 4;
            this.buttonCallaps.UseVisualStyleBackColor = true;
            this.buttonCallaps.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonSideBarSales
            // 
            this.buttonSideBarSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarSales.Enabled = false;
            this.buttonSideBarSales.FlatAppearance.BorderSize = 0;
            this.buttonSideBarSales.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarSales.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarSales.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarSales.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarSales.Image = global::WFBookManagment.Properties.Resources.Sale_Price;
            this.buttonSideBarSales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarSales.Location = new System.Drawing.Point(0, 350);
            this.buttonSideBarSales.Name = "buttonSideBarSales";
            this.buttonSideBarSales.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarSales.TabIndex = 3;
            this.buttonSideBarSales.Text = "مبـيعــات";
            this.buttonSideBarSales.UseVisualStyleBackColor = true;
            this.buttonSideBarSales.Click += new System.EventHandler(this.buttonSideBarSales_Click);
            // 
            // buttonSideBarStudents
            // 
            this.buttonSideBarStudents.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarStudents.Enabled = false;
            this.buttonSideBarStudents.FlatAppearance.BorderSize = 0;
            this.buttonSideBarStudents.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarStudents.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarStudents.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarStudents.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarStudents.Image = global::WFBookManagment.Properties.Resources.students;
            this.buttonSideBarStudents.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarStudents.Location = new System.Drawing.Point(0, 290);
            this.buttonSideBarStudents.Name = "buttonSideBarStudents";
            this.buttonSideBarStudents.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarStudents.TabIndex = 2;
            this.buttonSideBarStudents.Text = "الطـــــلاب";
            this.buttonSideBarStudents.UseVisualStyleBackColor = true;
            this.buttonSideBarStudents.Click += new System.EventHandler(this.buttonSideBarStudents_Click);
            // 
            // buttonSideBarBooks
            // 
            this.buttonSideBarBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarBooks.Enabled = false;
            this.buttonSideBarBooks.FlatAppearance.BorderSize = 0;
            this.buttonSideBarBooks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarBooks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarBooks.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarBooks.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarBooks.Image = global::WFBookManagment.Properties.Resources.books;
            this.buttonSideBarBooks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarBooks.Location = new System.Drawing.Point(0, 230);
            this.buttonSideBarBooks.Name = "buttonSideBarBooks";
            this.buttonSideBarBooks.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarBooks.TabIndex = 1;
            this.buttonSideBarBooks.Text = "الكتـــــب";
            this.buttonSideBarBooks.UseVisualStyleBackColor = true;
            this.buttonSideBarBooks.Click += new System.EventHandler(this.buttonSideBarBooks_Click);
            // 
            // buttonSideBarHome
            // 
            this.buttonSideBarHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSideBarHome.FlatAppearance.BorderSize = 0;
            this.buttonSideBarHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSideBarHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSideBarHome.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSideBarHome.ForeColor = System.Drawing.Color.SandyBrown;
            this.buttonSideBarHome.Image = global::WFBookManagment.Properties.Resources.Homy;
            this.buttonSideBarHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSideBarHome.Location = new System.Drawing.Point(0, 170);
            this.buttonSideBarHome.Name = "buttonSideBarHome";
            this.buttonSideBarHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonSideBarHome.Size = new System.Drawing.Size(198, 50);
            this.buttonSideBarHome.TabIndex = 0;
            this.buttonSideBarHome.Text = "الرئيسية";
            this.buttonSideBarHome.UseVisualStyleBackColor = true;
            this.buttonSideBarHome.Click += new System.EventHandler(this.buttonSideBarHome_Click);
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.SandyBrown;
            this.panelTitleBar.Controls.Add(this.labelMainState);
            this.panelTitleBar.Controls.Add(this.buttonLock);
            this.panelTitleBar.Controls.Add(this.buttonInfo);
            this.panelTitleBar.Controls.Add(this.buttonMinimize);
            this.panelTitleBar.Controls.Add(this.buttonMaximize);
            this.panelTitleBar.Controls.Add(this.buttonExit);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(200, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(1000, 42);
            this.panelTitleBar.TabIndex = 1;
            // 
            // labelMainState
            // 
            this.labelMainState.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMainState.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelMainState.Location = new System.Drawing.Point(375, 4);
            this.labelMainState.Name = "labelMainState";
            this.labelMainState.Size = new System.Drawing.Size(250, 35);
            this.labelMainState.TabIndex = 0;
            this.labelMainState.Text = "الشــــاشة الرئيــسيــة ";
            this.labelMainState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonLock
            // 
            this.buttonLock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLock.Image = global::WFBookManagment.Properties.Resources.Security_Lock;
            this.buttonLock.Location = new System.Drawing.Point(961, 5);
            this.buttonLock.Name = "buttonLock";
            this.buttonLock.Size = new System.Drawing.Size(30, 30);
            this.buttonLock.TabIndex = 0;
            this.buttonLock.UseVisualStyleBackColor = true;
            this.buttonLock.Click += new System.EventHandler(this.buttonLock_Click);
            // 
            // buttonInfo
            // 
            this.buttonInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonInfo.Image = global::WFBookManagment.Properties.Resources.Info_Squared;
            this.buttonInfo.Location = new System.Drawing.Point(925, 5);
            this.buttonInfo.Name = "buttonInfo";
            this.buttonInfo.Size = new System.Drawing.Size(30, 30);
            this.buttonInfo.TabIndex = 0;
            this.buttonInfo.UseVisualStyleBackColor = true;
            // 
            // buttonMinimize
            // 
            this.buttonMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMinimize.Image = global::WFBookManagment.Properties.Resources.minimize;
            this.buttonMinimize.Location = new System.Drawing.Point(77, 5);
            this.buttonMinimize.Name = "buttonMinimize";
            this.buttonMinimize.Size = new System.Drawing.Size(30, 30);
            this.buttonMinimize.TabIndex = 0;
            this.buttonMinimize.UseVisualStyleBackColor = true;
            this.buttonMinimize.Click += new System.EventHandler(this.buttonMinimize_Click);
            // 
            // buttonMaximize
            // 
            this.buttonMaximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMaximize.Image = global::WFBookManagment.Properties.Resources.maximize;
            this.buttonMaximize.Location = new System.Drawing.Point(41, 5);
            this.buttonMaximize.Name = "buttonMaximize";
            this.buttonMaximize.Size = new System.Drawing.Size(30, 30);
            this.buttonMaximize.TabIndex = 0;
            this.buttonMaximize.UseVisualStyleBackColor = true;
            this.buttonMaximize.Click += new System.EventHandler(this.buttonMaximize_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(5, 5);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.dataGridViewMain);
            this.panelMain.Controls.Add(this.panelMainBottom);
            this.panelMain.Controls.Add(this.panelMainTop);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1000, 708);
            this.panelMain.TabIndex = 0;
            // 
            // dataGridViewMain
            // 
            this.dataGridViewMain.AllowUserToAddRows = false;
            this.dataGridViewMain.AllowUserToDeleteRows = false;
            this.dataGridViewMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMain.BackgroundColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMain.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewMain.ColumnHeadersHeight = 40;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewMain.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewMain.GridColor = System.Drawing.Color.SaddleBrown;
            this.dataGridViewMain.Location = new System.Drawing.Point(35, 89);
            this.dataGridViewMain.MultiSelect = false;
            this.dataGridViewMain.Name = "dataGridViewMain";
            this.dataGridViewMain.ReadOnly = true;
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewMain.RowTemplate.Height = 35;
            this.dataGridViewMain.RowTemplate.ReadOnly = true;
            this.dataGridViewMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMain.ShowCellToolTips = false;
            this.dataGridViewMain.ShowEditingIcon = false;
            this.dataGridViewMain.ShowRowErrors = false;
            this.dataGridViewMain.Size = new System.Drawing.Size(920, 500);
            this.dataGridViewMain.TabIndex = 2;
            this.dataGridViewMain.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMain_CellContentClick);
            this.dataGridViewMain.DoubleClick += new System.EventHandler(this.dataGridViewMain_DoubleClick);
            // 
            // panelMainBottom
            // 
            this.panelMainBottom.BackColor = System.Drawing.Color.Silver;
            this.panelMainBottom.Controls.Add(this.buttonReports);
            this.panelMainBottom.Controls.Add(this.buttonMainDetails);
            this.panelMainBottom.Controls.Add(this.buttonMainDelete);
            this.panelMainBottom.Controls.Add(this.buttonMainUpdate);
            this.panelMainBottom.Controls.Add(this.buttonMainAdd);
            this.panelMainBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelMainBottom.Location = new System.Drawing.Point(0, 613);
            this.panelMainBottom.Name = "panelMainBottom";
            this.panelMainBottom.Size = new System.Drawing.Size(1000, 95);
            this.panelMainBottom.TabIndex = 1;
            // 
            // buttonMainDetails
            // 
            this.buttonMainDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMainDetails.BackColor = System.Drawing.Color.Orange;
            this.buttonMainDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMainDetails.Enabled = false;
            this.buttonMainDetails.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.buttonMainDetails.FlatAppearance.BorderSize = 2;
            this.buttonMainDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonMainDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonMainDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMainDetails.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainDetails.ForeColor = System.Drawing.Color.SaddleBrown;
            this.buttonMainDetails.Image = global::WFBookManagment.Properties.Resources.details;
            this.buttonMainDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonMainDetails.Location = new System.Drawing.Point(259, 27);
            this.buttonMainDetails.Name = "buttonMainDetails";
            this.buttonMainDetails.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonMainDetails.Size = new System.Drawing.Size(150, 50);
            this.buttonMainDetails.TabIndex = 10;
            this.buttonMainDetails.Text = "تفاصيل";
            this.buttonMainDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonMainDetails.UseVisualStyleBackColor = false;
            this.buttonMainDetails.Click += new System.EventHandler(this.buttonMainDetails_Click);
            // 
            // buttonMainDelete
            // 
            this.buttonMainDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMainDelete.BackColor = System.Drawing.Color.Orange;
            this.buttonMainDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMainDelete.Enabled = false;
            this.buttonMainDelete.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.buttonMainDelete.FlatAppearance.BorderSize = 2;
            this.buttonMainDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Salmon;
            this.buttonMainDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Salmon;
            this.buttonMainDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMainDelete.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainDelete.ForeColor = System.Drawing.Color.SaddleBrown;
            this.buttonMainDelete.Image = global::WFBookManagment.Properties.Resources.delete32;
            this.buttonMainDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonMainDelete.Location = new System.Drawing.Point(425, 27);
            this.buttonMainDelete.Name = "buttonMainDelete";
            this.buttonMainDelete.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonMainDelete.Size = new System.Drawing.Size(150, 50);
            this.buttonMainDelete.TabIndex = 9;
            this.buttonMainDelete.Text = "حذف";
            this.buttonMainDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonMainDelete.UseVisualStyleBackColor = false;
            this.buttonMainDelete.Click += new System.EventHandler(this.buttonMainDelete_Click);
            // 
            // buttonMainUpdate
            // 
            this.buttonMainUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMainUpdate.BackColor = System.Drawing.Color.Orange;
            this.buttonMainUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMainUpdate.Enabled = false;
            this.buttonMainUpdate.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.buttonMainUpdate.FlatAppearance.BorderSize = 2;
            this.buttonMainUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.buttonMainUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGreen;
            this.buttonMainUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMainUpdate.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainUpdate.ForeColor = System.Drawing.Color.SaddleBrown;
            this.buttonMainUpdate.Image = global::WFBookManagment.Properties.Resources.update;
            this.buttonMainUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonMainUpdate.Location = new System.Drawing.Point(591, 27);
            this.buttonMainUpdate.Name = "buttonMainUpdate";
            this.buttonMainUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonMainUpdate.Size = new System.Drawing.Size(150, 50);
            this.buttonMainUpdate.TabIndex = 8;
            this.buttonMainUpdate.Text = "تعديل";
            this.buttonMainUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonMainUpdate.UseVisualStyleBackColor = false;
            this.buttonMainUpdate.Click += new System.EventHandler(this.buttonMainUpdate_Click);
            // 
            // buttonMainAdd
            // 
            this.buttonMainAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMainAdd.BackColor = System.Drawing.Color.Orange;
            this.buttonMainAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMainAdd.Enabled = false;
            this.buttonMainAdd.FlatAppearance.BorderColor = System.Drawing.Color.OrangeRed;
            this.buttonMainAdd.FlatAppearance.BorderSize = 2;
            this.buttonMainAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.buttonMainAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.buttonMainAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMainAdd.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainAdd.ForeColor = System.Drawing.Color.SaddleBrown;
            this.buttonMainAdd.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonMainAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonMainAdd.Location = new System.Drawing.Point(757, 27);
            this.buttonMainAdd.Name = "buttonMainAdd";
            this.buttonMainAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonMainAdd.Size = new System.Drawing.Size(150, 50);
            this.buttonMainAdd.TabIndex = 7;
            this.buttonMainAdd.Text = "إضافة";
            this.buttonMainAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonMainAdd.UseVisualStyleBackColor = false;
            this.buttonMainAdd.Click += new System.EventHandler(this.buttonMainAdd_Click);
            // 
            // panelMainTop
            // 
            this.panelMainTop.BackColor = System.Drawing.Color.Orange;
            this.panelMainTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMainTop.Controls.Add(this.label2);
            this.panelMainTop.Controls.Add(this.textBoxFind);
            this.panelMainTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMainTop.Location = new System.Drawing.Point(0, 0);
            this.panelMainTop.Name = "panelMainTop";
            this.panelMainTop.Size = new System.Drawing.Size(1000, 70);
            this.panelMainTop.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(577, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "صندوق البحث :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxFind
            // 
            this.textBoxFind.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxFind.Font = new System.Drawing.Font("Cairo", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFind.Location = new System.Drawing.Point(271, 14);
            this.textBoxFind.Name = "textBoxFind";
            this.textBoxFind.Size = new System.Drawing.Size(300, 40);
            this.textBoxFind.TabIndex = 0;
            this.textBoxFind.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panelContainer
            // 
            this.panelContainer.Controls.Add(this.panelMain);
            this.panelContainer.Controls.Add(this.panelHome);
            this.panelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContainer.Location = new System.Drawing.Point(200, 42);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Size = new System.Drawing.Size(1000, 708);
            this.panelContainer.TabIndex = 8;
            // 
            // panelHome
            // 
            this.panelHome.BackgroundImage = global::WFBookManagment.Properties.Resources.palacio40;
            this.panelHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelHome.Controls.Add(this.panel7);
            this.panelHome.Controls.Add(this.panelUserPox);
            this.panelHome.Controls.Add(this.panelBorrowsPox);
            this.panelHome.Controls.Add(this.panelCategoriesPox);
            this.panelHome.Controls.Add(this.panelStudentsPox);
            this.panelHome.Controls.Add(this.panelSalesPox);
            this.panelHome.Controls.Add(this.panelBooksPox);
            this.panelHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHome.Location = new System.Drawing.Point(0, 0);
            this.panelHome.Name = "panelHome";
            this.panelHome.Size = new System.Drawing.Size(1000, 708);
            this.panelHome.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.buttonAddUser);
            this.panel7.Controls.Add(this.buttonAddCategory);
            this.panel7.Controls.Add(this.buttonAddBorrow);
            this.panel7.Controls.Add(this.buttonAddSale);
            this.panel7.Controls.Add(this.buttonAddStudent);
            this.panel7.Controls.Add(this.buttonAddBook);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 558);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1000, 150);
            this.panel7.TabIndex = 7;
            // 
            // buttonAddUser
            // 
            this.buttonAddUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddUser.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddUser.FlatAppearance.BorderSize = 0;
            this.buttonAddUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddUser.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddUser.ForeColor = System.Drawing.Color.Black;
            this.buttonAddUser.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddUser.Location = new System.Drawing.Point(69, 37);
            this.buttonAddUser.Name = "buttonAddUser";
            this.buttonAddUser.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddUser.Size = new System.Drawing.Size(125, 60);
            this.buttonAddUser.TabIndex = 6;
            this.buttonAddUser.Text = "أمين";
            this.buttonAddUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddUser.UseVisualStyleBackColor = false;
            this.buttonAddUser.Click += new System.EventHandler(this.buttonAddUser_Click);
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddCategory.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddCategory.FlatAppearance.BorderSize = 0;
            this.buttonAddCategory.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCategory.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCategory.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCategory.ForeColor = System.Drawing.Color.Black;
            this.buttonAddCategory.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddCategory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCategory.Location = new System.Drawing.Point(216, 37);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddCategory.Size = new System.Drawing.Size(125, 60);
            this.buttonAddCategory.TabIndex = 5;
            this.buttonAddCategory.Text = "فئات";
            this.buttonAddCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddCategory.UseVisualStyleBackColor = false;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // buttonAddBorrow
            // 
            this.buttonAddBorrow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddBorrow.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddBorrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddBorrow.FlatAppearance.BorderSize = 0;
            this.buttonAddBorrow.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBorrow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBorrow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBorrow.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddBorrow.ForeColor = System.Drawing.Color.Black;
            this.buttonAddBorrow.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddBorrow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddBorrow.Location = new System.Drawing.Point(363, 37);
            this.buttonAddBorrow.Name = "buttonAddBorrow";
            this.buttonAddBorrow.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddBorrow.Size = new System.Drawing.Size(125, 60);
            this.buttonAddBorrow.TabIndex = 4;
            this.buttonAddBorrow.Text = "إعارات";
            this.buttonAddBorrow.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddBorrow.UseVisualStyleBackColor = false;
            this.buttonAddBorrow.Click += new System.EventHandler(this.buttonAddBorrow_Click);
            // 
            // buttonAddSale
            // 
            this.buttonAddSale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddSale.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSale.FlatAppearance.BorderSize = 0;
            this.buttonAddSale.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSale.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSale.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddSale.ForeColor = System.Drawing.Color.Black;
            this.buttonAddSale.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddSale.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddSale.Location = new System.Drawing.Point(510, 37);
            this.buttonAddSale.Name = "buttonAddSale";
            this.buttonAddSale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddSale.Size = new System.Drawing.Size(125, 60);
            this.buttonAddSale.TabIndex = 3;
            this.buttonAddSale.Text = "مبيعات";
            this.buttonAddSale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddSale.UseVisualStyleBackColor = false;
            this.buttonAddSale.Click += new System.EventHandler(this.buttonAddSale_Click);
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddStudent.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddStudent.FlatAppearance.BorderSize = 0;
            this.buttonAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddStudent.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddStudent.ForeColor = System.Drawing.Color.Black;
            this.buttonAddStudent.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(657, 37);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddStudent.Size = new System.Drawing.Size(125, 60);
            this.buttonAddStudent.TabIndex = 2;
            this.buttonAddStudent.Text = "طالب";
            this.buttonAddStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddStudent.UseVisualStyleBackColor = false;
            this.buttonAddStudent.Click += new System.EventHandler(this.buttonAddStudent_Click);
            // 
            // buttonAddBook
            // 
            this.buttonAddBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddBook.FlatAppearance.BorderSize = 0;
            this.buttonAddBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddBook.ForeColor = System.Drawing.Color.Black;
            this.buttonAddBook.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddBook.Location = new System.Drawing.Point(805, 37);
            this.buttonAddBook.Name = "buttonAddBook";
            this.buttonAddBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddBook.Size = new System.Drawing.Size(125, 60);
            this.buttonAddBook.TabIndex = 1;
            this.buttonAddBook.Text = "كتاب";
            this.buttonAddBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddBook.UseVisualStyleBackColor = false;
            this.buttonAddBook.Click += new System.EventHandler(this.buttonAddBook_Click);
            // 
            // panelUserPox
            // 
            this.panelUserPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelUserPox.BackColor = System.Drawing.Color.Cornsilk;
            this.panelUserPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelUserPox.Controls.Add(this.labelCountUsers);
            this.panelUserPox.Controls.Add(this.label9);
            this.panelUserPox.Location = new System.Drawing.Point(65, 294);
            this.panelUserPox.Name = "panelUserPox";
            this.panelUserPox.Size = new System.Drawing.Size(300, 225);
            this.panelUserPox.TabIndex = 6;
            // 
            // labelCountUsers
            // 
            this.labelCountUsers.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountUsers.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountUsers.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.labelCountUsers.Location = new System.Drawing.Point(24, 20);
            this.labelCountUsers.Name = "labelCountUsers";
            this.labelCountUsers.Size = new System.Drawing.Size(250, 65);
            this.labelCountUsers.TabIndex = 2;
            this.labelCountUsers.Text = "--";
            this.labelCountUsers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label9.Location = new System.Drawing.Point(24, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(250, 115);
            this.label9.TabIndex = 1;
            this.label9.Text = "أمناء";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelBorrowsPox
            // 
            this.panelBorrowsPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelBorrowsPox.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panelBorrowsPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBorrowsPox.Controls.Add(this.labelCountBorrows);
            this.panelBorrowsPox.Controls.Add(this.label11);
            this.panelBorrowsPox.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panelBorrowsPox.Location = new System.Drawing.Point(371, 294);
            this.panelBorrowsPox.Name = "panelBorrowsPox";
            this.panelBorrowsPox.Size = new System.Drawing.Size(300, 225);
            this.panelBorrowsPox.TabIndex = 5;
            // 
            // labelCountBorrows
            // 
            this.labelCountBorrows.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountBorrows.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountBorrows.ForeColor = System.Drawing.Color.DarkOrchid;
            this.labelCountBorrows.Location = new System.Drawing.Point(24, 20);
            this.labelCountBorrows.Name = "labelCountBorrows";
            this.labelCountBorrows.Size = new System.Drawing.Size(250, 65);
            this.labelCountBorrows.TabIndex = 2;
            this.labelCountBorrows.Text = "--";
            this.labelCountBorrows.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkOrchid;
            this.label11.Location = new System.Drawing.Point(24, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(250, 115);
            this.label11.TabIndex = 1;
            this.label11.Text = "إعارات";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelCategoriesPox
            // 
            this.panelCategoriesPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelCategoriesPox.BackColor = System.Drawing.Color.Chocolate;
            this.panelCategoriesPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCategoriesPox.Controls.Add(this.labelCountCategories);
            this.panelCategoriesPox.Controls.Add(this.label13);
            this.panelCategoriesPox.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panelCategoriesPox.Location = new System.Drawing.Point(677, 294);
            this.panelCategoriesPox.Name = "panelCategoriesPox";
            this.panelCategoriesPox.Size = new System.Drawing.Size(300, 225);
            this.panelCategoriesPox.TabIndex = 4;
            this.panelCategoriesPox.Click += new System.EventHandler(this.panelCategoriesPox_Click);
            this.panelCategoriesPox.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // labelCountCategories
            // 
            this.labelCountCategories.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountCategories.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountCategories.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labelCountCategories.Location = new System.Drawing.Point(24, 20);
            this.labelCountCategories.Name = "labelCountCategories";
            this.labelCountCategories.Size = new System.Drawing.Size(250, 65);
            this.labelCountCategories.TabIndex = 2;
            this.labelCountCategories.Text = "--";
            this.labelCountCategories.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.labelCountCategories.Click += new System.EventHandler(this.labelCountCategories_Click);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label13.Location = new System.Drawing.Point(24, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(250, 115);
            this.label13.TabIndex = 1;
            this.label13.Text = "الفئات";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // panelStudentsPox
            // 
            this.panelStudentsPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelStudentsPox.BackColor = System.Drawing.Color.Chocolate;
            this.panelStudentsPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStudentsPox.Controls.Add(this.labelCountStudents);
            this.panelStudentsPox.Controls.Add(this.label7);
            this.panelStudentsPox.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panelStudentsPox.Location = new System.Drawing.Point(37, 63);
            this.panelStudentsPox.Name = "panelStudentsPox";
            this.panelStudentsPox.Size = new System.Drawing.Size(300, 225);
            this.panelStudentsPox.TabIndex = 3;
            this.panelStudentsPox.Click += new System.EventHandler(this.panelStudentsPox_Click);
            // 
            // labelCountStudents
            // 
            this.labelCountStudents.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountStudents.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountStudents.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labelCountStudents.Location = new System.Drawing.Point(24, 138);
            this.labelCountStudents.Name = "labelCountStudents";
            this.labelCountStudents.Size = new System.Drawing.Size(250, 65);
            this.labelCountStudents.TabIndex = 2;
            this.labelCountStudents.Text = "--";
            this.labelCountStudents.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelCountStudents.Click += new System.EventHandler(this.labelCountStudents_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label7.Location = new System.Drawing.Point(24, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(250, 115);
            this.label7.TabIndex = 1;
            this.label7.Text = "طلاب";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // panelSalesPox
            // 
            this.panelSalesPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelSalesPox.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.panelSalesPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSalesPox.Controls.Add(this.labelCountSales);
            this.panelSalesPox.Controls.Add(this.label3);
            this.panelSalesPox.ForeColor = System.Drawing.Color.DarkOrchid;
            this.panelSalesPox.Location = new System.Drawing.Point(343, 63);
            this.panelSalesPox.Name = "panelSalesPox";
            this.panelSalesPox.Size = new System.Drawing.Size(300, 225);
            this.panelSalesPox.TabIndex = 2;
            // 
            // labelCountSales
            // 
            this.labelCountSales.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountSales.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountSales.ForeColor = System.Drawing.Color.DarkOrchid;
            this.labelCountSales.Location = new System.Drawing.Point(24, 138);
            this.labelCountSales.Name = "labelCountSales";
            this.labelCountSales.Size = new System.Drawing.Size(250, 65);
            this.labelCountSales.TabIndex = 2;
            this.labelCountSales.Text = "--";
            this.labelCountSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkOrchid;
            this.label3.Location = new System.Drawing.Point(24, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(250, 115);
            this.label3.TabIndex = 1;
            this.label3.Text = "مبيعات";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panelBooksPox
            // 
            this.panelBooksPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelBooksPox.BackColor = System.Drawing.Color.Cornsilk;
            this.panelBooksPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBooksPox.Controls.Add(this.labelCountBooks);
            this.panelBooksPox.Controls.Add(this.label5);
            this.panelBooksPox.Location = new System.Drawing.Point(649, 63);
            this.panelBooksPox.Name = "panelBooksPox";
            this.panelBooksPox.Size = new System.Drawing.Size(300, 225);
            this.panelBooksPox.TabIndex = 1;
            this.panelBooksPox.Click += new System.EventHandler(this.panelBooksPox_Click);
            // 
            // labelCountBooks
            // 
            this.labelCountBooks.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountBooks.Font = new System.Drawing.Font("khalaad Sara", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountBooks.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.labelCountBooks.Location = new System.Drawing.Point(24, 138);
            this.labelCountBooks.Name = "labelCountBooks";
            this.labelCountBooks.Size = new System.Drawing.Size(250, 65);
            this.labelCountBooks.TabIndex = 2;
            this.labelCountBooks.Text = "--";
            this.labelCountBooks.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.labelCountBooks.Click += new System.EventHandler(this.labelCountBooks_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Gulzar", 44F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label5.Location = new System.Drawing.Point(24, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(250, 115);
            this.label5.TabIndex = 1;
            this.label5.Text = "الكتب";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // buttonReports
            // 
            this.buttonReports.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonReports.BackColor = System.Drawing.Color.Orange;
            this.buttonReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonReports.Enabled = false;
            this.buttonReports.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.buttonReports.FlatAppearance.BorderSize = 2;
            this.buttonReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReports.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReports.ForeColor = System.Drawing.Color.SaddleBrown;
            this.buttonReports.Image = global::WFBookManagment.Properties.Resources.details;
            this.buttonReports.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonReports.Location = new System.Drawing.Point(93, 27);
            this.buttonReports.Name = "buttonReports";
            this.buttonReports.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonReports.Size = new System.Drawing.Size(150, 50);
            this.buttonReports.TabIndex = 11;
            this.buttonReports.Text = "تقارير";
            this.buttonReports.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonReports.UseVisualStyleBackColor = false;
            this.buttonReports.Click += new System.EventHandler(this.buttonReports_Click);
            // 
            // formMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(1200, 750);
            this.Controls.Add(this.panelContainer);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelSideBar);
            this.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الرئيسة - المكتبة";
            this.Activated += new System.EventHandler(this.formMain_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formMain_FormClosing);
            this.Load += new System.EventHandler(this.formMain_Load);
            this.panelSideBar.ResumeLayout(false);
            this.panelSideBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBuImage)).EndInit();
            this.panelTitleBar.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).EndInit();
            this.panelMainBottom.ResumeLayout(false);
            this.panelMainTop.ResumeLayout(false);
            this.panelMainTop.PerformLayout();
            this.panelContainer.ResumeLayout(false);
            this.panelHome.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panelUserPox.ResumeLayout(false);
            this.panelBorrowsPox.ResumeLayout(false);
            this.panelCategoriesPox.ResumeLayout(false);
            this.panelStudentsPox.ResumeLayout(false);
            this.panelSalesPox.ResumeLayout(false);
            this.panelBooksPox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideBar;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonLock;
        private System.Windows.Forms.Button buttonInfo;
        private System.Windows.Forms.Button buttonMinimize;
        private System.Windows.Forms.Button buttonMaximize;
        private System.Windows.Forms.Label labelMainState;
        private System.Windows.Forms.Button buttonSideBarHome;
        private System.Windows.Forms.Button buttonSideBarBooks;
        private System.Windows.Forms.Button buttonCallaps;
        private System.Windows.Forms.Button buttonSideBarSales;
        private System.Windows.Forms.Button buttonSideBarStudents;
        private System.Windows.Forms.Button buttonSideBarBarrow;
        private System.Windows.Forms.Button buttonSideBarUsers;
        private System.Windows.Forms.Button buttonSideBarCategory;
        private System.Windows.Forms.Panel panelContainer;
        private System.Windows.Forms.Panel panelHome;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button buttonAddUser;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.Button buttonAddBorrow;
        private System.Windows.Forms.Button buttonAddSale;
        private System.Windows.Forms.Button buttonAddStudent;
        private System.Windows.Forms.Button buttonAddBook;
        private System.Windows.Forms.Panel panelUserPox;
        private System.Windows.Forms.Label labelCountUsers;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panelBorrowsPox;
        private System.Windows.Forms.Label labelCountBorrows;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panelCategoriesPox;
        private System.Windows.Forms.Label labelCountCategories;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panelStudentsPox;
        private System.Windows.Forms.Label labelCountStudents;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panelSalesPox;
        private System.Windows.Forms.Label labelCountSales;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelBooksPox;
        private System.Windows.Forms.Label labelCountBooks;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelMainBottom;
        private System.Windows.Forms.Button buttonMainDetails;
        private System.Windows.Forms.Button buttonMainDelete;
        private System.Windows.Forms.Button buttonMainUpdate;
        private System.Windows.Forms.Button buttonMainAdd;
        private System.Windows.Forms.TextBox textBoxFind;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelMainTop;
        private System.Windows.Forms.DataGridView dataGridViewMain;
        public System.Windows.Forms.Label labelPermission;
        public System.Windows.Forms.Label labelUsername;
        public System.Windows.Forms.PictureBox pBuImage;
        private System.Windows.Forms.Button buttonReports;
    }
}