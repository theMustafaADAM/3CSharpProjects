﻿namespace WFBookManagment.PRL
{
    partial class formAddCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddCategory));
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.textBoxCategory = new System.Windows.Forms.TextBox();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelTitle.Location = new System.Drawing.Point(50, 120);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(300, 36);
            this.labelTitle.TabIndex = 3;
            this.labelTitle.Text = "اسم الفئة :";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxCategory
            // 
            this.textBoxCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCategory.Location = new System.Drawing.Point(50, 170);
            this.textBoxCategory.Multiline = true;
            this.textBoxCategory.Name = "textBoxCategory";
            this.textBoxCategory.Size = new System.Drawing.Size(300, 100);
            this.textBoxCategory.TabIndex = 0;
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddCategory.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddCategory.FlatAppearance.BorderSize = 0;
            this.buttonAddCategory.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCategory.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCategory.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCategory.ForeColor = System.Drawing.Color.Black;
            this.buttonAddCategory.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddCategory.Image")));
            this.buttonAddCategory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCategory.Location = new System.Drawing.Point(200, 276);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddCategory.Size = new System.Drawing.Size(150, 40);
            this.buttonAddCategory.TabIndex = 1;
            this.buttonAddCategory.Text = "فئات";
            this.buttonAddCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddCategory.UseVisualStyleBackColor = false;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // formAddCategory
            // 
            this.AcceptButton = this.buttonAddCategory;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(400, 447);
            this.Controls.Add(this.buttonAddCategory);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.textBoxCategory);
            this.Controls.Add(this.buttonExit);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(175, 227);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddCategory";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label labelTitle;
        public System.Windows.Forms.Button buttonAddCategory;
        public System.Windows.Forms.TextBox textBoxCategory;
    }
}