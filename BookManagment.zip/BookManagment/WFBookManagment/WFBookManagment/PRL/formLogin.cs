﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using WFBookManagment.DAL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formLogin : Form
    {
        public formLogin()
        {
            InitializeComponent();
            textBoxPassword.UseSystemPasswordChar = !checkBoxShowPassword.Checked;
        }

        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            textBoxPassword.UseSystemPasswordChar = !checkBoxShowPassword.Checked;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            //this.Close();
            formDialogYESNO dialogYESNO = new formDialogYESNO("هل تريد مغادرة برنامج المكتبة ؟");

            //  to Subscribe the Event and Get the Data to Private Method
            dialogYESNO.DataBack += Closing_DataBack;

            dialogYESNO.ShowDialog();

            if (!_ConfirmClose)
            {
                return;
            }

            Environment.Exit(0);
        }

        private void formLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (CloseMode)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل تريد مغادرة برنامج المكتبة ؟");

                //  to Subscribe the Event and Get the Data to Private Method
                dialogYESNO.DataBack += Closing_DataBack;

                dialogYESNO.ShowDialog();

                if (!_ConfirmClose)
                {
                    e.Cancel = (e.CloseReason == CloseReason.UserClosing);
                    return;
                }
            }
        }

        bool _ConfirmClose;

        private void Closing_DataBack(object sender, bool Answer)
        {
            _ConfirmClose = Answer;
        }

        clsUsers clsUser = new clsUsers();
        DataTable data = new DataTable();
        bool CloseMode = true;

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string _username = textBoxUsername.Text.Trim(),
                _password = textBoxPassword.Text.Trim();
            try
            {
                data = clsUser.LogIn(_username, _password);

                if (data.Rows.Count > 0)
                {
                    if (clsUser.UpdateLogInState(_username, _password))
                    {
                        CloseMode = false;
                        this.Close();
                        
                        formMain main = new formMain();

                        main.labelUsername.Text = data.Rows[0]["Username"].ToString();
                        main.labelPermission.Text = data.Rows[0]["uPermissions"].ToString();

                        if (data.Rows[0]["uImage"] is DBNull)
                            main.pBuImage.Image = Properties.Resources.MUser100;
                        else
                        {
                            byte[] Picture = (byte[])data.Rows[0]["uImage"];
                            MemoryStream stream = new MemoryStream(Picture);
                            main.pBuImage.Image = Image.FromStream(stream);
                        }

                        Program.UserName = data.Rows[0]["uName"].ToString();

                        main.Show();
                    }
                }
                else
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                        ("لم نجد مستخدما بالمعلومات المدخلة، حاول مرة أخرى");
                    missInfo.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
            }
        }
    }
}
