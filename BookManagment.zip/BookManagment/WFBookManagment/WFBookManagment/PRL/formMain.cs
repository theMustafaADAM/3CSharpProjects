﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WFBookManagment.PRL
{
    public partial class formMain : Form
    {

        public formMain()
        {
            InitializeComponent();

            if (labelUsername.Text == ""
                || labelPermission.Text == "")
            {
                buttonLock.PerformClick();
            }
        }

        public enum enState
        {
            Home = 0, Books = 1, Students = 2,
            Sales = 3, Borrows = 4, Categories = 5, Users = 6
        };
        private enState state;

        bool CloseMode = true;

        // Var Form BLL
        clsCategories clsCategory = new clsCategories();
        clsBooks clsbooks = new clsBooks();
        clsStudents clsstudent = new clsStudents();
        clsSales clsSale = new clsSales();
        clsBorrow clborrow = new clsBorrow();
        clsUsers clsUser = new clsUsers();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            CloseMode = true;
            //Environment.Exit(0);
            buttonLock.PerformClick();
        }

        private void buttonMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }

        private void buttonMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (panelSideBar.Size.Width == 200)
            {
                panelSideBar.Width = 50;
                dataGridViewMain.Width = 1075;
                buttonSideBarHome.RightToLeft = buttonSideBarBooks.RightToLeft
                    = buttonSideBarStudents.RightToLeft = buttonSideBarSales.RightToLeft
                    = buttonSideBarBarrow.RightToLeft = buttonSideBarUsers.RightToLeft
                    = buttonSideBarCategory.RightToLeft = RightToLeft.No;
            }
            else
            {
                panelSideBar.Width = 200;
                dataGridViewMain.Width = 920;
                buttonSideBarHome.RightToLeft = buttonSideBarBooks.RightToLeft
                    = buttonSideBarStudents.RightToLeft = buttonSideBarSales.RightToLeft
                    = buttonSideBarBarrow.RightToLeft = buttonSideBarUsers.RightToLeft
                    = buttonSideBarCategory.RightToLeft = RightToLeft.Yes;
            }
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonSideBarCategory_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            labelMainState.Text = "شــــاشة الفئـــــات";
            state = enState.Categories;

            _LoadCategories();
        }

        private void _LoadCategories()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Categories Data
                DataTable dtCategories = clsCategory.LoadData();
                dataGridViewMain.DataSource = dtCategories;
                labelCountCategories.Text = dtCategories.Rows.Count.ToString();
                dataGridViewMain.Columns["ت"].Width = 120;
                dataGridViewMain.Columns["الفئة"].HeaderText = "الفئــــــة";
                dataGridViewMain.ClearSelection();
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonSideBarUsers_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            state = enState.Users;
            labelMainState.Text = "شــــاشة الأمنـــــاء";

            _LoadAllUsers();
        }

        private void _LoadAllUsers()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Books Data
                DataTable dtUsers = clsUser.LoadUsers();
                dataGridViewMain.DataSource = dtUsers;
                labelCountUsers.Text = dtUsers.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 25;
                dataGridViewMain.Columns["ت"].Width = 40;
                dataGridViewMain.Columns["الأمين"].Width = 160;
                dataGridViewMain.Columns["القسم"].Visible = true;
                dataGridViewMain.Columns["الجوال"].Visible = true;
                dataGridViewMain.Columns["الوظيفة"].Visible = true;
                dataGridViewMain.Columns["الايميل"].Visible = true;
                dataGridViewMain.Columns["الدراسة"].Visible = false;
                dataGridViewMain.Columns["الخبرة"].Visible = false;
                dataGridViewMain.Columns["تخصص الدراسة"].Visible = true;
                dataGridViewMain.Columns["تخصص الخبرة"].Visible = true;
                dataGridViewMain.Columns["راتب التعيين"].Visible = false;
                dataGridViewMain.Columns["الصورة"].Visible = false;
                dataGridViewMain.Columns["Password"].Visible = false;
                dataGridViewMain.Columns["الصلاحيات"].Visible = false;
                dataGridViewMain.Columns["المستخدم"].Visible = false;
                dataGridViewMain.Columns["الحالة"].Visible = false;
                dataGridViewMain.ClearSelection();
            }
            catch (Exception ex)
            {
                formDialogFail missInfo = new formDialogFail(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonSideBarBooks_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            state = enState.Books;
            labelMainState.Text = "شــــاشة الكتـــــب";

            _LoadFullBooks();
        }

        private void _LoadFullBooks()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Books Data and Counts
                DataTable dtBooks = clsbooks.LoadFullBooks();
                dataGridViewMain.DataSource = dtBooks;
                labelCountBooks.Text = dtBooks.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 25;
                dataGridViewMain.Columns["ت"].Width = 40;
                dataGridViewMain.Columns["عنوان الكتاب"].Width = 170;
                dataGridViewMain.Columns["غلاف الكتاب"].Visible = false;
                //dataGridViewMain.Columns["الكمية"].Visible = false;
                dataGridViewMain.Columns["السعر"].Visible = false;
                dataGridViewMain.Columns["التقييم"].Visible = false;
                dataGridViewMain.ClearSelection();
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonSideBarHome_Click(object sender, EventArgs e)
        {
            panelHome.Visible = true;
            panelMain.Visible = false;

            state = enState.Home;
            labelMainState.Text = "الشــــاشة الرئيـــــسية";
        }

        private void buttonSideBarStudents_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            state = enState.Students;
            labelMainState.Text = "شــــاشة الطـــــلاب";

            _LoadAllStudents();
        }

        private void _LoadAllStudents()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Books Data
                DataTable dtStudents = clsstudent.LoadStudents();
                dataGridViewMain.DataSource = dtStudents;
                labelCountStudents.Text = dtStudents.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 25;
                dataGridViewMain.Columns["ت"].Width = 40;
                dataGridViewMain.Columns["اسم الطالب"].Width = 200;
                dataGridViewMain.Columns["الصورة"].Visible = false;
                dataGridViewMain.Columns["الكلية"].Visible = false;
                dataGridViewMain.ClearSelection();
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonSideBarSales_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            state = enState.Sales;
            labelMainState.Text = "شــــاشة المبيعـــــات";

            _LoadSales();
        }

        private void _LoadSales()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Books Data
                DataTable dtSales = clsSale.GetSales();
                dataGridViewMain.DataSource = dtSales;
                labelCountSales.Text = dtSales.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 25;
                dataGridViewMain.Columns["ت"].Width = 40;
                dataGridViewMain.Columns["التاريخ"].Visible = true;
                dataGridViewMain.Columns["البائع"].Visible = true;
                dataGridViewMain.Columns["الإجمالي"].Visible = true;
                dataGridViewMain.Columns["الطالب"].Visible = true;
                dataGridViewMain.Columns["الجوال"].Visible = true;
                dataGridViewMain.Columns["الايميل"].Visible = false;
                dataGridViewMain.Columns["ملغاة"].Visible = true;
                dataGridViewMain.ClearSelection();
                dgvBtn.HeaderText = "إلغاء";
                dgvBtn.Width = 90;
                dgvBtn.Text = "إلغاء";
                // to Show Text On Button
                dgvBtn.UseColumnTextForButtonValue = true;
                if (!dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Add(dgvBtn);
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonSideBarBarrow_Click(object sender, EventArgs e)
        {
            panelHome.Visible = false;
            panelMain.Visible = true;

            state = enState.Borrows;
            labelMainState.Text = "شــــاشة الإعـــــارات";

            _LoadBorrows();
        }

        DataGridViewButtonColumn dgvBtn = new DataGridViewButtonColumn();
        private void _LoadBorrows()
        {
            try
            {
                // Remove DGV Button
                if (dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Remove(dgvBtn);
                // Load Books Data
                DataTable dtBorrows = clborrow.GetBorrows();
                dataGridViewMain.DataSource = dtBorrows;
                labelCountBorrows.Text = dtBorrows.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 20;
                dataGridViewMain.Columns["ت"].Width = 35;
                dataGridViewMain.Columns["التاريخ"].Visible = true;
                dataGridViewMain.Columns["المعير"].Visible = true;
                dataGridViewMain.Columns["الطالب"].Visible = true;
                dataGridViewMain.Columns["الجوال"].Visible = true;
                dataGridViewMain.Columns["الايميل"].Visible = false;
                dataGridViewMain.Columns["الأسابيع"].Visible = true;
                dataGridViewMain.Columns["نهاية الإعارة"].Visible = true;
                dataGridViewMain.Columns["الإجمالي"].Visible = true;
                dataGridViewMain.Columns["السعر"].Visible = false;
                dataGridViewMain.ClearSelection();

                // to Show Text On Button
                dgvBtn.HeaderText = "إعادة";
                dgvBtn.Width = 90;
                dgvBtn.Text = "إعادة";
                dgvBtn.UseColumnTextForButtonValue = true;
                if (!dataGridViewMain.Columns.Contains(dgvBtn))
                    dataGridViewMain.Columns.Add(dgvBtn);
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void formMain_Load(object sender, EventArgs e)
        {
            panelHome.Visible = true;
            panelMain.Visible = false;
            state = enState.Home;
            labelMainState.Text = "الشــــاشة الرئيــسيــة";
        }

        private void buttonMainAdd_Click(object sender, EventArgs e)
        {

            switch (state)
            {
                case enState.Books:

                    formAddBook addBook = new formAddBook(0, false);
                    addBook.ShowDialog();

                    break;
                case enState.Students:

                    formAddStudent addstudent = new formAddStudent(0, false);
                    addstudent.ShowDialog();

                    break;
                case enState.Sales:

                    formAddBookSale bookSale = new formAddBookSale(-1);
                    bookSale.ShowDialog();

                    break;
                case enState.Borrows:

                    formAddBookBorrow bookBorrow = new formAddBookBorrow(-1, false);
                    bookBorrow.ShowDialog();

                    break;
                case enState.Categories:

                    formAddCategory addCategory = new formAddCategory(0, false);
                    addCategory.ShowDialog();

                    break;
                case enState.Users:

                    formAddUsers addUsers = new formAddUsers(-1, false);
                    addUsers.ShowDialog();

                    break;

                default: break;
            }
        }

        private void buttonMainUpdate_Click(object sender, EventArgs e)
        {
            switch (state)
            {
                case enState.Books:

                    int bookID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddBook updateBook = new formAddBook(bookID, false);
                    updateBook.textBoxBookTitle.Text = dataGridViewMain.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
                    updateBook.textBoxPrice.Text = dataGridViewMain.CurrentRow.Cells["السعر"].Value.ToString();
                    updateBook.textBoxPublish.Text = dataGridViewMain.CurrentRow.Cells["النشر"].Value.ToString();
                    updateBook.numericQty.Value = Convert.ToDecimal(dataGridViewMain.CurrentRow.Cells["الكمية"].Value);
                    updateBook.textBoxAuthor.Text = dataGridViewMain.CurrentRow.Cells["اسم المؤلف"].Value.ToString();
                    updateBook.textBoxCategory.Text = dataGridViewMain.CurrentRow.Cells["الفئة"].Value.ToString();

                    if (dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value is DBNull)
                        updateBook.BookCover.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        updateBook.BookCover.Image = Image.FromStream(stream);
                    }
                    updateBook.numericRate.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["التقييم"].Value);

                    updateBook.buttonAddBook.Image = Properties.Resources.update;
                    updateBook.ShowDialog();

                    break;

                case enState.Students:
                    int studenID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddStudent updStudent = new formAddStudent(studenID, false);
                    updStudent.textBoxstName.Text = dataGridViewMain.CurrentRow.Cells["اسم الطالب"].Value.ToString();
                    updStudent.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["جواله"].Value.ToString();
                    updStudent.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    updStudent.textBoxstAddress.Text = dataGridViewMain.CurrentRow.Cells["عنوانه"].Value.ToString();
                    updStudent.comboBoxSchools.SelectedIndex = updStudent.comboBoxSchools.FindString
                        (dataGridViewMain.CurrentRow.Cells["الكلية"].Value.ToString());
                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        updStudent.stImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        updStudent.stImage.Image = Image.FromStream(stream);
                    }
                    updStudent.buttonAddStudent.Image = Properties.Resources.update;
                    updStudent.ShowDialog();

                    break;
                case enState.Sales:

                    formDialogNotAllowed notAllowed = new formDialogNotAllowed();
                    notAllowed.ShowDialog();

                    break;
                case enState.Borrows:

                    int borrowID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddBookBorrow updateBorrow = new formAddBookBorrow(borrowID, true);
                    updateBorrow.textBoxBillNumber.Text = borrowID.ToString();
                    //returnBorrow.dtPSaleDate.Value = (DateTime)dataGridViewMain.CurrentRow.Cells["التاريخ"].Value;
                    updateBorrow.labelUser.Text = dataGridViewMain.CurrentRow.Cells["المعير"].Value.ToString();
                    updateBorrow.textBoxCustomer.Text = dataGridViewMain.CurrentRow.Cells["الطالب"].Value.ToString();
                    updateBorrow.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                    updateBorrow.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    updateBorrow.textBoxEndBorrow.Text = dataGridViewMain.CurrentRow.Cells["نهاية الإعارة"].Value.ToString();
                    updateBorrow.numericDays.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الأسابيع"].Value.ToString());
                    updateBorrow.buttonAddBorrow.Text = "تحديث إعارة";
                    updateBorrow.buttonAddBorrow.Image = Properties.Resources.update;
                    updateBorrow.dataGridViewCustomers.Enabled = false;
                    updateBorrow.ShowDialog();

                    break;
                case enState.Categories:

                    int catID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddCategory updateCategory = new formAddCategory(catID, false);
                    updateCategory.textBoxCategory.Text = dataGridViewMain.CurrentRow.Cells[1].Value.ToString();
                    updateCategory.buttonAddCategory.Image = Properties.Resources.update;
                    updateCategory.ShowDialog();

                    break;
                case enState.Users:

                    int userID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddUsers updateUser = new formAddUsers(userID, false);
                    updateUser.textBoxuName.Text = dataGridViewMain.CurrentRow.Cells["الأمين"].Value.ToString();
                    updateUser.textBoxUsername.Text = dataGridViewMain.CurrentRow.Cells["المستخدم"].Value.ToString();
                    updateUser.textBoxuMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();

                    if (dataGridViewMain.CurrentRow.Cells["الايميل"].Value is DBNull)
                        updateUser.textBoxstEmail.Text = string.Empty;
                    else
                        updateUser.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();

                    updateUser.checkBoxStates.Checked = (bool)dataGridViewMain.CurrentRow.Cells["الحالة"].Value;

                    updateUser.textBoxPassword.Text = dataGridViewMain.CurrentRow.Cells["Password"].Value.ToString();
                    updateUser.textBoxPassword.Enabled = false;
                    updateUser.textBoxPassword.ReadOnly = true;

                    updateUser.comboBoxDepartments.SelectedIndex = updateUser.comboBoxDepartments.FindString(dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString());
                    updateUser.textBoxDepartments.Text = dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString();

                    updateUser.comboBoxJob.SelectedIndex = updateUser.comboBoxJob.FindString(dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString());
                    updateUser.textBoxJobs.Text = dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString();

                    updateUser.comboBoxPermissions.SelectedIndex = updateUser.comboBoxPermissions.FindString(dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString());
                    updateUser.textBoxPermissions.Text = dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString();

                    updateUser.numericExpYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الخبرة"].Value);
                    updateUser.numericStdYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الدراسة"].Value);

                    updateUser.textBoxStdSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الدراسة"].Value);
                    updateUser.textBoxExpSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الخبرة"].Value);

                    updateUser.textBoxSalary.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["راتب التعيين"].Value);

                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        updateUser.uImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        updateUser.uImage.Image = Image.FromStream(stream);
                    }
                    updateUser.buttonAddStudent.Text = "تعديل أمين مكتبة";
                    updateUser.buttonAddStudent.Image = Properties.Resources.update;
                    updateUser.ShowDialog();

                    break;

                default: break;
            }
        }

        private void buttonMainDelete_Click(object sender, EventArgs e)
        {
            switch (state)
            {
                case enState.Books:
                    int bookID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddBook delBook = new formAddBook(bookID, true);
                    delBook.textBoxBookTitle.Text = dataGridViewMain.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
                    delBook.textBoxBookTitle.ReadOnly = true;
                    delBook.textBoxPrice.Text = dataGridViewMain.CurrentRow.Cells["السعر"].Value.ToString();
                    delBook.textBoxPrice.ReadOnly = true;
                    delBook.textBoxPublish.Text = dataGridViewMain.CurrentRow.Cells["النشر"].Value.ToString();
                    delBook.textBoxPublish.ReadOnly = true;

                    if (dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value is DBNull)
                        delBook.BookCover.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        delBook.BookCover.Image = Image.FromStream(stream);
                    }
                    delBook.buttonAddBook.Image = Properties.Resources.delete32;
                    delBook.ShowDialog();
                    break;

                case enState.Students:

                    int studenID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddStudent delStudent = new formAddStudent(studenID, true);
                    delStudent.textBoxstName.Text = dataGridViewMain.CurrentRow.Cells["اسم الطالب"].Value.ToString();
                    delStudent.textBoxstName.ReadOnly = true;
                    delStudent.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["جواله"].Value.ToString();
                    delStudent.textBoxstMobile.ReadOnly = true;
                    delStudent.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    delStudent.textBoxstEmail.ReadOnly = true;
                    delStudent.textBoxstAddress.Text = dataGridViewMain.CurrentRow.Cells["عنوانه"].Value.ToString();
                    delStudent.textBoxstAddress.ReadOnly = true;
                    delStudent.comboBoxSchools.Text = dataGridViewMain.CurrentRow.Cells["الكلية"].Value.ToString();
                    delStudent.comboBoxSchools.Enabled = false;
                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        delStudent.stImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        delStudent.stImage.Image = Image.FromStream(stream);
                    }
                    delStudent.stImage.Enabled = false;
                    delStudent.linkLabelCover.Enabled = false;
                    delStudent.buttonAddStudent.Image = Properties.Resources.delete32;
                    delStudent.ShowDialog();

                    break;
                case enState.Sales:

                    formDialogNotAllowed notAllowed = new formDialogNotAllowed();
                    notAllowed.ShowDialog();

                    break;
                case enState.Borrows:

                    formDialogNotAllowed delnotAllowed = new formDialogNotAllowed();
                    delnotAllowed.ShowDialog();

                    break;
                case enState.Categories:

                    int catID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddCategory delCategory = new formAddCategory(catID, true);
                    delCategory.textBoxCategory.Text = dataGridViewMain.CurrentRow.Cells[1].Value.ToString();
                    delCategory.textBoxCategory.ReadOnly = true;
                    delCategory.buttonAddCategory.Image = Properties.Resources.delete32;
                    delCategory.ShowDialog();

                    break;

                case enState.Users:

                    int userID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddUsers delUser = new formAddUsers(userID, true);
                    delUser.textBoxuName.Text = dataGridViewMain.CurrentRow.Cells["الأمين"].Value.ToString();
                    delUser.textBoxUsername.Text = dataGridViewMain.CurrentRow.Cells["المستخدم"].Value.ToString();
                    delUser.textBoxuMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                    delUser.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    delUser.checkBoxStates.Checked = (bool)dataGridViewMain.CurrentRow.Cells["الحالة"].Value;

                    delUser.textBoxPassword.Text = dataGridViewMain.CurrentRow.Cells["Password"].Value.ToString();
                    delUser.textBoxConfirmPassword.Text = dataGridViewMain.CurrentRow.Cells["Password"].Value.ToString();
                    delUser.textBoxPassword.Enabled = false;
                    delUser.textBoxPassword.ReadOnly = true;

                    delUser.comboBoxDepartments.SelectedIndex = delUser.comboBoxDepartments.FindString(dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString());
                    delUser.textBoxDepartments.Text = dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString();

                    delUser.comboBoxJob.SelectedIndex = delUser.comboBoxJob.FindString(dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString());
                    delUser.textBoxJobs.Text = dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString();

                    delUser.comboBoxPermissions.SelectedIndex = delUser.comboBoxPermissions.FindString(dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString());
                    delUser.textBoxPermissions.Text = dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString();

                    delUser.numericExpYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الخبرة"].Value);
                    delUser.numericStdYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الدراسة"].Value);

                    delUser.textBoxStdSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الدراسة"].Value);
                    delUser.textBoxExpSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الخبرة"].Value);

                    delUser.textBoxSalary.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["راتب التعيين"].Value);

                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        delUser.uImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        delUser.uImage.Image = Image.FromStream(stream);
                    }

                    delUser.textBoxuName.Enabled =
                    delUser.textBoxUsername.Enabled =
                    delUser.textBoxPassword.Enabled =
                    delUser.textBoxConfirmPassword.Enabled =
                    delUser.textBoxuMobile.Enabled =
                    delUser.textBoxstEmail.Enabled =
                    delUser.comboBoxDepartments.Enabled =
                    delUser.comboBoxPermissions.Enabled =
                    delUser.comboBoxJob.Enabled =
                    delUser.linkLabeluImage.Enabled =
                    delUser.buttonAddDepartment.Enabled =
                    delUser.buttonAddJobs.Enabled =
                    delUser.numericExpYears.Enabled =
                    delUser.numericStdYears.Enabled =
                    delUser.textBoxStdSpecialty.Enabled =
                    delUser.comboBoxSpecialtyStd.Enabled =
                    delUser.textBoxExpSpecialty.Enabled =
                    delUser.comboBoxSpecialtyExp.Enabled =
                    delUser.buttonAddSpecialty.Enabled =
                    delUser.buttonAddSpecialties.Enabled =
                    delUser.checkBoxStates.Enabled =
                    delUser.buttonAddPersmission.Enabled = false;

                    delUser.buttonAddStudent.Image = Properties.Resources.delete32;
                    delUser.ShowDialog();

                    break;

                default: break;
            }
        }

        private void buttonMainDetails_Click(object sender, EventArgs e)
        {
            switch (state)
            {
                case enState.Books:
                    int bookID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formBookDetails detBook = new formBookDetails();
                    detBook.textBoxBookTitle.Text = dataGridViewMain.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
                    detBook.textBoxBookTitle.ReadOnly = true;
                    detBook.textBoxPrice.Text = dataGridViewMain.CurrentRow.Cells["السعر"].Value.ToString();
                    detBook.textBoxPrice.ReadOnly = true;
                    detBook.textBoxPublish.Text = dataGridViewMain.CurrentRow.Cells["النشر"].Value.ToString();
                    detBook.textBoxPublish.ReadOnly = true;
                    detBook.textBoxAuthor.Text = dataGridViewMain.CurrentRow.Cells["اسم المؤلف"].Value.ToString();
                    detBook.textBoxCategory.Text = dataGridViewMain.CurrentRow.Cells["الفئة"].Value.ToString();
                    if (dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value is DBNull)
                        detBook.BookCover.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["غلاف الكتاب"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        detBook.BookCover.Image = Image.FromStream(stream);
                    }
                    detBook.numericRate.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["التقييم"].Value);
                    detBook.ShowDialog();
                    break;
                case enState.Students:

                    formStudentDetails detStudent = new formStudentDetails();
                    detStudent.textBoxstName.Text = dataGridViewMain.CurrentRow.Cells["اسم الطالب"].Value.ToString();
                    detStudent.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["جواله"].Value.ToString();
                    detStudent.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    detStudent.textBoxstAddress.Text = dataGridViewMain.CurrentRow.Cells["عنوانه"].Value.ToString();
                    detStudent.textBoxSchool.Text = dataGridViewMain.CurrentRow.Cells["الكلية"].Value.ToString();
                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        detStudent.stImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        detStudent.stImage.Image = Image.FromStream(stream);
                    }
                    detStudent.ShowDialog();

                    break;
                case enState.Sales:

                    int saleID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formShowBookSale showSale = new formShowBookSale(saleID);
                    showSale.textBoxBillNumber.Text = saleID.ToString();
                    showSale.textBoxdtSale.Text = dataGridViewMain.CurrentRow.Cells["التاريخ"].Value.ToString();
                    showSale.labelUser.Text = dataGridViewMain.CurrentRow.Cells["البائع"].Value.ToString();
                    showSale.textBoxStudent.Text = dataGridViewMain.CurrentRow.Cells["الطالب"].Value.ToString();
                    showSale.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                    showSale.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    showSale.textBoxTotal.Text = dataGridViewMain.CurrentRow.Cells["الإجمالي"].Value.ToString();
                    showSale.ShowDialog();
                    break;
                case enState.Borrows:

                    int borrowID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formShowBookBorrow showBorrow = new formShowBookBorrow(borrowID);
                    showBorrow.textBoxBillNumber.Text = borrowID.ToString();
                    //showBorrow.dtPSaleDate.Value = (DateTime)dataGridViewMain.CurrentRow.Cells["التاريخ"].Value;
                    showBorrow.labelUser.Text = dataGridViewMain.CurrentRow.Cells["المعير"].Value.ToString();
                    showBorrow.textBoxCustomer.Text = dataGridViewMain.CurrentRow.Cells["الطالب"].Value.ToString();
                    showBorrow.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                    showBorrow.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    showBorrow.textBoxEndBorrow.Text = dataGridViewMain.CurrentRow.Cells["نهاية الإعارة"].Value.ToString();
                    showBorrow.numericDays.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["أيام الإعارة"].Value.ToString());
                    showBorrow.buttonAddBook.Enabled = false;
                    showBorrow.buttonAddToList.Enabled = false;
                    showBorrow.buttonSetBook.Enabled = false;
                    showBorrow.buttonRemoveBook.Enabled = false;
                    showBorrow.buttonRemoveAll.Enabled = false;
                    showBorrow.ShowDialog();

                    break;
                case enState.Categories:
                    int catID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddCategory detCategory = new formAddCategory(catID, true);
                    detCategory.textBoxCategory.Text = dataGridViewMain.CurrentRow.Cells[1].Value.ToString();
                    detCategory.textBoxCategory.ReadOnly = true;
                    detCategory.buttonAddCategory.Visible = false;
                    detCategory.ShowDialog();

                    break;
                case enState.Users:

                    int userID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                    formAddUsers delUser = new formAddUsers(userID, true);
                    delUser.textBoxuName.Text = dataGridViewMain.CurrentRow.Cells["الأمين"].Value.ToString();
                    delUser.textBoxUsername.Text = dataGridViewMain.CurrentRow.Cells["المستخدم"].Value.ToString();
                    delUser.textBoxuMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                    delUser.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                    delUser.checkBoxStates.Checked = (bool)dataGridViewMain.CurrentRow.Cells["الحالة"].Value;

                    delUser.textBoxPassword.Text = dataGridViewMain.CurrentRow.Cells["Password"].Value.ToString();
                    delUser.textBoxConfirmPassword.Text = dataGridViewMain.CurrentRow.Cells["Password"].Value.ToString();
                    delUser.textBoxPassword.Enabled = false;
                    delUser.textBoxPassword.ReadOnly = true;

                    delUser.comboBoxDepartments.SelectedIndex = delUser.comboBoxDepartments.FindString(dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString());
                    delUser.textBoxDepartments.Text = dataGridViewMain.CurrentRow.Cells["القسم"].Value.ToString();

                    delUser.comboBoxJob.SelectedIndex = delUser.comboBoxJob.FindString(dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString());
                    delUser.textBoxJobs.Text = dataGridViewMain.CurrentRow.Cells["الوظيفة"].Value.ToString();

                    delUser.comboBoxPermissions.SelectedIndex = delUser.comboBoxPermissions.FindString(dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString());
                    delUser.textBoxPermissions.Text = dataGridViewMain.CurrentRow.Cells["الصلاحيات"].Value.ToString();

                    delUser.numericExpYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الخبرة"].Value);
                    delUser.numericStdYears.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الدراسة"].Value);

                    delUser.textBoxStdSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الدراسة"].Value);
                    delUser.textBoxExpSpecialty.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["تخصص الخبرة"].Value);

                    delUser.textBoxSalary.Text = Convert.ToString(dataGridViewMain.CurrentRow.Cells["راتب التعيين"].Value);

                    if (dataGridViewMain.CurrentRow.Cells["الصورة"].Value is DBNull)
                        delUser.uImage.Image = null;
                    else
                    {
                        byte[] Picture = (byte[])dataGridViewMain.CurrentRow.Cells["الصورة"].Value;
                        MemoryStream stream = new MemoryStream(Picture);
                        delUser.uImage.Image = Image.FromStream(stream);
                    }

                    delUser.textBoxuName.Enabled =
                    delUser.textBoxUsername.Enabled =
                    delUser.textBoxPassword.Enabled =
                    delUser.textBoxConfirmPassword.Enabled =
                    delUser.textBoxuMobile.Enabled =
                    delUser.textBoxstEmail.Enabled =
                    delUser.textBoxStdSpecialty.Enabled =
                    delUser.textBoxExpSpecialty.Enabled =
                    delUser.comboBoxDepartments.Enabled =
                    delUser.comboBoxPermissions.Enabled =
                    delUser.comboBoxJob.Enabled =
                    delUser.comboBoxSpecialtyExp.Enabled =
                    delUser.comboBoxSpecialtyStd.Enabled =
                    delUser.numericExpYears.Enabled =
                    delUser.numericStdYears.Enabled =
                    delUser.checkBoxStates.Enabled =
                    delUser.linkLabelRemove.Enabled =
                    delUser.linkLabeluImage.Enabled =
                    delUser.buttonAddSpecialties.Enabled =
                    delUser.buttonAddStudent.Visible =
                    delUser.buttonAddSpecialty.Enabled =
                    delUser.buttonAddDepartment.Enabled =
                    delUser.buttonAddJobs.Enabled =
                    delUser.buttonAddPersmission.Enabled = false;

                    delUser.ShowDialog();

                    break;

                default: break;
            }
        }

        private void formMain_Activated(object sender, EventArgs e)
        {
            _FillLabelWithItemsCounts();

            // فتح الصلاحيات
            switch (labelPermission.Text)
            {
                case "كتب":

                    buttonSideBarBooks.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "طلاب":

                    buttonSideBarStudents.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "مبيعات":

                    buttonSideBarSales.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "إعارات":

                    buttonSideBarBarrow.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "أمناء":

                    buttonSideBarUsers.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "مبرمج":

                    buttonSideBarStudents.Enabled = true;
                    buttonSideBarSales.Enabled = true;
                    buttonSideBarBarrow.Enabled = true;
                    buttonSideBarBooks.Enabled = true;
                    buttonSideBarUsers.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;

                    break;

                case "مدير":

                    buttonSideBarStudents.Enabled = true;
                    buttonSideBarSales.Enabled = true;
                    buttonSideBarBarrow.Enabled = true;
                    buttonSideBarBooks.Enabled = true;
                    buttonSideBarUsers.Enabled = true;
                    buttonMainDelete.Enabled = true;
                    buttonMainAdd.Enabled = true;
                    buttonMainUpdate.Enabled = true;
                    buttonMainDetails.Enabled = true;
                    buttonReports.Enabled = true;

                    break;

                default:
                    break;
            }

            /*if(labelPermission.Text == "كتب") 
            {
            }
            else if(labelPermission.Text == "طلاب")
            {
            }
            else if (labelPermission.Text == "مبيعات")
            {
            }
            else if (labelPermission.Text == "إعارات")
            {
            }
            else if (labelPermission.Text == "أمناء")
            {
            }
            else if (labelPermission.Text == "مبرمج")
            {
            }
            else if (labelPermission.Text == "مدير")
            {
            }
            else 
            {
                /*formDialogFail fail = new formDialogFail("يرجى دخول النظام أولاً");
                fail.ShowDialog();
                buttonLock.PerformClick();
                return;
            }*/

            switch (state)
            {
                case enState.Books: _LoadFullBooks(); break;
                case enState.Students: _LoadAllStudents(); break;
                case enState.Sales: _LoadSales(); break;
                case enState.Borrows: _LoadBorrows(); break;
                case enState.Categories: _LoadCategories(); break;
                case enState.Users: _LoadAllUsers(); break;
                default: break;
            }
        }

        private void _FillLabelWithItemsCounts()
        {
            //Books==================================================
            DataTable dtcBooks = clsbooks.LoadFullBooks();
            dataGridViewMain.DataSource = dtcBooks;
            labelCountBooks.Text = dtcBooks.Rows.Count.ToString();
            //Students==================================================
            DataTable dtcStudents = clsstudent.LoadStudents();
            dataGridViewMain.DataSource = dtcStudents;
            labelCountStudents.Text = dtcStudents.Rows.Count.ToString();
            //Sales==================================================
            DataTable dtcSales = clsSale.GetSales();
            dataGridViewMain.DataSource = dtcSales;
            labelCountSales.Text = dtcSales.Rows.Count.ToString();
            //Borrows==================================================
            DataTable dtcBorrows = clborrow.GetBorrows();
            dataGridViewMain.DataSource = dtcBorrows;
            labelCountBorrows.Text = dtcBorrows.Rows.Count.ToString();
            //Categories==================================================
            DataTable dtcCategories = clsCategory.LoadData();
            dataGridViewMain.DataSource = dtcCategories;
            labelCountCategories.Text = dtcCategories.Rows.Count.ToString();
            //Users==================================================
            DataTable dtcUsers = clsUser.LoadUsers();
            dataGridViewMain.DataSource = dtcUsers;
            labelCountUsers.Text = dtcUsers.Rows.Count.ToString();
        }

        private void dataGridViewMain_DoubleClick(object sender, EventArgs e)
        {
            buttonMainUpdate.PerformClick();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            switch (state)
            {
                case enState.Books:
                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);
                    dataGridViewMain.DataSource = clsBooks.FindBook(textBoxFind.Text);
                    dataGridViewMain.RowHeadersWidth = 25;
                    dataGridViewMain.Columns["ت"].Width = 40;
                    dataGridViewMain.Columns["عنوان الكتاب"].Width = 200;
                    dataGridViewMain.Columns["غلاف الكتاب"].Visible = false;
                    dataGridViewMain.Columns["السعر"].Visible = false;
                    dataGridViewMain.Columns["التقييم"].Visible = false;
                    dataGridViewMain.ClearSelection();
                    break;
                case enState.Students:
                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);
                    dataGridViewMain.DataSource = clsStudents.FindStudent(textBoxFind.Text);
                    dataGridViewMain.RowHeadersWidth = 25;
                    dataGridViewMain.Columns["ت"].Width = 40;
                    dataGridViewMain.Columns["اسم الطالب"].Width = 200;
                    dataGridViewMain.Columns["الصورة"].Visible = false;
                    dataGridViewMain.Columns["الكلية"].Visible = false;
                    dataGridViewMain.ClearSelection();
                    break;
                case enState.Sales:
                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);
                    //dataGridViewMain.DataSource = clsSales.FindSale(textBoxFind.Text);
                    dataGridViewMain.DataSource = clsSales.FindConcatSale(textBoxFind.Text);
                    dataGridViewMain.RowHeadersWidth = 25;
                    dataGridViewMain.Columns["ت"].Width = 40;
                    dataGridViewMain.Columns["التاريخ"].Visible = true;
                    dataGridViewMain.Columns["البائع"].Visible = true;
                    dataGridViewMain.Columns["الإجمالي"].Visible = true;
                    dataGridViewMain.Columns["الطالب"].Visible = true;
                    dataGridViewMain.Columns["الجوال"].Visible = true;
                    dataGridViewMain.Columns["الايميل"].Visible = false;
                    dataGridViewMain.Columns["ملغاة"].Visible = true;
                    dataGridViewMain.ClearSelection();
                    // to Show Text On Button
                    dgvBtn.UseColumnTextForButtonValue = true;
                    if (!dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Add(dgvBtn);

                    break;
                case enState.Borrows:
                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);
                    //dataGridViewMain.DataSource = clsBorrow.FindBorrow(textBoxFind.Text);
                    dataGridViewMain.DataSource = clsBorrow.FindConcatBorrow(textBoxFind.Text);
                    dataGridViewMain.RowHeadersWidth = 25;
                    dataGridViewMain.Columns["ت"].Width = 40;
                    dataGridViewMain.Columns["التاريخ"].Visible = true;
                    dataGridViewMain.Columns["المعير"].Visible = true;
                    dataGridViewMain.Columns["الطالب"].Visible = true;
                    dataGridViewMain.Columns["الجوال"].Visible = true;
                    dataGridViewMain.Columns["الايميل"].Visible = false;
                    dataGridViewMain.Columns["الأسابيع"].Visible = true;
                    dataGridViewMain.Columns["الإجمالي"].Visible = true;
                    dataGridViewMain.Columns["السعر"].Visible = false;
                    dataGridViewMain.Columns["نهاية الإعارة"].Visible = true;
                    dataGridViewMain.ClearSelection();
                    // to Show Text On Button
                    dgvBtn.HeaderText = "إعادة";
                    dgvBtn.Width = 90;
                    dgvBtn.Text = "إعادة";
                    dgvBtn.UseColumnTextForButtonValue = true;
                    if (!dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Add(dgvBtn);

                    break;
                case enState.Categories:
                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);
                    dataGridViewMain.DataSource = clsCategories.FindData(textBoxFind.Text);
                    dataGridViewMain.Columns[0].Width = 120;
                    dataGridViewMain.Columns[0].HeaderText = "تسلسل";
                    dataGridViewMain.Columns[1].HeaderText = "الفئــــــة";
                    dataGridViewMain.ClearSelection();
                    break;

                case enState.Users:

                    // Remove DGV Button
                    if (dataGridViewMain.Columns.Contains(dgvBtn))
                        dataGridViewMain.Columns.Remove(dgvBtn);

                    dataGridViewMain.DataSource = clsUsers.FindData(textBoxFind.Text);
                    dataGridViewMain.RowHeadersWidth = 25;
                    dataGridViewMain.Columns["ت"].Width = 40;
                    dataGridViewMain.Columns["الأمين"].Width = 160;
                    dataGridViewMain.Columns["القسم"].Visible = true;
                    dataGridViewMain.Columns["الجوال"].Visible = true;
                    dataGridViewMain.Columns["الوظيفة"].Visible = true;
                    dataGridViewMain.Columns["الايميل"].Visible = true;
                    dataGridViewMain.Columns["الدراسة"].Visible = false;
                    dataGridViewMain.Columns["الخبرة"].Visible = false;
                    dataGridViewMain.Columns["تخصص الدراسة"].Visible = true;
                    dataGridViewMain.Columns["تخصص الخبرة"].Visible = true;
                    dataGridViewMain.Columns["راتب التعيين"].Visible = false;
                    dataGridViewMain.Columns["الصورة"].Visible = false;
                    dataGridViewMain.Columns["Password"].Visible = false;
                    dataGridViewMain.Columns["الصلاحيات"].Visible = false;
                    dataGridViewMain.Columns["المستخدم"].Visible = false;
                    dataGridViewMain.Columns["الحالة"].Visible = false;
                    dataGridViewMain.ClearSelection();

                    break;

                default: break;
            }
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (labelPermission.Text == "")
            {
                formDialogFail fail = new formDialogFail("يرجى دخول النظام أولاً");
                fail.ShowDialog();
                return;
            }
        }

        private void labelCountCategories_Click(object sender, EventArgs e)
        {
            buttonSideBarCategory.PerformClick();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            //buttonSideBarCategory.PerformClick();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            buttonSideBarCategory.PerformClick();
        }

        private void panelStudentsPox_Click(object sender, EventArgs e)
        {
            buttonSideBarStudents.PerformClick();
        }

        private void panelCategoriesPox_Click(object sender, EventArgs e)
        {
            buttonSideBarCategory.PerformClick();
        }

        private void panelBooksPox_Click(object sender, EventArgs e)
        {
            buttonSideBarBooks.PerformClick();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            buttonSideBarBooks.PerformClick();
        }

        private void labelCountBooks_Click(object sender, EventArgs e)
        {
            buttonSideBarBooks.PerformClick();
        }

        private void formMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (CloseMode)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل تريد مغادرة برنامج المكتبة ؟");

                //  to Subscribe the Event and Get the Data to Private Method
                dialogYESNO.DataBack += Closing_DataBack;

                dialogYESNO.ShowDialog();

                if (!_ConfirmClose)
                {
                    e.Cancel = (e.CloseReason == CloseReason.UserClosing);
                    return;
                }
            }
        }

        bool _ConfirmClose;

        private void Closing_DataBack(object sender, bool Answer)
        {
            _ConfirmClose = Answer;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            buttonSideBarStudents.PerformClick();
        }

        private void labelCountStudents_Click(object sender, EventArgs e)
        {
            buttonSideBarStudents.PerformClick();
        }

        private void dataGridViewMain_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                switch (state)
                {
                    case enState.Home: break;
                    case enState.Books: break;
                    case enState.Students: break;
                    case enState.Sales:
                        int saleID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                        bool Canceled = Convert.ToBoolean(dataGridViewMain.CurrentRow.Cells["ملغاة"].Value);
                        if (Canceled)
                        {
                            formDialogNotAllowed frm = new formDialogNotAllowed();
                            frm.ShowDialog(); return;
                        }
                        formAddBookSale canceleSale = new formAddBookSale(saleID);
                        canceleSale.textBoxBillNumber.Text = saleID.ToString();
                        canceleSale.labelUser.Text = dataGridViewMain.CurrentRow.Cells["البائع"].Value.ToString();
                        canceleSale.textBoxstName.Text = dataGridViewMain.CurrentRow.Cells["الطالب"].Value.ToString();
                        canceleSale.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                        canceleSale.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                        canceleSale.dataGridViewBooks.Enabled = canceleSale.dataGridViewCustomers.Enabled = false;
                        canceleSale.buttonAddBook.Enabled = false;
                        canceleSale.buttonAddToList.Enabled = false;
                        canceleSale.buttonSetBook.Enabled = false;
                        canceleSale.buttonRemoveBook.Enabled = false;
                        canceleSale.buttonClearTable.Enabled = false;
                        canceleSale.textBoxTotal.Text = dataGridViewMain.CurrentRow.Cells["الإجمالي"].Value.ToString();
                        canceleSale.buttonAddSale.Text = "إلغاء البيع";
                        canceleSale.buttonAddSale.Image = Properties.Resources.update;
                        canceleSale.ShowDialog();
                        break;

                    case enState.Borrows:
                        int borrowID = Convert.ToInt32(dataGridViewMain.CurrentRow.Cells["ت"].Value);
                        bool Returned = Convert.ToBoolean(dataGridViewMain.CurrentRow.Cells["أُعيدت"].Value);
                        if (Returned)
                        {
                            formDialogNotAllowed frm = new formDialogNotAllowed();
                            frm.ShowDialog(); return;
                        }
                        formAddBookBorrow returnBorrow = new formAddBookBorrow(borrowID, false);
                        returnBorrow.textBoxBillNumber.Text = borrowID.ToString();
                        //returnBorrow.dtPSaleDate.Value = (DateTime)dataGridViewMain.CurrentRow.Cells["التاريخ"].Value;
                        returnBorrow.labelUser.Text = dataGridViewMain.CurrentRow.Cells["المعير"].Value.ToString();
                        returnBorrow.textBoxCustomer.Text = dataGridViewMain.CurrentRow.Cells["الطالب"].Value.ToString();
                        returnBorrow.textBoxstMobile.Text = dataGridViewMain.CurrentRow.Cells["الجوال"].Value.ToString();
                        returnBorrow.textBoxstEmail.Text = dataGridViewMain.CurrentRow.Cells["الايميل"].Value.ToString();
                        returnBorrow.buttonAddBook.Enabled = false;
                        returnBorrow.buttonAddToList.Enabled = false;
                        returnBorrow.buttonSetBook.Enabled = false;
                        returnBorrow.buttonRemoveBook.Enabled = false;
                        returnBorrow.buttonRemoveAll.Enabled = false;
                        returnBorrow.textBoxEndBorrow.Text = dataGridViewMain.CurrentRow.Cells["نهاية الإعارة"].Value.ToString();
                        returnBorrow.numericDays.Value = Convert.ToInt16(dataGridViewMain.CurrentRow.Cells["الأسابيع"].Value.ToString());
                        returnBorrow.buttonAddBorrow.Text = "تسجيل إرجاع";
                        returnBorrow.buttonAddBorrow.Image = Properties.Resources.update;
                        returnBorrow.ShowDialog();
                        break;
                    case enState.Categories: break;
                    case enState.Users: break;
                    default: break;
                }
            }
        }

        private void buttonAddStudent_Click(object sender, EventArgs e)
        {
            // التحقق من الصلاحيات
            if (labelPermission.Text == "طلاب" || labelPermission.Text == "مدير")
            {
                formAddStudent addstudent = new formAddStudent(0, false);
                addstudent.ShowDialog();
            }
            else
            {
                formDialogFail fail = new formDialogFail("لا تملك الصلاحية لإضافة طالب");
                fail.ShowDialog();
                return;
            }
        }

        private void buttonAddSale_Click(object sender, EventArgs e)
        {
            // التحقق من الصلاحيات
            if (labelPermission.Text == "مبيعات" || labelPermission.Text == "مدير")
            {
                formAddStudent addstudent = new formAddStudent(0, false);
                addstudent.ShowDialog();
            }
            else
            {
                formDialogFail fail = new formDialogFail("لا تملك الصلاحية لإنشاء مبيعات");
                fail.ShowDialog();
                return;
            }
        }

        private void buttonAddBorrow_Click(object sender, EventArgs e)
        {
            // التحقق من الصلاحيات
            if (labelPermission.Text == "إعارات" || labelPermission.Text == "مدير")
            {
                formAddBookBorrow bookBorrow = new formAddBookBorrow(-1, false);
                bookBorrow.ShowDialog();
            }
            else
            {
                formDialogFail fail = new formDialogFail("لا تملك الصلاحية لإنشاء إعارات");
                fail.ShowDialog();
                return;
            }
        }

        private void buttonAddUser_Click(object sender, EventArgs e)
        {
            // التحقق من الصلاحيات
            if (labelPermission.Text == "أمناء" || labelPermission.Text == "مدير")
            {
                formAddUsers addUsers = new formAddUsers(-1, false);
                addUsers.ShowDialog();
            }
            else
            {
                formDialogFail fail = new formDialogFail("لا تملك الصلاحية لإضافة أمين");
                fail.ShowDialog();
                return;
            }
        }

        private void buttonLock_Click(object sender, EventArgs e)
        {
            CloseMode = false;
            clsUser.LogOut();
            labelPermission.Text = labelUsername.Text = "";
            //this.Hide();
            formLogin login = new formLogin();
            login.Show();
        }

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            // التحقق من الصلاحيات
            if (labelPermission.Text == "كتب" || labelPermission.Text == "مدير")
            {
                formAddBook addBook = new formAddBook(0, false);
                addBook.ShowDialog();
            }
            else
            {
                formDialogFail fail = new formDialogFail("لا تملك الصلاحية لإضافة كتاب");
                fail.ShowDialog();
                return;
            }
        }

        private void buttonReports_Click(object sender, EventArgs e)
        {
            formAddReports addReports = new formAddReports();
            addReports.ShowDialog();
        }
    }
}