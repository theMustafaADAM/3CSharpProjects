﻿namespace WFBookManagment.PRL
{
    partial class formShowBookSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formShowBookSale));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.labelUser = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxBillNumber = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBoxdtSale = new System.Windows.Forms.TextBox();
            this.buttonNewBill = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxStudent = new System.Windows.Forms.TextBox();
            this.buttonAddBook = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxstEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxstMobile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.buttonClearTable = new System.Windows.Forms.Button();
            this.buttonRemoveBook = new System.Windows.Forms.Button();
            this.buttonAddToList = new System.Windows.Forms.Button();
            this.dataGridViewBooks = new System.Windows.Forms.DataGridView();
            this.buttonSetBook = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonAddSale = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBooks)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(905, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "الرقم :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelUser
            // 
            this.labelUser.Font = new System.Drawing.Font("Tajawal", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.labelUser.Location = new System.Drawing.Point(37, 5);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(292, 70);
            this.labelUser.TabIndex = 10;
            this.labelUser.Text = "مستخدم النظام ";
            this.labelUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label6.Location = new System.Drawing.Point(607, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 36);
            this.label6.TabIndex = 12;
            this.label6.Text = "تاريخ الفاتورة :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxBillNumber
            // 
            this.textBoxBillNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBillNumber.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxBillNumber.Location = new System.Drawing.Point(792, 22);
            this.textBoxBillNumber.Name = "textBoxBillNumber";
            this.textBoxBillNumber.ReadOnly = true;
            this.textBoxBillNumber.Size = new System.Drawing.Size(110, 37);
            this.textBoxBillNumber.TabIndex = 22;
            this.textBoxBillNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.textBoxdtSale);
            this.panel3.Controls.Add(this.buttonNewBill);
            this.panel3.Controls.Add(this.textBoxBillNumber);
            this.panel3.Controls.Add(this.labelUser);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(-25, 47);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1050, 80);
            this.panel3.TabIndex = 24;
            // 
            // textBoxdtSale
            // 
            this.textBoxdtSale.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxdtSale.Font = new System.Drawing.Font("Simplified Arabic Fixed", 19F);
            this.textBoxdtSale.Location = new System.Drawing.Point(335, 21);
            this.textBoxdtSale.Name = "textBoxdtSale";
            this.textBoxdtSale.ReadOnly = true;
            this.textBoxdtSale.Size = new System.Drawing.Size(266, 35);
            this.textBoxdtSale.TabIndex = 35;
            this.textBoxdtSale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonNewBill
            // 
            this.buttonNewBill.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonNewBill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNewBill.FlatAppearance.BorderSize = 0;
            this.buttonNewBill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonNewBill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonNewBill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNewBill.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNewBill.ForeColor = System.Drawing.Color.Black;
            this.buttonNewBill.Image = ((System.Drawing.Image)(resources.GetObject("buttonNewBill.Image")));
            this.buttonNewBill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewBill.Location = new System.Drawing.Point(749, 22);
            this.buttonNewBill.Name = "buttonNewBill";
            this.buttonNewBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonNewBill.Size = new System.Drawing.Size(39, 38);
            this.buttonNewBill.TabIndex = 34;
            this.buttonNewBill.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonNewBill.UseVisualStyleBackColor = false;
            this.buttonNewBill.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.textBoxStudent);
            this.panel1.Controls.Add(this.buttonAddBook);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.textBoxTotal);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.textBoxstEmail);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBoxstMobile);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.buttonAddStudent);
            this.panel1.Controls.Add(this.buttonClearTable);
            this.panel1.Controls.Add(this.buttonRemoveBook);
            this.panel1.Controls.Add(this.buttonAddToList);
            this.panel1.Controls.Add(this.dataGridViewBooks);
            this.panel1.Controls.Add(this.buttonSetBook);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.buttonAddSale);
            this.panel1.Location = new System.Drawing.Point(45, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(910, 433);
            this.panel1.TabIndex = 25;
            // 
            // textBoxStudent
            // 
            this.textBoxStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxStudent.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxStudent.Location = new System.Drawing.Point(586, 80);
            this.textBoxStudent.Name = "textBoxStudent";
            this.textBoxStudent.ReadOnly = true;
            this.textBoxStudent.Size = new System.Drawing.Size(287, 40);
            this.textBoxStudent.TabIndex = 35;
            this.textBoxStudent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonAddBook
            // 
            this.buttonAddBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddBook.FlatAppearance.BorderSize = 0;
            this.buttonAddBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAddBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddBook.ForeColor = System.Drawing.Color.Black;
            this.buttonAddBook.Image = global::WFBookManagment.Properties.Resources.addbook44;
            this.buttonAddBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddBook.Location = new System.Drawing.Point(519, 97);
            this.buttonAddBook.Name = "buttonAddBook";
            this.buttonAddBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddBook.Size = new System.Drawing.Size(38, 38);
            this.buttonAddBook.TabIndex = 34;
            this.buttonAddBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddBook.UseVisualStyleBackColor = false;
            this.buttonAddBook.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cairo", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label8.Location = new System.Drawing.Point(586, 402);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "ريال سعودي";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTotal.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxTotal.Location = new System.Drawing.Point(586, 362);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.ReadOnly = true;
            this.textBoxTotal.Size = new System.Drawing.Size(287, 37);
            this.textBoxTotal.TabIndex = 31;
            this.textBoxTotal.Text = "0";
            this.textBoxTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label7.Location = new System.Drawing.Point(703, 322);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 37);
            this.label7.TabIndex = 30;
            this.label7.Text = "المبلغ الإجمالي :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxstEmail
            // 
            this.textBoxstEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstEmail.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxstEmail.Location = new System.Drawing.Point(586, 272);
            this.textBoxstEmail.Name = "textBoxstEmail";
            this.textBoxstEmail.ReadOnly = true;
            this.textBoxstEmail.Size = new System.Drawing.Size(287, 40);
            this.textBoxstEmail.TabIndex = 29;
            this.textBoxstEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label5.Location = new System.Drawing.Point(703, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(170, 36);
            this.label5.TabIndex = 28;
            this.label5.Text = "بريده الالكتروني :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // textBoxstMobile
            // 
            this.textBoxstMobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstMobile.Font = new System.Drawing.Font("Simplified Arabic Fixed", 19F);
            this.textBoxstMobile.Location = new System.Drawing.Point(586, 176);
            this.textBoxstMobile.Name = "textBoxstMobile";
            this.textBoxstMobile.ReadOnly = true;
            this.textBoxstMobile.Size = new System.Drawing.Size(287, 35);
            this.textBoxstMobile.TabIndex = 27;
            this.textBoxstMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label3.Location = new System.Drawing.Point(703, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 36);
            this.label3.TabIndex = 7;
            this.label3.Text = "جواله :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(703, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 36);
            this.label2.TabIndex = 7;
            this.label2.Text = "الطالب أو العميل :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddStudent.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddStudent.FlatAppearance.BorderSize = 0;
            this.buttonAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAddStudent.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddStudent.ForeColor = System.Drawing.Color.Black;
            this.buttonAddStudent.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddStudent.Image")));
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(834, 80);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddStudent.Size = new System.Drawing.Size(39, 40);
            this.buttonAddStudent.TabIndex = 17;
            this.buttonAddStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddStudent.UseVisualStyleBackColor = false;
            // 
            // buttonClearTable
            // 
            this.buttonClearTable.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonClearTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonClearTable.FlatAppearance.BorderSize = 0;
            this.buttonClearTable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonClearTable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonClearTable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonClearTable.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClearTable.ForeColor = System.Drawing.Color.Black;
            this.buttonClearTable.Image = global::WFBookManagment.Properties.Resources.clearAll;
            this.buttonClearTable.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonClearTable.Location = new System.Drawing.Point(519, 273);
            this.buttonClearTable.Name = "buttonClearTable";
            this.buttonClearTable.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonClearTable.Size = new System.Drawing.Size(39, 38);
            this.buttonClearTable.TabIndex = 26;
            this.buttonClearTable.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonClearTable.UseVisualStyleBackColor = false;
            this.buttonClearTable.Visible = false;
            // 
            // buttonRemoveBook
            // 
            this.buttonRemoveBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonRemoveBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRemoveBook.FlatAppearance.BorderSize = 0;
            this.buttonRemoveBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonRemoveBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonRemoveBook.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonRemoveBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRemoveBook.ForeColor = System.Drawing.Color.Black;
            this.buttonRemoveBook.Image = global::WFBookManagment.Properties.Resources.Remove_Book;
            this.buttonRemoveBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonRemoveBook.Location = new System.Drawing.Point(519, 229);
            this.buttonRemoveBook.Name = "buttonRemoveBook";
            this.buttonRemoveBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonRemoveBook.Size = new System.Drawing.Size(39, 38);
            this.buttonRemoveBook.TabIndex = 25;
            this.buttonRemoveBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonRemoveBook.UseVisualStyleBackColor = false;
            this.buttonRemoveBook.Visible = false;
            // 
            // buttonAddToList
            // 
            this.buttonAddToList.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddToList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddToList.FlatAppearance.BorderSize = 0;
            this.buttonAddToList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddToList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddToList.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAddToList.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddToList.ForeColor = System.Drawing.Color.Black;
            this.buttonAddToList.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddToList.Image")));
            this.buttonAddToList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddToList.Location = new System.Drawing.Point(519, 185);
            this.buttonAddToList.Name = "buttonAddToList";
            this.buttonAddToList.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddToList.Size = new System.Drawing.Size(39, 38);
            this.buttonAddToList.TabIndex = 24;
            this.buttonAddToList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddToList.UseVisualStyleBackColor = false;
            this.buttonAddToList.Visible = false;
            // 
            // dataGridViewBooks
            // 
            this.dataGridViewBooks.AllowUserToAddRows = false;
            this.dataGridViewBooks.AllowUserToDeleteRows = false;
            this.dataGridViewBooks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewBooks.BackgroundColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cairo", 14.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBooks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewBooks.ColumnHeadersHeight = 40;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cairo", 14.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewBooks.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewBooks.GridColor = System.Drawing.Color.SaddleBrown;
            this.dataGridViewBooks.Location = new System.Drawing.Point(29, 34);
            this.dataGridViewBooks.MultiSelect = false;
            this.dataGridViewBooks.Name = "dataGridViewBooks";
            this.dataGridViewBooks.ReadOnly = true;
            this.dataGridViewBooks.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewBooks.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewBooks.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewBooks.RowTemplate.Height = 25;
            this.dataGridViewBooks.RowTemplate.ReadOnly = true;
            this.dataGridViewBooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBooks.ShowCellToolTips = false;
            this.dataGridViewBooks.ShowEditingIcon = false;
            this.dataGridViewBooks.ShowRowErrors = false;
            this.dataGridViewBooks.Size = new System.Drawing.Size(484, 333);
            this.dataGridViewBooks.TabIndex = 3;
            // 
            // buttonSetBook
            // 
            this.buttonSetBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonSetBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSetBook.FlatAppearance.BorderSize = 0;
            this.buttonSetBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonSetBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonSetBook.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSetBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSetBook.ForeColor = System.Drawing.Color.Black;
            this.buttonSetBook.Image = global::WFBookManagment.Properties.Resources.Search32;
            this.buttonSetBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSetBook.Location = new System.Drawing.Point(519, 141);
            this.buttonSetBook.Name = "buttonSetBook";
            this.buttonSetBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonSetBook.Size = new System.Drawing.Size(38, 38);
            this.buttonSetBook.TabIndex = 18;
            this.buttonSetBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonSetBook.UseVisualStyleBackColor = false;
            this.buttonSetBook.Visible = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(260, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(250, 37);
            this.label4.TabIndex = 9;
            this.label4.Text = "الكتب المختارة وتفاصيلها";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // buttonAddSale
            // 
            this.buttonAddSale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddSale.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSale.FlatAppearance.BorderSize = 0;
            this.buttonAddSale.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSale.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSale.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddSale.ForeColor = System.Drawing.Color.Black;
            this.buttonAddSale.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddSale.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddSale.Location = new System.Drawing.Point(29, 365);
            this.buttonAddSale.Name = "buttonAddSale";
            this.buttonAddSale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddSale.Size = new System.Drawing.Size(197, 40);
            this.buttonAddSale.TabIndex = 1;
            this.buttonAddSale.Text = "إنشاء فاتورة";
            this.buttonAddSale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddSale.UseVisualStyleBackColor = false;
            this.buttonAddSale.Visible = false;
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // formShowBookSale
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.panel3);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(120, 100);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formShowBookSale";
            this.Opacity = 0.95D;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label labelUser;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox textBoxBillNumber;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TextBox textBoxTotal;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox textBoxstEmail;
        public System.Windows.Forms.Button buttonAddSale;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox textBoxstMobile;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button buttonAddStudent;
        public System.Windows.Forms.Button buttonClearTable;
        public System.Windows.Forms.Button buttonRemoveBook;
        public System.Windows.Forms.Button buttonAddToList;
        public System.Windows.Forms.Button buttonSetBook;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Button buttonNewBill;
        public System.Windows.Forms.Button buttonAddBook;
        public System.Windows.Forms.TextBox textBoxdtSale;
        public System.Windows.Forms.DataGridView dataGridViewBooks;
        public System.Windows.Forms.TextBox textBoxStudent;
    }
}