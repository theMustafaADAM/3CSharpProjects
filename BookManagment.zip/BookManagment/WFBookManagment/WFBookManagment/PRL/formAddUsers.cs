﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using WFBookManagment.DAL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formAddUsers : Form
    {
        public formAddUsers(int ID, bool Stt)
        {

            InitializeComponent();
            _ID = ID;
            _Delstate = Stt;

            if (_Delstate)
            {
                comboBoxJob.Enabled = buttonAddJobs.Enabled = textBoxstEmail.Enabled =
                    linkLabeluImage.Enabled = uImage.Enabled = false;
                comboBoxJob.Text = string.Empty;
            }

        }

        private void _FillComboWithJobs()
        {
            int depID = clsDepartments.Find(comboBoxDepartments.Text).depID;
            comboBoxJob.DataSource = clsUser.LoadJobsByDepartmentID(depID);
            comboBoxJob.DisplayMember = "الوظيفة";
            comboBoxJob.ValueMember = "ت";
        }

        private void _FillComboWithDepartments()
        {
            //DataTable dtDepartments = clsUsers.LoadDepartments();
            //foreach (DataRow row in dtDepartments.Rows)
            //{
            //    comboBoxDepartments.Items.Add(row["القسم"]);
            //}

            comboBoxDepartments.DataSource = clsUsers.LoadDepartments();
            comboBoxDepartments.DisplayMember = "القسم";
            comboBoxDepartments.ValueMember = "ت";
            textBoxDepartments.Text = comboBoxDepartments.Text;
        }

        private void _FillComboWithPermissions()
        {
            comboBoxPermissions.DataSource = clsUsers.LoadPermissions();
            comboBoxPermissions.DisplayMember = "الصلاحية";
            comboBoxPermissions.ValueMember = "ت";
        }

        private void _FillComboWithSpecialties()
        {
            comboBoxSpecialtyExp.DataSource =  comboBoxSpecialtyStd.DataSource = 
                clsUsers.LoadSpecialties();
            comboBoxSpecialtyStd.DisplayMember = 
                comboBoxSpecialtyExp.DisplayMember = "التخصص";
            comboBoxSpecialtyStd.ValueMember = 
                comboBoxSpecialtyExp.ValueMember = "ت";
        }

        private bool _Delstate;
        private int _ID;
        MemoryStream stream;
        byte[] byteImg;
        clsUsers clsUser = new clsUsers();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public decimal CheckSalary()
        {
            decimal salary = 0;
            
            // رواتب الشهادة ما قبل الثانوي
            if ((numericStdYears.Value < 10) && (numericExpYears.Value < 4)) salary = 3000;
            
            else if ((numericStdYears.Value < 10)
                && (numericExpYears.Value > 3 && numericExpYears.Value < 8)) salary = 5000;
            
            else if ((numericStdYears.Value < 10)
                        && (numericExpYears.Value > 7)) salary = 7000;

            // رواتب الشهادة الثانوية إلى الجامعية
            else if ((numericStdYears.Value > 9 && numericStdYears.Value < 17)
                && (numericExpYears.Value < 4)) salary = 6000;
            
            else if ((numericStdYears.Value > 9 && numericStdYears.Value < 17)
                && (numericExpYears.Value > 3 && numericExpYears.Value < 8)) salary = 8000;
            
            else if ((numericStdYears.Value > 9 && numericStdYears.Value < 17)
                && (numericExpYears.Value > 7)) salary = 10000;

            // رواتب شهادات الدبلوم العالي فأعلى
            else if ((numericStdYears.Value > 16) && (numericExpYears.Value < 4)) salary = 9000;
            
            else if ((numericStdYears.Value > 16)
                && (numericExpYears.Value > 3 && numericExpYears.Value < 8)) salary = 11000;
            
            else if (numericStdYears.Value > 16 && numericExpYears.Value > 7) salary = 13000;

            return salary;
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren() ||            
                (textBoxuName.Text == string.Empty              || textBoxDepartments.Text == string.Empty
                || textBoxJobs.Text == string.Empty             || textBoxUsername.Text == string.Empty
                || textBoxuMobile.Text == string.Empty          || textBoxPermissions.Text == string.Empty
                || textBoxConfirmPassword.Text == string.Empty  || textBoxPassword.Text == string.Empty))
            {
                formDialogMissInfo missInfo = new formDialogMissInfo();
                missInfo.ShowDialog();
                return;
            }

            // INSERT With Image & Email
            if (_ID == -1 && (uImage.Image != null && textBoxstEmail.Text != string.Empty))
            {
                stream = new MemoryStream();
                uImage.Image.Save(stream, uImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsUser = new clsUsers();
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Insert(clsUser, "Full");

                formDialogOK done = new formDialogOK("حٌفظ الأمين بكامل المعلومات");
                done.ShowDialog();
                _ResetTools();
            }
            // Inset Without Image & Email
            else if (_ID == -1 && (uImage.Image == null && textBoxstEmail.Text == string.Empty))
            {
                byteImg = new byte[0];

                clsUser = new clsUsers();
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Insert(clsUser, "None");

                formDialogOK done = new formDialogOK("حُفظ معلومات الأمين على نقص");
                done.ShowDialog();
                _ResetTools();
            }
            // Inset Without Image
            else if (_ID == -1 && (uImage.Image == null && textBoxstEmail.Text != string.Empty))
            {
                byteImg = new byte[0];

                clsUser = new clsUsers();
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Insert(clsUser, "NoImg");

                formDialogOK done = new formDialogOK("حُفظ الأمين بلا صورة");
                done.ShowDialog();
                _ResetTools();
            }
            // Inset Without Email
            else if (_ID == -1 && (uImage.Image != null && textBoxstEmail.Text == string.Empty))
            {
                stream = new MemoryStream();
                uImage.Image.Save(stream, uImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsUser = new clsUsers();
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Insert(clsUser, "NoMail");

                formDialogOK done = new formDialogOK("حُفظ الأمين بلا ايميل");
                done.ShowDialog();
                _ResetTools();
            }
            // UPDATE Full
            else if ((_ID != -1 && !_Delstate) && (uImage.Image != null && textBoxstEmail.Text != string.Empty))
            {
                stream = new MemoryStream();
                uImage.Image.Save(stream, uImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsUser = new clsUsers();
                clsUser.uID = _ID;
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Update(clsUser, "Full");

                formDialogOK done = new formDialogOK("عُدلت كامل معلومات الأمين");
                done.ShowDialog();
            }
            // Update Without Image & Email
            else if ((_ID != 0 && !_Delstate) && (uImage.Image == null && textBoxstEmail.Text == string.Empty))
            {
                byteImg = new byte[0];

                clsUser = new clsUsers();
                clsUser.uID = _ID;
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Update(clsUser, "None");

                formDialogOK done = new formDialogOK("عُدلت معلومات الأمين على نقص");
                done.ShowDialog();
            }
            // Update Without Image
            else if ((_ID != 0 && !_Delstate) && (uImage.Image == null && textBoxstEmail.Text != string.Empty))
            {
                byteImg = new byte[0];

                clsUser = new clsUsers();
                clsUser.uID = _ID;
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Update(clsUser, "NoImg");

                formDialogOK done = new formDialogOK("عُدلت معلومات الأمين بلا صورة");
                done.ShowDialog();
            }
            // UPDATE Without Email
            else if ((_ID != -1 && !_Delstate) && (uImage.Image != null && textBoxstEmail.Text == string.Empty))
            {
                stream = new MemoryStream();
                uImage.Image.Save(stream, uImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsUser = new clsUsers();
                clsUser.uID = _ID;
                clsUser.uName = textBoxuName.Text;
                clsUser.Username = textBoxUsername.Text;
                clsUser.Password = textBoxPassword.Text;
                clsUser.uPermissions = textBoxPermissions.Text;
                clsUser.uStates = checkBoxStates.Checked;
                clsUser.uImage = byteImg;
                clsUser.uJob = textBoxJobs.Text;
                clsUser.uDepartment = textBoxDepartments.Text;
                clsUser.uMobile = textBoxuMobile.Text;
                clsUser.uEmail = textBoxstEmail.Text;
                clsUser.STDYears = Convert.ToInt16(numericStdYears.Value);
                clsUser.EXPYears = Convert.ToInt16(numericExpYears.Value);
                clsUser.SpecialtySTD = textBoxStdSpecialty.Text;
                clsUser.SpecialtyEXP = textBoxExpSpecialty.Text;
                clsUser.HireSalary = Convert.ToDecimal(textBoxSalary.Text);
                clsUser.Update(clsUser, "NoMail");

                formDialogOK done = new formDialogOK("عُدلت معلومات الأمين بلا ايميل");
                done.ShowDialog();
            }
            // DELETE
            else if (_ID != 0 && _Delstate)
            {
                formDialogYESNO dialog = new formDialogYESNO($"تأكيد حذف {textBoxuName.Text} ؟");
                dialog.DataBack += Dialog_DataBack;
                dialog.ShowDialog();

                if (_ConfirmDelete)
                {

                    clsUser.Delete(_ID);
                    formDialogOK done = new formDialogOK("حُذفت معلومات الأمين");
                    done.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmDelete;
        private void Dialog_DataBack(object sender, bool Answer)
        {
            _ConfirmDelete = Answer;
        }

        private void _ResetTools()
        {
            textBoxuName.Text = textBoxUsername.Text = textBoxuMobile.Text
                = textBoxstEmail.Text = textBoxPassword.Text = textBoxConfirmPassword.Text
                = string.Empty;
            uImage.Image = null;
            checkBoxStates.Checked = true;
        }

        private void BookCover_Click(object sender, EventArgs e)
        {
            linkLabel1_LinkClicked(null, null);
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)
                && e.KeyChar != Convert.ToChar(CurrentCulture.NumberFormat.NumberDecimalSeparator);
        }

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddCategory addAuthor = new formAddCategory(-5, false);
            addAuthor.labelTitle.Text = "اسم المؤلف";
            addAuthor.buttonAddCategory.Text = "مؤلف";
            addAuthor.ShowDialog();
        }

        private void buttonAddCateg_Click(object sender, EventArgs e)
        {
            formAddCategory addcateg = new formAddCategory();
            addcateg.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "ملفات الصور | *.JPG; *.PNG; *.GIF; *.PMB;";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                uImage.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void buttonAddSchool_Click(object sender, EventArgs e)
        {
            formAddJob addJob = new formAddJob();
            addJob.ShowDialog();

            formAddUsers_Load(null, null);
        }

        private void textBoxstMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBoxstEmail_Validated(object sender, EventArgs e)
        {
            if (!clsDataAccess.EmailCheck(textBoxstEmail.Text.Trim()))
            {
                formDialogMissInfo wrongEmail = new formDialogMissInfo("صيغة بريد الكتروني خاطئة!!");
                wrongEmail.ShowDialog();

                textBoxstEmail.SelectionStart = 0;
                textBoxstEmail.SelectionLength = textBoxstEmail.TextLength;
            }
            else
            {
                return;
            }
        }

        private void comboBoxDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            int depID = clsDepartments.Find(textBoxDepartments.Text).depID;
            comboBoxJob.DataSource = clsUser.LoadJobsByDepartmentID(depID);
            comboBoxJob.DisplayMember = "الوظيفة";
            comboBoxJob.ValueMember = "ت";
            //textBoxDepartments.Text = comboBoxDepartments.Text;
        }

        private void comboBoxJob_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxPermissions_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void formAddUsers_Load(object sender, EventArgs e)
        {
            _FillComboWithDepartments();
            _FillComboWithSpecialties();
            
            _FillComboWithJobs();
            
            _FillComboWithPermissions();
            textBoxSalary.Text = CheckSalary().ToString();
         
            if (_ID == -1)
            {
                comboBoxDepartments.SelectedIndex = comboBoxDepartments.FindString("المبيعات");
                comboBoxPermissions.SelectedIndex = comboBoxPermissions.FindString("مبيعات");
            }
        }

        private void comboBoxDepartments_SelectedValueChanged(object sender, EventArgs e)
        {
        }

        private void buttonAddDepartment_Click(object sender, EventArgs e)
        {
            formAddCategory addDepartment = new formAddCategory(-7, false);
            addDepartment.labelTitle.Text = "إضافة قسم";
            addDepartment.buttonAddCategory.Text = "قسم وظيفي";
            addDepartment.ShowDialog();
            formAddUsers_Load(null, null);
        }

        private void labelSchool_Click(object sender, EventArgs e)
        {

        }

        private void buttonAddPersmission_Click(object sender, EventArgs e)
        {
            formAddCategory addPermission = new formAddCategory(-11, false);
            addPermission.labelTitle.Text = "إضافة صلاحية";
            addPermission.buttonAddCategory.Text = "صلاحية";
            addPermission.ShowDialog();
            formAddUsers_Load(null, null);
        }

        private void textBoxPassword_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxPassword.Text.Trim()))
            {
                formDialogMissInfo wrongEmail = new formDialogMissInfo("كلمة السر مطلوبة!!");
                wrongEmail.ShowDialog();

                textBoxPassword.SelectionStart = 0;
                textBoxPassword.SelectionLength = textBoxPassword.TextLength;
            }
            else
            {
                return;
            }
        }

        private void textBoxConfirmPassword_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (textBoxPassword.Text.Trim() != textBoxConfirmPassword.Text.Trim())
            {
                formDialogMissInfo wrongEmail = new formDialogMissInfo("تطابق حقلي كلمة السر والتأكيد أساسي!!");
                wrongEmail.ShowDialog();

                textBoxConfirmPassword.SelectionStart = 0;
                textBoxConfirmPassword.SelectionLength = textBoxConfirmPassword.TextLength;
            }
            else
            {
                return;
            }
        }

        private void textBoxUsername_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxUsername.Text.Trim()))
            {
                formDialogMissInfo wrongEmail = new formDialogMissInfo("اسم المستخدم للأمين مطلوب!!");
                wrongEmail.ShowDialog();

                textBoxUsername.SelectionStart = 0;
                textBoxUsername.SelectionLength = textBoxUsername.TextLength;
            }
            else
            {
                return;
            }
        }

        private void comboBoxDepartments_SelectionChangeCommitted(object sender, EventArgs e)
        {
            textBoxDepartments.Text = comboBoxDepartments.Text;
        }

        private void formAddUsers_Activated(object sender, EventArgs e)
        {
            _FillComboWithJobs();
        }

        private void comboBoxSpecialtyStd_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxSpecialtyExp_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxSpecialtyStd_SelectionChangeCommitted(object sender, EventArgs e)
        {
            textBoxStdSpecialty.Text = comboBoxSpecialtyStd.Text;

        }

        private void comboBoxSpecialtyExp_SelectionChangeCommitted(object sender, EventArgs e)
        {
            textBoxExpSpecialty.Text = comboBoxSpecialtyExp.Text;

        }

        private void comboBoxJob_SelectionChangeCommitted(object sender, EventArgs e)
        {
            textBoxJobs.Text = comboBoxJob.Text;

        }

        private void comboBoxPermissions_SelectionChangeCommitted(object sender, EventArgs e)
        {
            textBoxPermissions.Text = comboBoxPermissions.Text;

        }

        private void numericStdYears_ValueChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void numericExpYears_ValueChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            uImage.Image = null;
        }

        private void buttonAddSpecialty_Click(object sender, EventArgs e)
        {
            formAddCategory addSpecialty = new formAddCategory(-3, false);
            addSpecialty.labelTitle.Text = "عنوان التخصص";
            addSpecialty.buttonAddCategory.Text = "تخصص";
            addSpecialty.ShowDialog();
            formAddUsers_Load(null, null);

        }

        private void buttonAddSpecialties_Click(object sender, EventArgs e)
        {
            buttonAddSpecialty.PerformClick();
        }
    }

}
