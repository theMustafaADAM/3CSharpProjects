﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formBooksList : Form
    {
        public formBooksList()
        {
            InitializeComponent();
            SelectMode = false;
        }

        public bool SelectMode = false;

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridViewBooks_DoubleClick(object sender, EventArgs e)
        {
            string BookSelected = (string)dataGridViewBooks.CurrentRow.Cells["عنوان الكتاب"].Value;

            formDialogYESNO dialogYESNO = new formDialogYESNO($"هل تريد اختيار الكتاب : {BookSelected} ؟");

            dialogYESNO.DataBack += DialogYESNO_DataBack;

            dialogYESNO.ShowDialog();

            if (!_ConfirmSelect) return;
            else
            {
                // after select
                SelectMode = true;
                this.Close();
            }
        }

        bool _ConfirmSelect;
        private void DialogYESNO_DataBack(object sender, bool Answer)
        {
            _ConfirmSelect = Answer;
        }

        clsBooks clsbook = new clsBooks();

        private void formBooksList_Load(object sender, EventArgs e)
        {
            dataGridViewBooks.DataSource = clsbook.LoadFullBooks();
            dataGridViewBooks.RowHeadersWidth = 25;
            dataGridViewBooks.Columns["ت"].Width = 40;
            dataGridViewBooks.Columns["عنوان الكتاب"].Width = 170;
            dataGridViewBooks.Columns["غلاف الكتاب"].Visible = false;
            //dataGridViewBooks.Columns["الكمية"].Visible = false;
            //dataGridViewBooks.Columns["السعر"].Visible = false;
            dataGridViewBooks.Columns["التقييم"].Visible = false;
            dataGridViewBooks.ClearSelection();
        }
    }
}