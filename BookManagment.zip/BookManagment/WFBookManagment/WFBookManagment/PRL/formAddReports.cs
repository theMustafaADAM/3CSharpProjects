﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formAddReports : Form
    {        
        public formAddReports()
        {
            InitializeComponent();
            label1ReportDate.Text = DateTime.Now.ToLongDateString();
            labelReportUser.Text = Program.UserName;
            _FillLabelWithItemsCounts();
            _LoadAllUsers();
        }

        // Var Form BLL
        clsCategories clsCategory = new clsCategories();
        clsBooks clsbooks = new clsBooks();
        clsStudents clsstudent = new clsStudents();
        clsSales clsSale = new clsSales();
        clsBorrow clborrow = new clsBorrow();
        clsUsers clsUser = new clsUsers();

        private void _FillLabelWithItemsCounts()
        {
            //Books==================================================
            DataTable dtcBooks = clsbooks.LoadFullBooks();
            labelCountBooks.Text = dtcBooks.Rows.Count.ToString();
            //Students==================================================
            DataTable dtcStudents = clsstudent.LoadStudents();
            labelCountStudents.Text = dtcStudents.Rows.Count.ToString();
            //Sales==================================================
            DataTable dtcSales = clsSale.GetSales();
            labelCountSales.Text = dtcSales.Rows.Count.ToString();
            //Borrows==================================================
            DataTable dtcBorrows = clborrow.GetBorrows();
            labelCountBorrows.Text = dtcBorrows.Rows.Count.ToString();
            //Categories==================================================
            DataTable dtcCategories = clsCategory.LoadData();
            labelCountCategories.Text = dtcCategories.Rows.Count.ToString();
            //Users==================================================
            DataTable dtcUsers = clsUser.LoadUsers();
            labelCountUsers.Text = dtcUsers.Rows.Count.ToString();
        }

        private void _LoadAllUsers()
        {
            try
            {
                // Load Books Data
                DataTable dtUsers = clsUser.LoadUsers();
                dataGridViewMain.DataSource = dtUsers;
                labelCountUsers.Text = dtUsers.Rows.Count.ToString();
                dataGridViewMain.RowHeadersWidth = 25;
                dataGridViewMain.Columns["ت"].Visible = false;
                dataGridViewMain.Columns["الأمين"].Visible = true;
                dataGridViewMain.Columns["القسم"].Visible = true;
                dataGridViewMain.Columns["الجوال"].Visible = false;
                dataGridViewMain.Columns["الوظيفة"].Visible = true;
                dataGridViewMain.Columns["الايميل"].Visible = false;
                dataGridViewMain.Columns["الدراسة"].Visible = false;
                dataGridViewMain.Columns["الخبرة"].Visible = false;
                dataGridViewMain.Columns["تخصص الدراسة"].Visible = true;
                dataGridViewMain.Columns["تخصص الخبرة"].Visible = true;
                dataGridViewMain.Columns["راتب التعيين"].Visible = false;
                dataGridViewMain.Columns["الصورة"].Visible = false;
                dataGridViewMain.Columns["Password"].Visible = false;
                dataGridViewMain.Columns["الصلاحيات"].Visible = false;
                dataGridViewMain.Columns["المستخدم"].Visible = false;
                dataGridViewMain.Columns["الحالة"].Visible = false;
                dataGridViewMain.ClearSelection();
            }
            catch (Exception ex)
            {
                formDialogFail missInfo = new formDialogFail(ex.Message);
                missInfo.ShowDialog();
                return;
            }
        }

        private void buttonPrintSettings_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void buttonPrintPreview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void buttonPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap img = new Bitmap(splitContainer1.Panel2.Width, 
                splitContainer1.Panel2.Height);

            splitContainer1.Panel2.DrawToBitmap(img, 
                new Rectangle(Point.Empty, splitContainer1.Panel2.Size));

            e.Graphics.DrawImage(img, 50, 100);
        }
    }
}
