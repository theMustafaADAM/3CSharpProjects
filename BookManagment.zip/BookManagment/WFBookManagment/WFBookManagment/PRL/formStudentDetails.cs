﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using WFBookManagment.DAL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formStudentDetails : Form
    {
        public formStudentDetails()
        {
            InitializeComponent();
        }
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
    }
}
