﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFBookManagment.PRL
{
    public partial class formDialogYESNO : Form
    {
        // to Declare a delegate
        // the Caller = sender
        // the Wanted Data = bool answer
        public delegate void DataBackEventHandler(object sender, bool Answer);

        // to Declare an event to use the delegate
        // Make an Instance from it
        public event DataBackEventHandler DataBack;

        private bool _Answer;

        public formDialogYESNO()
        {
            InitializeComponent();
        }

        public formDialogYESNO(string Question)
        {
            InitializeComponent();
            labelQuestion.Text = Question;
        }
        private void timerNotification_Tick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnYES_Click(object sender, EventArgs e)
        {
            _Answer = true;
            // to Trigger the event to send back data to caller form
            DataBack?.Invoke(this, _Answer);

            this.Close();
        }

        private void btnNO_Click(object sender, EventArgs e)
        {
            _Answer = false;

            // to Trigger the event to send back data to caller form
            DataBack?.Invoke(this, _Answer);

            this.Close();
        }
    }
}
