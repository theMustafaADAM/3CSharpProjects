﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formAddJob : Form
    {
        public formAddJob()
        {
            InitializeComponent();
            textBoxSalary.Text = CheckSalary().ToString();
        }

        clsUsers clsUser = new clsUsers();
        private void _FillComboWithDepartments()
        {
            comboBoxDepartments.DataSource = clsUsers.LoadDepartments();
            comboBoxDepartments.DisplayMember = "القسم";
            comboBoxDepartments.ValueMember = "ت";

        }

        //private bool _Delstate;
        //private int _ID;

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)
                && e.KeyChar != Convert.ToChar(CurrentCulture.NumberFormat.NumberDecimalSeparator);
        }

        public decimal CheckSalary()
        {
            decimal salary = 0;
            // رواتب الشهادة المنخفضة
            if ((rBstd09Years.Checked) && (rBexp03Years.Checked)) salary = 3000;
            else if ((rBstd09Years.Checked) && (rBexp47Years.Checked)) salary = 5000;
            else if ((rBstd09Years.Checked) && (rBexp8YearsPlus.Checked)) salary = 7000;
            // رواتب الشهادة الجامعية
            else if ((rBstd1016Years.Checked) && (rBexp03Years.Checked)) salary = 7000;
            else if ((rBstd1016Years.Checked) && (rBexp47Years.Checked)) salary = 9000;
            else if ((rBstd1016Years.Checked) && (rBexp8YearsPlus.Checked)) salary = 11000;
            // رواتب الشهادات العليا
            else if ((rBstd17YearsPlus.Checked) && (rBexp03Years.Checked)) salary = 9000;
            else if ((rBstd17YearsPlus.Checked) && (rBexp47Years.Checked)) salary = 11000;
            else if ((rBstd17YearsPlus.Checked) && (rBexp8YearsPlus.Checked)) salary = 13000;

            else salary = 0;
            return salary;
        }

        private void rBstd09Years_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void rBstd1016Years_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void rBstd17YearsPlus_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void rBexp03Years_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void rBexp47Years_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void rBexp8YearsPlus_CheckedChanged(object sender, EventArgs e)
        {
            textBoxSalary.Text = CheckSalary().ToString();
        }

        private void formAddJob_Load(object sender, EventArgs e)
        {
            _FillComboWithDepartments();
            textBoxDepartments.Text = comboBoxDepartments.Text;
            textBoxDepID.Text = comboBoxDepartments.SelectedValue.ToString();
        }

        private void comboBoxDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxDepartments.Text = comboBoxDepartments.Text;
            textBoxDepID.Text = comboBoxDepartments.SelectedValue.ToString();
        }

        clsJobs clsJob = new clsJobs();

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            if (textBoxDepartments.Text == string.Empty ||
                textBoxDepID.Text == string.Empty ||
                textBoxJobTitle.Text == string.Empty)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo();
                missInfo.ShowDialog();
                return;
            }

            clsJob = new clsJobs();
            clsJob.depID = Convert.ToInt16(textBoxDepID.Text);
            clsJob.jobName = textBoxJobTitle.Text;
            clsJob.Insert(clsJob);

            formDialogOK dialogOK = new formDialogOK("حُفظت الوظيفة");
            dialogOK.ShowDialog();

            this.Close();
        }
    }
}
