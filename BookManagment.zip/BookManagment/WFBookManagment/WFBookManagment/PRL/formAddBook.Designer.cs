﻿namespace WFBookManagment.PRL
{
    partial class formAddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddBook));
            this.buttonExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxBookTitle = new System.Windows.Forms.TextBox();
            this.buttonAddBook = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.comboBoxAuthor = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxCategories = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.numericRate = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.BookCover = new System.Windows.Forms.PictureBox();
            this.linkLabelCover = new System.Windows.Forms.LinkLabel();
            this.buttonAddAuth = new System.Windows.Forms.Button();
            this.buttonAddCateg = new System.Windows.Forms.Button();
            this.textBoxPublish = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.numericQty = new System.Windows.Forms.NumericUpDown();
            this.textBoxCategory = new System.Windows.Forms.TextBox();
            this.textBoxAuthor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxAuthID = new System.Windows.Forms.TextBox();
            this.textBoxCategID = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.numericRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookCover)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericQty)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(60, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "عنوان الكتاب :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxBookTitle
            // 
            this.textBoxBookTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxBookTitle.Location = new System.Drawing.Point(60, 91);
            this.textBoxBookTitle.Multiline = true;
            this.textBoxBookTitle.Name = "textBoxBookTitle";
            this.textBoxBookTitle.Size = new System.Drawing.Size(680, 60);
            this.textBoxBookTitle.TabIndex = 0;
            // 
            // buttonAddBook
            // 
            this.buttonAddBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddBook.FlatAppearance.BorderSize = 0;
            this.buttonAddBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddBook.ForeColor = System.Drawing.Color.Black;
            this.buttonAddBook.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddBook.Location = new System.Drawing.Point(60, 660);
            this.buttonAddBook.Name = "buttonAddBook";
            this.buttonAddBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddBook.Size = new System.Drawing.Size(680, 40);
            this.buttonAddBook.TabIndex = 1;
            this.buttonAddBook.Text = "كتاب";
            this.buttonAddBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddBook.UseVisualStyleBackColor = false;
            this.buttonAddBook.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(60, 360);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "سعر الكتاب :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPrice.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxPrice.Location = new System.Drawing.Point(60, 400);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(329, 37);
            this.textBoxPrice.TabIndex = 4;
            this.textBoxPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPrice_KeyPress);
            // 
            // comboBoxAuthor
            // 
            this.comboBoxAuthor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAuthor.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxAuthor.FormattingEnabled = true;
            this.comboBoxAuthor.Location = new System.Drawing.Point(60, 200);
            this.comboBoxAuthor.Name = "comboBoxAuthor";
            this.comboBoxAuthor.Size = new System.Drawing.Size(285, 38);
            this.comboBoxAuthor.TabIndex = 6;
            this.comboBoxAuthor.SelectedIndexChanged += new System.EventHandler(this.comboBoxAuthor_SelectedIndexChanged);
            this.comboBoxAuthor.Click += new System.EventHandler(this.comboBoxAuthor_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label3.Location = new System.Drawing.Point(60, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(330, 36);
            this.label3.TabIndex = 7;
            this.label3.Text = "لائحة المؤلفين :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(60, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "لائحة الفئات :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBoxCategories
            // 
            this.comboBoxCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategories.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxCategories.FormattingEnabled = true;
            this.comboBoxCategories.Location = new System.Drawing.Point(60, 300);
            this.comboBoxCategories.Name = "comboBoxCategories";
            this.comboBoxCategories.Size = new System.Drawing.Size(285, 38);
            this.comboBoxCategories.TabIndex = 8;
            this.comboBoxCategories.SelectedIndexChanged += new System.EventHandler(this.comboBoxCategories_SelectedIndexChanged);
            this.comboBoxCategories.Click += new System.EventHandler(this.comboBoxCategories_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label5.Location = new System.Drawing.Point(60, 550);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 36);
            this.label5.TabIndex = 10;
            this.label5.Text = "تقييم الكتاب :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericRate
            // 
            this.numericRate.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.numericRate.Location = new System.Drawing.Point(60, 590);
            this.numericRate.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericRate.Name = "numericRate";
            this.numericRate.Size = new System.Drawing.Size(160, 37);
            this.numericRate.TabIndex = 11;
            this.numericRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label6.Location = new System.Drawing.Point(60, 455);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(330, 36);
            this.label6.TabIndex = 12;
            this.label6.Text = "الطبعة وتاريخ النشر :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookCover
            // 
            this.BookCover.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.BookCover.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BookCover.Image = global::WFBookManagment.Properties.Resources.a_book0;
            this.BookCover.Location = new System.Drawing.Point(410, 400);
            this.BookCover.Name = "BookCover";
            this.BookCover.Size = new System.Drawing.Size(330, 230);
            this.BookCover.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BookCover.TabIndex = 15;
            this.BookCover.TabStop = false;
            this.BookCover.Click += new System.EventHandler(this.BookCover_Click);
            // 
            // linkLabelCover
            // 
            this.linkLabelCover.AutoSize = true;
            this.linkLabelCover.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabelCover.Location = new System.Drawing.Point(411, 360);
            this.linkLabelCover.Name = "linkLabelCover";
            this.linkLabelCover.Size = new System.Drawing.Size(194, 36);
            this.linkLabelCover.TabIndex = 16;
            this.linkLabelCover.TabStop = true;
            this.linkLabelCover.Text = "اضغط لتحميل الغلاف";
            this.linkLabelCover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabelCover.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // buttonAddAuth
            // 
            this.buttonAddAuth.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddAuth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddAuth.FlatAppearance.BorderSize = 0;
            this.buttonAddAuth.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddAuth.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddAuth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddAuth.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddAuth.ForeColor = System.Drawing.Color.Black;
            this.buttonAddAuth.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddAuth.Image")));
            this.buttonAddAuth.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddAuth.Location = new System.Drawing.Point(350, 200);
            this.buttonAddAuth.Name = "buttonAddAuth";
            this.buttonAddAuth.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddAuth.Size = new System.Drawing.Size(39, 40);
            this.buttonAddAuth.TabIndex = 17;
            this.buttonAddAuth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddAuth.UseVisualStyleBackColor = false;
            this.buttonAddAuth.Click += new System.EventHandler(this.buttonAddAuth_Click);
            // 
            // buttonAddCateg
            // 
            this.buttonAddCateg.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddCateg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddCateg.FlatAppearance.BorderSize = 0;
            this.buttonAddCateg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCateg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCateg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCateg.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCateg.ForeColor = System.Drawing.Color.Black;
            this.buttonAddCateg.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddCateg.Image")));
            this.buttonAddCateg.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCateg.Location = new System.Drawing.Point(350, 300);
            this.buttonAddCateg.Name = "buttonAddCateg";
            this.buttonAddCateg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddCateg.Size = new System.Drawing.Size(39, 40);
            this.buttonAddCateg.TabIndex = 18;
            this.buttonAddCateg.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddCateg.UseVisualStyleBackColor = false;
            this.buttonAddCateg.Click += new System.EventHandler(this.buttonAddCateg_Click);
            // 
            // textBoxPublish
            // 
            this.textBoxPublish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPublish.Location = new System.Drawing.Point(60, 495);
            this.textBoxPublish.Name = "textBoxPublish";
            this.textBoxPublish.Size = new System.Drawing.Size(329, 43);
            this.textBoxPublish.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label7.Location = new System.Drawing.Point(231, 550);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 36);
            this.label7.TabIndex = 21;
            this.label7.Text = "الكمية :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numericQty
            // 
            this.numericQty.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.numericQty.Location = new System.Drawing.Point(230, 590);
            this.numericQty.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numericQty.Name = "numericQty";
            this.numericQty.Size = new System.Drawing.Size(160, 37);
            this.numericQty.TabIndex = 22;
            this.numericQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // textBoxCategory
            // 
            this.textBoxCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCategory.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxCategory.Location = new System.Drawing.Point(473, 300);
            this.textBoxCategory.Name = "textBoxCategory";
            this.textBoxCategory.ReadOnly = true;
            this.textBoxCategory.Size = new System.Drawing.Size(265, 40);
            this.textBoxCategory.TabIndex = 23;
            this.textBoxCategory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxAuthor
            // 
            this.textBoxAuthor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAuthor.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxAuthor.Location = new System.Drawing.Point(473, 200);
            this.textBoxAuthor.Name = "textBoxAuthor";
            this.textBoxAuthor.ReadOnly = true;
            this.textBoxAuthor.Size = new System.Drawing.Size(265, 40);
            this.textBoxAuthor.TabIndex = 24;
            this.textBoxAuthor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label8.Location = new System.Drawing.Point(410, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(330, 36);
            this.label8.TabIndex = 25;
            this.label8.Text = "مؤلف الكتاب :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label9.Location = new System.Drawing.Point(410, 260);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(330, 36);
            this.label9.TabIndex = 26;
            this.label9.Text = "فئة الكتاب :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxAuthID
            // 
            this.textBoxAuthID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAuthID.Font = new System.Drawing.Font("Simplified Arabic Fixed", 22F);
            this.textBoxAuthID.Location = new System.Drawing.Point(410, 200);
            this.textBoxAuthID.Name = "textBoxAuthID";
            this.textBoxAuthID.ReadOnly = true;
            this.textBoxAuthID.Size = new System.Drawing.Size(60, 40);
            this.textBoxAuthID.TabIndex = 28;
            this.textBoxAuthID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCategID
            // 
            this.textBoxCategID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxCategID.Font = new System.Drawing.Font("Simplified Arabic Fixed", 22F);
            this.textBoxCategID.Location = new System.Drawing.Point(410, 300);
            this.textBoxCategID.Name = "textBoxCategID";
            this.textBoxCategID.ReadOnly = true;
            this.textBoxCategID.Size = new System.Drawing.Size(60, 40);
            this.textBoxCategID.TabIndex = 27;
            this.textBoxCategID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.LinkColor = System.Drawing.Color.Navy;
            this.linkLabel1.Location = new System.Drawing.Point(688, 360);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(51, 36);
            this.linkLabel1.TabIndex = 29;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "إزالة";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // formAddBook
            // 
            this.AcceptButton = this.buttonAddBook;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(800, 730);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.textBoxAuthID);
            this.Controls.Add(this.textBoxCategID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxAuthor);
            this.Controls.Add(this.textBoxCategory);
            this.Controls.Add(this.numericQty);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxPublish);
            this.Controls.Add(this.buttonAddCateg);
            this.Controls.Add(this.buttonAddAuth);
            this.Controls.Add(this.linkLabelCover);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.BookCover);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numericRate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxCategories);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxAuthor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.buttonAddBook);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxBookTitle);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(215, 100);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddBook";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            this.Activated += new System.EventHandler(this.formAddBook_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.numericRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookCover)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button buttonAddBook;
        public System.Windows.Forms.TextBox textBoxBookTitle;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBoxPrice;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button buttonAddAuth;
        public System.Windows.Forms.Button buttonAddCateg;
        public System.Windows.Forms.ComboBox comboBoxAuthor;
        public System.Windows.Forms.ComboBox comboBoxCategories;
        public System.Windows.Forms.PictureBox BookCover;
        public System.Windows.Forms.LinkLabel linkLabelCover;
        public System.Windows.Forms.TextBox textBoxPublish;
        public System.Windows.Forms.NumericUpDown numericRate;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.NumericUpDown numericQty;
        public System.Windows.Forms.TextBox textBoxCategory;
        public System.Windows.Forms.TextBox textBoxAuthor;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox textBoxAuthID;
        public System.Windows.Forms.TextBox textBoxCategID;
        public System.Windows.Forms.LinkLabel linkLabel1;
    }
}