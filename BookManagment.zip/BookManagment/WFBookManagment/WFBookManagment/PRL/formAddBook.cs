﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formAddBook : Form
    {
        public formAddBook(int ID, bool Stt)
        {
            if (ID == 0)
            {
                InitializeComponent();
                _FillComboWithCategories();
                _FillComboWithAuthors();
                _ID = ID;
                _Delstate = Stt;
            }
            else
            {
                InitializeComponent();
                _FillComboWithCategories();
                _FillComboWithAuthors();
                _ID = ID;
                _Delstate = Stt;
                DataTable dtAuthName = clsBook.GetAuthorByBookID(_ID);
                var authName = dtAuthName.Rows[0][0].ToString();
                comboBoxAuthor.SelectedItem = comboBoxAuthor.FindString(authName).ToString();

                DataTable dtctgName = clsBook.GetCategoryByBookID(_ID);
                var ctgName = dtctgName.Rows[0][0].ToString();
                comboBoxCategories.SelectedItem = comboBoxCategories.FindString(ctgName).ToString();

                if (_Delstate)
                {
                    numericRate.Enabled = comboBoxAuthor.Enabled = comboBoxCategories.Enabled =
                        buttonAddAuth.Enabled = buttonAddCateg.Enabled = textBoxPublish.Enabled =
                        linkLabelCover.Enabled = BookCover.Enabled = false;
                    comboBoxCategories.Text = comboBoxAuthor.Text = string.Empty;
                }
            }
        }
        public formAddBook()
        {
            InitializeComponent();
            _FillComboWithAuthors();
            _FillComboWithCategories();
        }

        private void _FillComboWithAuthors()
        {
            comboBoxAuthor.DataSource = clsBook.LoadAuthors();
            comboBoxAuthor.DisplayMember = "AuthName";
            comboBoxAuthor.ValueMember = "AuthID";

        }

        private void _FillComboWithCategories()
        {
            comboBoxCategories.DataSource = clsCategory.LoadData();
            comboBoxCategories.DisplayMember = "الفئة";
            comboBoxCategories.ValueMember = "ت";
        }


        private bool _Delstate;
        private int _ID;
        public int aindx;
        public int cindx;
        MemoryStream stream;
        byte[] byteImg;
        clsCategories clsCategory = new clsCategories();
        clsBooks clsBook = new clsBooks();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (textBoxBookTitle.Text == string.Empty || textBoxPrice.Text == string.Empty
                || comboBoxAuthor.Text == string.Empty || comboBoxCategories.Text == string.Empty
                || numericQty.Value == 0)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo();
                missInfo.ShowDialog();
                return;
            }
            // INSERT
            if (_ID == 0)
            {
                stream = new MemoryStream();
                BookCover.Image.Save(stream, BookCover.Image.RawFormat);
                byteImg = stream.ToArray();

                clsBook = new clsBooks();
                clsBook.bookTitle = textBoxBookTitle.Text;
                clsBook.bookCategID = Convert.ToInt16(textBoxCategID.Text);
                clsBook.bookCategName = textBoxCategory.Text;
                clsBook.AuthID = Convert.ToInt16(textBoxAuthID.Text);
                clsBook.AuthName = textBoxAuthor.Text;
                clsBook.bookPrice = Convert.ToDecimal(textBoxPrice.Text);
                clsBook.bookQty = Convert.ToInt16(numericQty.Value);
                clsBook.PublishDate = textBoxPublish.Text;
                clsBook.bookRate = Convert.ToInt16(numericRate.Value);
                clsBook.bookCover = byteImg;
                clsBook.Insert(clsBook);
                formDialogOK done = new formDialogOK("حُفظ الكتاب بنجاح");
                done.ShowDialog();
                this.Close();
            }
            // UPDATE
            else if (_ID != 0 && !_Delstate)
            {
                stream = new MemoryStream();
                BookCover.Image.Save(stream, BookCover.Image.RawFormat);
                byteImg = stream.ToArray();

                clsBook = new clsBooks();
                clsBook.bookTitle = textBoxBookTitle.Text;
                clsBook.bookCategID = Convert.ToInt16(textBoxCategID.Text);
                clsBook.bookCategName = textBoxCategory.Text;
                clsBook.AuthID = Convert.ToInt16(textBoxAuthID.Text);
                clsBook.AuthName = textBoxAuthor.Text;
                clsBook.bookPrice = Convert.ToDecimal(textBoxPrice.Text);
                clsBook.bookQty = Convert.ToInt16(numericQty.Value);
                clsBook.PublishDate = textBoxPublish.Text;
                clsBook.bookRate = Convert.ToInt16(numericRate.Value);
                clsBook.bookCover = byteImg;
                clsBook.bookID = _ID;
                clsBook.Update(clsBook);
                formDialogOK done = new formDialogOK("عُدل الكتاب بنجاح");
                done.ShowDialog();
                this.Close();
            }
            // DELETE
            else if (_ID != 0 && _Delstate)
            {
                formDialogYESNO dialog = new formDialogYESNO($"تأكيد حذف {textBoxBookTitle.Text} ؟");
                dialog.DataBack += Dialog_DataBack;
                dialog.ShowDialog();

                if (_ConfirmDelete)
                {
                    clsBook.Delete(_ID);
                    formDialogOK done = new formDialogOK("حُذف الكتاب بنجاح");
                    done.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmDelete;

        private void Dialog_DataBack(object sender, bool Answer)
        {
            _ConfirmDelete = Answer;
        }

        private void BookCover_Click(object sender, EventArgs e)
        {
            linkLabel1_LinkClicked(null, null);
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)
                && e.KeyChar != Convert.ToChar(CurrentCulture.NumberFormat.NumberDecimalSeparator);
        }

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddCategory addAuthor = new formAddCategory(-5, false);
            addAuthor.labelTitle.Text = "اسم المؤلف";
            addAuthor.buttonAddCategory.Text = "مؤلف";
            addAuthor.ShowDialog();
        }

        private void formAddBook_Activated(object sender, EventArgs e)
        {
            if (_ID == 0)
            {
                _FillComboWithAuthors();
                _FillComboWithCategories();
            }
            else return;
        }

        private void buttonAddCateg_Click(object sender, EventArgs e)
        {
            formAddCategory addcateg = new formAddCategory();
            addcateg.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "ملفات الصور | *.JPG; *.PNG; *.GIF; *.PMB;";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                BookCover.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void comboBoxAuthor_Click(object sender, EventArgs e)
        {
        }

        private void comboBoxCategories_Click(object sender, EventArgs e)
        {
        }

        private void comboBoxCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxCategID.Text = comboBoxCategories.SelectedValue.ToString();
            textBoxCategory.Text = comboBoxCategories.Text.ToString();
        }

        private void comboBoxAuthor_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxAuthID.Text = comboBoxAuthor.SelectedValue.ToString();
            textBoxAuthor.Text = comboBoxAuthor.Text.ToString();
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BookCover.Image = null;
        }
    }
}
