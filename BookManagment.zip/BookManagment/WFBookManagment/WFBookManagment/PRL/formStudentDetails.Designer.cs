﻿namespace WFBookManagment.PRL
{
    partial class formStudentDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formStudentDetails));
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxstAddress = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabelCover = new System.Windows.Forms.LinkLabel();
            this.textBoxstEmail = new System.Windows.Forms.TextBox();
            this.textBoxstName = new System.Windows.Forms.TextBox();
            this.textBoxstMobile = new System.Windows.Forms.TextBox();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.stImage = new System.Windows.Forms.PictureBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.textBoxSchool = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.stImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(56, 250);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(330, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "عنوان الطالب :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxstAddress
            // 
            this.textBoxstAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstAddress.Location = new System.Drawing.Point(56, 289);
            this.textBoxstAddress.Multiline = true;
            this.textBoxstAddress.Name = "textBoxstAddress";
            this.textBoxstAddress.ReadOnly = true;
            this.textBoxstAddress.Size = new System.Drawing.Size(330, 120);
            this.textBoxstAddress.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(414, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "المدرسة أو  الكلية :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label3.Location = new System.Drawing.Point(56, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(330, 36);
            this.label3.TabIndex = 7;
            this.label3.Text = "اسم الطالب :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(56, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "رقم الهاتف الجوال :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label6.Location = new System.Drawing.Point(56, 426);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(330, 36);
            this.label6.TabIndex = 12;
            this.label6.Text = "البريد الالكتروني :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabelCover
            // 
            this.linkLabelCover.Enabled = false;
            this.linkLabelCover.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabelCover.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.linkLabelCover.Location = new System.Drawing.Point(414, 146);
            this.linkLabelCover.Name = "linkLabelCover";
            this.linkLabelCover.Size = new System.Drawing.Size(330, 36);
            this.linkLabelCover.TabIndex = 6;
            this.linkLabelCover.TabStop = true;
            this.linkLabelCover.Text = "صورة الطالب (إن وجدت)";
            this.linkLabelCover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxstEmail
            // 
            this.textBoxstEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstEmail.Location = new System.Drawing.Point(56, 465);
            this.textBoxstEmail.Name = "textBoxstEmail";
            this.textBoxstEmail.ReadOnly = true;
            this.textBoxstEmail.Size = new System.Drawing.Size(330, 43);
            this.textBoxstEmail.TabIndex = 3;
            // 
            // textBoxstName
            // 
            this.textBoxstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstName.Location = new System.Drawing.Point(56, 82);
            this.textBoxstName.Name = "textBoxstName";
            this.textBoxstName.ReadOnly = true;
            this.textBoxstName.Size = new System.Drawing.Size(330, 43);
            this.textBoxstName.TabIndex = 0;
            // 
            // textBoxstMobile
            // 
            this.textBoxstMobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstMobile.Font = new System.Drawing.Font("Simplified Arabic Fixed", 18F);
            this.textBoxstMobile.Location = new System.Drawing.Point(56, 186);
            this.textBoxstMobile.Name = "textBoxstMobile";
            this.textBoxstMobile.ReadOnly = true;
            this.textBoxstMobile.Size = new System.Drawing.Size(330, 34);
            this.textBoxstMobile.TabIndex = 1;
            this.textBoxstMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddStudent.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddStudent.FlatAppearance.BorderSize = 0;
            this.buttonAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddStudent.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddStudent.ForeColor = System.Drawing.Color.Black;
            this.buttonAddStudent.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(414, 468);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddStudent.Size = new System.Drawing.Size(330, 40);
            this.buttonAddStudent.TabIndex = 7;
            this.buttonAddStudent.Text = "طالب";
            this.buttonAddStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddStudent.UseVisualStyleBackColor = false;
            this.buttonAddStudent.Visible = false;
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // stImage
            // 
            this.stImage.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.stImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stImage.Enabled = false;
            this.stImage.Image = global::WFBookManagment.Properties.Resources.افريقية;
            this.stImage.Location = new System.Drawing.Point(414, 190);
            this.stImage.Name = "stImage";
            this.stImage.Size = new System.Drawing.Size(330, 219);
            this.stImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stImage.TabIndex = 15;
            this.stImage.TabStop = false;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // textBoxSchool
            // 
            this.textBoxSchool.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSchool.Location = new System.Drawing.Point(414, 82);
            this.textBoxSchool.Name = "textBoxSchool";
            this.textBoxSchool.ReadOnly = true;
            this.textBoxSchool.Size = new System.Drawing.Size(330, 43);
            this.textBoxSchool.TabIndex = 16;
            // 
            // formStudentDetails
            // 
            this.AcceptButton = this.buttonAddStudent;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.textBoxSchool);
            this.Controls.Add(this.textBoxstMobile);
            this.Controls.Add(this.textBoxstName);
            this.Controls.Add(this.textBoxstEmail);
            this.Controls.Add(this.linkLabelCover);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.stImage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAddStudent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxstAddress);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(215, 120);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formStudentDetails";
            this.Opacity = 0.9D;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            ((System.ComponentModel.ISupportInitialize)(this.stImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button buttonAddStudent;
        public System.Windows.Forms.TextBox textBoxstAddress;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.PictureBox stImage;
        public System.Windows.Forms.LinkLabel linkLabelCover;
        public System.Windows.Forms.TextBox textBoxstEmail;
        public System.Windows.Forms.TextBox textBoxstName;
        public System.Windows.Forms.TextBox textBoxstMobile;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        public System.Windows.Forms.TextBox textBoxSchool;
    }
}