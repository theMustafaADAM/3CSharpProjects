﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;

namespace WFBookManagment.PRL
{
    public partial class formShowBookSale : Form
    {
        public formShowBookSale(int ID)
        {
            InitializeComponent();
            _ID = ID;
            DataTable dtSaleDetails = clsSaleDetail.GetSaleDetails(_ID);
            dataGridViewBooks.DataSource = dtSaleDetails;
            dataGridViewBooks.RowHeadersWidth = 20;
            dataGridViewBooks.Columns["ت"].Width = 70;
            dataGridViewBooks.Columns["الكتاب"].Width = 240; 
        }

        private int _ID;
        clsSaleDetails clsSaleDetail = new clsSaleDetails();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
