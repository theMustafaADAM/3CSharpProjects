﻿namespace WFBookManagment.PRL
{
    partial class formAddReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddReports));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labelReportTitle = new System.Windows.Forms.Label();
            this.buttonPrint = new System.Windows.Forms.Button();
            this.buttonPrintPreview = new System.Windows.Forms.Button();
            this.buttonPrintSettings = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelCategoriesPox = new System.Windows.Forms.Panel();
            this.labelCountCategories = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelCountBooks = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelCountUsers = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelCountStudents = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelCountSales = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelCountBorrows = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelReportPagesTitle = new System.Windows.Forms.Label();
            this.labelReportUser = new System.Windows.Forms.Label();
            this.label1ReportDate = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.dataGridViewMain = new System.Windows.Forms.DataGridView();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelCategoriesPox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.labelTitle);
            this.splitContainer1.Panel1.Controls.Add(this.buttonPrint);
            this.splitContainer1.Panel1.Controls.Add(this.buttonPrintPreview);
            this.splitContainer1.Panel1.Controls.Add(this.buttonPrintSettings);
            this.splitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.splitContainer1.Panel2.Controls.Add(this.label26);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Panel2.Controls.Add(this.panelCategoriesPox);
            this.splitContainer1.Panel2.Controls.Add(this.labelReportTitle);
            this.splitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer1.Size = new System.Drawing.Size(704, 881);
            this.splitContainer1.SplitterDistance = 70;
            this.splitContainer1.TabIndex = 30;
            // 
            // labelReportTitle
            // 
            this.labelReportTitle.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReportTitle.ForeColor = System.Drawing.Color.Black;
            this.labelReportTitle.Location = new System.Drawing.Point(32, 9);
            this.labelReportTitle.Name = "labelReportTitle";
            this.labelReportTitle.Size = new System.Drawing.Size(640, 36);
            this.labelReportTitle.TabIndex = 32;
            this.labelReportTitle.Text = "التقرير العام ";
            this.labelReportTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonPrint
            // 
            this.buttonPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonPrint.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPrint.FlatAppearance.BorderSize = 0;
            this.buttonPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPrint.Font = new System.Drawing.Font("Cairo", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrint.ForeColor = System.Drawing.Color.Black;
            this.buttonPrint.Image = global::WFBookManagment.Properties.Resources.Print;
            this.buttonPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPrint.Location = new System.Drawing.Point(339, 20);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonPrint.Size = new System.Drawing.Size(100, 40);
            this.buttonPrint.TabIndex = 33;
            this.buttonPrint.Text = "طباعة";
            this.buttonPrint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonPrint.UseVisualStyleBackColor = false;
            this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
            // 
            // buttonPrintPreview
            // 
            this.buttonPrintPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonPrintPreview.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonPrintPreview.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPrintPreview.FlatAppearance.BorderSize = 0;
            this.buttonPrintPreview.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonPrintPreview.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonPrintPreview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPrintPreview.Font = new System.Drawing.Font("Cairo", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrintPreview.ForeColor = System.Drawing.Color.Black;
            this.buttonPrintPreview.Image = global::WFBookManagment.Properties.Resources.Preview_Pane;
            this.buttonPrintPreview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPrintPreview.Location = new System.Drawing.Point(445, 20);
            this.buttonPrintPreview.Name = "buttonPrintPreview";
            this.buttonPrintPreview.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonPrintPreview.Size = new System.Drawing.Size(100, 40);
            this.buttonPrintPreview.TabIndex = 32;
            this.buttonPrintPreview.Text = "معاينة";
            this.buttonPrintPreview.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonPrintPreview.UseVisualStyleBackColor = false;
            this.buttonPrintPreview.Click += new System.EventHandler(this.buttonPrintPreview_Click);
            // 
            // buttonPrintSettings
            // 
            this.buttonPrintSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonPrintSettings.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonPrintSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPrintSettings.FlatAppearance.BorderSize = 0;
            this.buttonPrintSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonPrintSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonPrintSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPrintSettings.Font = new System.Drawing.Font("Cairo", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrintSettings.ForeColor = System.Drawing.Color.Black;
            this.buttonPrintSettings.Image = global::WFBookManagment.Properties.Resources.PrintSetup;
            this.buttonPrintSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPrintSettings.Location = new System.Drawing.Point(551, 20);
            this.buttonPrintSettings.Name = "buttonPrintSettings";
            this.buttonPrintSettings.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonPrintSettings.Size = new System.Drawing.Size(100, 40);
            this.buttonPrintSettings.TabIndex = 31;
            this.buttonPrintSettings.Text = "إعدادات";
            this.buttonPrintSettings.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonPrintSettings.UseVisualStyleBackColor = false;
            this.buttonPrintSettings.Click += new System.EventHandler(this.buttonPrintSettings_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelTitle.Location = new System.Drawing.Point(17, 15);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(119, 36);
            this.labelTitle.TabIndex = 34;
            this.labelTitle.Text = "تقارير النظام";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelCategoriesPox
            // 
            this.panelCategoriesPox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelCategoriesPox.BackColor = System.Drawing.Color.White;
            this.panelCategoriesPox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCategoriesPox.Controls.Add(this.labelCountBorrows);
            this.panelCategoriesPox.Controls.Add(this.labelCountSales);
            this.panelCategoriesPox.Controls.Add(this.labelCountStudents);
            this.panelCategoriesPox.Controls.Add(this.labelCountUsers);
            this.panelCategoriesPox.Controls.Add(this.labelCountBooks);
            this.panelCategoriesPox.Controls.Add(this.labelCountCategories);
            this.panelCategoriesPox.Controls.Add(this.label11);
            this.panelCategoriesPox.Controls.Add(this.label9);
            this.panelCategoriesPox.Controls.Add(this.label6);
            this.panelCategoriesPox.Controls.Add(this.label3);
            this.panelCategoriesPox.Controls.Add(this.label1);
            this.panelCategoriesPox.Controls.Add(this.label13);
            this.panelCategoriesPox.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panelCategoriesPox.Location = new System.Drawing.Point(43, 99);
            this.panelCategoriesPox.Name = "panelCategoriesPox";
            this.panelCategoriesPox.Size = new System.Drawing.Size(250, 345);
            this.panelCategoriesPox.TabIndex = 46;
            // 
            // labelCountCategories
            // 
            this.labelCountCategories.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountCategories.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountCategories.ForeColor = System.Drawing.Color.Black;
            this.labelCountCategories.Location = new System.Drawing.Point(15, 24);
            this.labelCountCategories.Name = "labelCountCategories";
            this.labelCountCategories.Size = new System.Drawing.Size(75, 45);
            this.labelCountCategories.TabIndex = 2;
            this.labelCountCategories.Text = "--";
            this.labelCountCategories.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label13.Location = new System.Drawing.Point(96, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(138, 45);
            this.label13.TabIndex = 1;
            this.label13.Text = "الفئات";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(96, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "الكتب";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCountBooks
            // 
            this.labelCountBooks.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountBooks.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountBooks.ForeColor = System.Drawing.Color.Black;
            this.labelCountBooks.Location = new System.Drawing.Point(15, 74);
            this.labelCountBooks.Name = "labelCountBooks";
            this.labelCountBooks.Size = new System.Drawing.Size(75, 45);
            this.labelCountBooks.TabIndex = 2;
            this.labelCountBooks.Text = "--";
            this.labelCountBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(96, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 45);
            this.label3.TabIndex = 1;
            this.label3.Text = "الأمناء";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCountUsers
            // 
            this.labelCountUsers.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountUsers.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountUsers.ForeColor = System.Drawing.Color.Black;
            this.labelCountUsers.Location = new System.Drawing.Point(15, 124);
            this.labelCountUsers.Name = "labelCountUsers";
            this.labelCountUsers.Size = new System.Drawing.Size(75, 45);
            this.labelCountUsers.TabIndex = 2;
            this.labelCountUsers.Text = "--";
            this.labelCountUsers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(96, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 45);
            this.label6.TabIndex = 1;
            this.label6.Text = "الطلاب";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCountStudents
            // 
            this.labelCountStudents.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountStudents.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountStudents.ForeColor = System.Drawing.Color.Black;
            this.labelCountStudents.Location = new System.Drawing.Point(15, 174);
            this.labelCountStudents.Name = "labelCountStudents";
            this.labelCountStudents.Size = new System.Drawing.Size(75, 45);
            this.labelCountStudents.TabIndex = 2;
            this.labelCountStudents.Text = "--";
            this.labelCountStudents.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(96, 224);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 45);
            this.label9.TabIndex = 1;
            this.label9.Text = "المبيعات";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCountSales
            // 
            this.labelCountSales.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountSales.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountSales.ForeColor = System.Drawing.Color.Black;
            this.labelCountSales.Location = new System.Drawing.Point(15, 224);
            this.labelCountSales.Name = "labelCountSales";
            this.labelCountSales.Size = new System.Drawing.Size(75, 45);
            this.labelCountSales.TabIndex = 2;
            this.labelCountSales.Text = "--";
            this.labelCountSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label11.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(96, 274);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 45);
            this.label11.TabIndex = 1;
            this.label11.Text = "الإعارات";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCountBorrows
            // 
            this.labelCountBorrows.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelCountBorrows.Font = new System.Drawing.Font("khalaad Sara", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCountBorrows.ForeColor = System.Drawing.Color.Black;
            this.labelCountBorrows.Location = new System.Drawing.Point(15, 274);
            this.labelCountBorrows.Name = "labelCountBorrows";
            this.labelCountBorrows.Size = new System.Drawing.Size(75, 45);
            this.labelCountBorrows.TabIndex = 2;
            this.labelCountBorrows.Text = "--";
            this.labelCountBorrows.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(60, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(219, 36);
            this.label7.TabIndex = 47;
            this.label7.Text = "إحصائية عامة";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.labelReportPagesTitle);
            this.panel1.Controls.Add(this.labelReportUser);
            this.panel1.Controls.Add(this.label1ReportDate);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Location = new System.Drawing.Point(311, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(351, 345);
            this.panel1.TabIndex = 48;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Tajawal", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(23, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 45);
            this.label8.TabIndex = 2;
            this.label8.Text = "المدير المالي";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Tajawal", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(23, 224);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 45);
            this.label10.TabIndex = 2;
            this.label10.Text = "المدير العام";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelReportPagesTitle
            // 
            this.labelReportPagesTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelReportPagesTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelReportPagesTitle.Font = new System.Drawing.Font("Tajawal", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReportPagesTitle.ForeColor = System.Drawing.Color.Black;
            this.labelReportPagesTitle.Location = new System.Drawing.Point(23, 174);
            this.labelReportPagesTitle.Name = "labelReportPagesTitle";
            this.labelReportPagesTitle.Size = new System.Drawing.Size(302, 45);
            this.labelReportPagesTitle.TabIndex = 2;
            this.labelReportPagesTitle.Text = "التقرير السنوي الأول لعام 2023";
            this.labelReportPagesTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelReportUser
            // 
            this.labelReportUser.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelReportUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelReportUser.Font = new System.Drawing.Font("Tajawal", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReportUser.ForeColor = System.Drawing.Color.Black;
            this.labelReportUser.Location = new System.Drawing.Point(23, 74);
            this.labelReportUser.Name = "labelReportUser";
            this.labelReportUser.Size = new System.Drawing.Size(194, 45);
            this.labelReportUser.TabIndex = 2;
            this.labelReportUser.Text = "السكرتير الإداري";
            this.labelReportUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1ReportDate
            // 
            this.label1ReportDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1ReportDate.Font = new System.Drawing.Font("khalaad Sara", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1ReportDate.ForeColor = System.Drawing.Color.Black;
            this.label1ReportDate.Location = new System.Drawing.Point(23, 24);
            this.label1ReportDate.Name = "label1ReportDate";
            this.label1ReportDate.Size = new System.Drawing.Size(194, 45);
            this.label1ReportDate.TabIndex = 2;
            this.label1ReportDate.Text = "--";
            this.label1ReportDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Font = new System.Drawing.Font("Gulzar", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(223, 274);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 45);
            this.label17.TabIndex = 1;
            this.label17.Text = "مراجعة مالية:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Gulzar", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label18.Location = new System.Drawing.Point(223, 224);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 45);
            this.label18.TabIndex = 1;
            this.label18.Text = "مراجعة إدارية:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label20.Location = new System.Drawing.Point(23, 124);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(303, 45);
            this.label20.TabIndex = 1;
            this.label20.Text = "عنوان التقرير:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Gulzar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(223, 74);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 45);
            this.label21.TabIndex = 1;
            this.label21.Text = "إعداد :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Gulzar", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(223, 24);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 45);
            this.label22.TabIndex = 1;
            this.label22.Text = "تاريخ الإعداد:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(336, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(308, 36);
            this.label2.TabIndex = 49;
            this.label2.Text = "عن التقرير";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dataGridViewMain);
            this.panel2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Location = new System.Drawing.Point(18, 524);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(669, 271);
            this.panel2.TabIndex = 50;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label26.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(35, 486);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(635, 36);
            this.label26.TabIndex = 51;
            this.label26.Text = "كل أداريي وأمناء المكتبة";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewMain
            // 
            this.dataGridViewMain.AllowUserToAddRows = false;
            this.dataGridViewMain.AllowUserToDeleteRows = false;
            this.dataGridViewMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMain.BackgroundColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Cairo", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMain.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewMain.ColumnHeadersHeight = 40;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Cairo", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewMain.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewMain.GridColor = System.Drawing.Color.SaddleBrown;
            this.dataGridViewMain.Location = new System.Drawing.Point(15, 19);
            this.dataGridViewMain.MultiSelect = false;
            this.dataGridViewMain.Name = "dataGridViewMain";
            this.dataGridViewMain.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Cairo", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            this.dataGridViewMain.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Cairo", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewMain.RowTemplate.Height = 35;
            this.dataGridViewMain.RowTemplate.ReadOnly = true;
            this.dataGridViewMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMain.Size = new System.Drawing.Size(635, 229);
            this.dataGridViewMain.TabIndex = 3;
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // formAddReports
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(704, 881);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(335, 30);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddReports";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة تقارير";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panelCategoriesPox.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer1;
        public System.Windows.Forms.Label labelReportTitle;
        public System.Windows.Forms.Button buttonPrintSettings;
        public System.Windows.Forms.Button buttonPrintPreview;
        public System.Windows.Forms.Button buttonPrint;
        public System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelCategoriesPox;
        private System.Windows.Forms.Label labelCountCategories;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelCountBorrows;
        private System.Windows.Forms.Label labelCountSales;
        private System.Windows.Forms.Label labelCountStudents;
        private System.Windows.Forms.Label labelCountUsers;
        private System.Windows.Forms.Label labelCountBooks;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelReportPagesTitle;
        private System.Windows.Forms.Label labelReportUser;
        private System.Windows.Forms.Label label1ReportDate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridViewMain;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}