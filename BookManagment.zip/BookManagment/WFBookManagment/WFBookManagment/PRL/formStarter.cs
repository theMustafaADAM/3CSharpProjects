﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using WFBookManagment.DAL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formStarter : Form
    {
        public formStarter()
        {
            InitializeComponent();
        }

        clsUsers clsUser = new clsUsers();
        DataTable stdata = new DataTable();

        private void Startertimer_Tick(object sender, EventArgs e)
        {
            StartTheLibrarySystem();
        }

        private void StartTheLibrarySystem()
        {
            try
            {
                stdata = clsUser.StartLibrarySystem();

                if (stdata.Rows.Count > 0)
                {
                    formMain main = new formMain();

                    main.labelUsername.Text = stdata.Rows[0]["Username"].ToString();
                    main.labelPermission.Text = stdata.Rows[0]["uPermissions"].ToString();

                    if (stdata.Rows[0]["uImage"] is DBNull)
                    {
                        main.pBuImage.Image = Properties.Resources.MUser100;
                    }
                    else
                    {
                        byte[] Picture = (byte[])stdata.Rows[0]["uImage"];
                        MemoryStream stream = new MemoryStream(Picture);
                        main.pBuImage.Image = Image.FromStream(stream);
                    }

                    Program.UserName = stdata.Rows[0]["uName"].ToString();
                    main.Show();
                    
                    this.Hide();
                    Startertimer.Enabled = false;
                    
                }
                else
                {
                    formLogin login = new formLogin();
                    login.Show();
                    
                    this.Hide();
                    Startertimer.Enabled = false;

                }
            }
            catch (Exception ex)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo(ex.Message);
                missInfo.ShowDialog();
            }
        }
    }
}
