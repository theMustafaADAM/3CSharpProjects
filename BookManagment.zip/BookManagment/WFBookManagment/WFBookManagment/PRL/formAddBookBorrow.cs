﻿using System;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WFBookManagment.PRL
{
    public partial class formAddBookBorrow : Form
    {
        DataTable table = new DataTable();
        private void _CreateDataTable()
        {
            table.Columns.Add("المعرف");
            table.Columns.Add("الكتاب");
            table.Columns.Add("السعر");


            dataGridViewBooks.DataSource = table;
        }

        private void _ResizeDataGridView()
        {
            dataGridViewBooks.RowHeadersWidth = 15;
            dataGridViewBooks.Columns["المعرف"].Width = 99;
            dataGridViewBooks.Columns["السعر"].Width = 99;
        }

        bool _UpdateMode = false;
        int _borrowID;
        clsBorrowDetails borrowDetails = new clsBorrowDetails();

        public formAddBookBorrow(int borrowID, bool UpdateMode)
        {
            InitializeComponent();
            labelUser.Text = Program.UserName;
            _borrowID = borrowID;
            _UpdateMode = UpdateMode;

            _FillDataGridViewWithStudents();
        }

        private void _FillDataGridViewWithStudents()
        {
            DataTable data = clsStudent.LoadStudents();
            dataGridViewCustomers.DataSource = data;
            dataGridViewCustomers.RowHeadersWidth = 20;
            dataGridViewCustomers.Columns["ت"].Width = 35;
            dataGridViewCustomers.Columns["اسم الطالب"].Width = 120;
            dataGridViewCustomers.Columns["عنوانه"].Visible = false;
            dataGridViewCustomers.Columns["الايميل"].Visible = false;
            dataGridViewCustomers.Columns["الكلية"].Visible = false;
            dataGridViewCustomers.Columns["الصورة"].Visible = false;
        }

        clsStudents clsStudent = new clsStudents();
        clsBorrow clBorrow = new clsBorrow();
        clsBorrowDetails clsBorrowDetail = new clsBorrowDetails();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddStudent addstudent = new formAddStudent(0, false);
            addstudent.ShowDialog();
        }

        private void buttonAddCateg_Click(object sender, EventArgs e)
        {
            if (textBoxBookID.Text != string.Empty) return;

            if (textBoxBillNumber.Text == string.Empty) buttonNewBill.PerformClick();

            formBooksList booksList = new formBooksList();
            booksList.ShowDialog();

            textBoxBookID.Text = booksList.dataGridViewBooks.CurrentRow.Cells["ت"].Value.ToString();
            textBoxBookTitle.Text = booksList.dataGridViewBooks.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
            textBoxPrice.Text = Convert.ToDecimal(3 * numericDays.Value).ToString();

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            formAddBook addBook = new formAddBook(0, false);
            addBook.ShowDialog();
        }

        private void buttonNewBill_Click(object sender, EventArgs e)
        {
            if (textBoxBillNumber.Text != string.Empty) return;
            textBoxBillNumber.Text = clBorrow.GetLastBorrowID().Rows[0][0].ToString();
        }

        private void buttonAddToList_Click(object sender, EventArgs e)
        {
            if (textBoxBookID.Text == string.Empty)
            {
                buttonSetBook.PerformClick();
                return;
            }

            // to check if Product been added
            for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
            {
                if (dataGridViewBooks.Rows[i].Cells["المعرف"].Value.ToString() == textBoxBookID.Text)
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء اختيار كتاب آخر أو التعديل على جدول الكتب");
                    missInfo.ShowDialog();
                    return;
                }
            }

            if (textBoxPrice.Text == string.Empty) numericDays.Value = 1;

            //StateMode = "AddDgv";
            DataRow drow = table.NewRow();
            drow[0] = textBoxBookID.Text;
            drow[1] = textBoxBookTitle.Text;
            drow[2] = textBoxPrice.Text;

            table.Rows.Add(drow);
            dataGridViewBooks.DataSource = table;

            _ClearAfterAddDgv();

            textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
        }

        private void _ClearAfterAddDgv()
        {
            textBoxBookID.Clear();
            textBoxBookTitle.Clear();
        }

        private void formAddBookBorrow_Load(object sender, EventArgs e)
        {
            _CreateDataTable();
            _ResizeDataGridView();
            // أعلى تاريخ متاح أسبوعين للأمام مثلا لصلاحية الاستعارة
            dtPSaleDate.MaxDate = DateTime.Now.AddDays(14);
            //  أقل تاريخ متاح للخلف مثلا لاستعارة يفترض أنها صدرت قبل عطلة الأسبوع مثلا
            dtPSaleDate.MinDate = DateTime.Now.AddDays(-3);

            if (_borrowID != -1)
            {
                DataTable dtBorrowDetails = borrowDetails.GetBorrowDetails(_borrowID);
                dataGridViewBooks.DataSource = dtBorrowDetails;
                dataGridViewBooks.RowHeadersWidth = 30;
                dataGridViewBooks.Columns["المعرف"].Width = 70;
            }

            if (!_UpdateMode)
            {
                buttonRemoveAll.Enabled = buttonRemoveBook.Enabled = false;
            }
        }

        private void formAddBookBorrow_Activated(object sender, EventArgs e)
        {
            _FillDataGridViewWithStudents();
            textBoxEndBorrow.Text = dtPSaleDate.Value.AddDays(Convert.ToInt16(numericDays.Value) * 7).ToShortDateString();
        }

        private void comboBoxStudent_SelectionChangeCommitted(object sender, EventArgs e)
        {
        }

        private void buttonAddBorrow_Click(object sender, EventArgs e)
        {
            // Add New Borrow Record
            if (_borrowID == -1)
            {
                if (textBoxBillNumber.Text == string.Empty) buttonNewBill.PerformClick();

                if (textBoxEndBorrow.Text == string.Empty)
                {
                    numericDays.Focus();
                    formDialogMissInfo miss = new formDialogMissInfo("لم يتم تحديد تاريخ نهاية الإعارة");
                    miss.ShowDialog();
                    return;
                }

                if (dataGridViewBooks.Rows.Count > 0)
                {
                    if (textBoxCustomer.Text == string.Empty)
                    {

                        formDialogMissInfo missInfo = new formDialogMissInfo("اختر الطالب");
                        missInfo.ShowDialog();
                        dataGridViewCustomers.Focus();
                        return;
                    }

                    string customer = textBoxCustomer.Text;
                    string csMobile = textBoxstMobile.Text;
                    string cstEmail = textBoxstEmail.Text;
                    string endBorro = textBoxEndBorrow.Text;

                    formDialogYESNO dialogAddRecord = new formDialogYESNO($"إضافة سجل إعارة باسم {customer} ؟");
                    dialogAddRecord.DataBack += DialogAddRecord_DataBack;
                    dialogAddRecord.ShowDialog();


                    if (!_ConfirmAddRecord)
                    {
                        dataGridViewCustomers.Focus();
                        return;
                    }

                    clBorrow = new clsBorrow();
                    clBorrow.borrowID = Convert.ToInt16(textBoxBillNumber.Text);
                    clBorrow.borrowDate = dtPSaleDate.Value.ToLongDateString();
                    clBorrow.borrowMan = labelUser.Text;
                    clBorrow.CustomerName = customer;
                    clBorrow.CustomerMobile = csMobile;
                    clBorrow.CustomerEmail = cstEmail;
                    clBorrow.EndBorrowDate = endBorro;
                    clBorrow.borrowDays = Convert.ToInt16(numericDays.Value);
                    clBorrow.borrowPrice = Convert.ToDecimal(textBoxPrice.Text);
                    clBorrow.TotalAmount = Convert.ToDecimal(textBoxTotal.Text);
                    clBorrow.IsReturned = false;

                    if (clBorrow.Insert(clBorrow))
                    {
                        for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
                        {
                            clsBorrowDetail = new clsBorrowDetails
                            {
                                borrowID = Convert.ToInt16(textBoxBillNumber.Text),
                                bookID = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[0].Value),
                                bookTitle = Convert.ToString(dataGridViewBooks.Rows[i].Cells[1].Value),
                                borrowPrice = Convert.ToDecimal(dataGridViewBooks.Rows[i].Cells[2].Value)
                            };
                            clsBorrowDetail.Insert(clsBorrowDetail);
                        }

                        int RowCounts = dataGridViewBooks.Rows.Count;

                        formDialogOK dialogOK = new formDialogOK
                            ($"تم حفظ التذكرة {textBoxBillNumber.Text} وعدد {RowCounts} كتب بنجاح");
                        dialogOK.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                    }
                    else
                    {
                        formDialogFail fail = new formDialogFail
                            ($"فشل حفظ التذكرة {textBoxBillNumber.Text} للأسف");
                        fail.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                        return;
                    }

                }
                else
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                    missInfo.ShowDialog();
                    return;
                }
            }
            // Edit Borrow Records
            else if (_borrowID != -1 && buttonAddBorrow.Text == "تحديث إعارة")
            {
                if (textBoxBillNumber.Text == string.Empty) textBoxBillNumber.Text = _borrowID.ToString();

                if (textBoxEndBorrow.Text == string.Empty)
                {
                    numericDays.Focus();
                    formDialogMissInfo miss = new formDialogMissInfo("لم يتم تحديد تاريخ نهاية الإعارة");
                    miss.ShowDialog();
                    return;
                }

                if (dataGridViewBooks.Rows.Count > 0)
                {
                    if (textBoxCustomer.Text == string.Empty)
                    {                        
                        formDialogMissInfo miss = new formDialogMissInfo("اختر الطالب");
                        miss.ShowDialog();
                        dataGridViewCustomers.Focus();
                        return;
                    }

                    string customer = textBoxCustomer.Text;
                    string csMobile = textBoxstMobile.Text;
                    string cstEmail = textBoxstEmail.Text;
                    string endBorro = textBoxEndBorrow.Text;

                    formDialogYESNO dialogAddRecord = new formDialogYESNO
                        ($"تعديل سجل إعارة باسم {customer} ؟");
                    dialogAddRecord.DataBack += DialogAddRecord_DataBack;
                    dialogAddRecord.ShowDialog();


                    if (!_ConfirmAddRecord)
                    {
                        formDialogCanceledOnRequest frm = new formDialogCanceledOnRequest();
                        frm.ShowDialog();
                        return;
                    }

                    clBorrow = new clsBorrow();
                    clBorrow.borrowID = Convert.ToInt16(textBoxBillNumber.Text);
                    clBorrow.borrowDate = dtPSaleDate.Value.ToLongDateString();
                    clBorrow.borrowMan = labelUser.Text;
                    clBorrow.CustomerName = customer;
                    clBorrow.CustomerMobile = csMobile;
                    clBorrow.CustomerEmail = cstEmail;
                    clBorrow.EndBorrowDate = endBorro;
                    clBorrow.borrowDays = Convert.ToInt16(numericDays.Value);
                    clBorrow.borrowPrice = Convert.ToDecimal(textBoxPrice.Text);
                    clBorrow.TotalAmount = Convert.ToDecimal(textBoxTotal.Text);
                    clBorrow.IsReturned = false;

                    if (clBorrow.Update(clBorrow))
                    {
                        for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
                        {
                            clsBorrowDetail = new clsBorrowDetails
                            {
                                borrowID = Convert.ToInt16(textBoxBillNumber.Text),
                                bookID = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[0].Value),
                                bookTitle = Convert.ToString(dataGridViewBooks.Rows[i].Cells[1].Value),
                                borrowPrice = Convert.ToDecimal(dataGridViewBooks.Rows[i].Cells[2].Value)
                            };
                            clsBorrowDetail.Update(clsBorrowDetail);
                        }
                        int RowCounts = dataGridViewBooks.Rows.Count;

                        formDialogOK dialogOK = new formDialogOK
                            ($"عُدلت التذكرة {textBoxBillNumber.Text} وعدد {RowCounts} كتب بنجاح");
                        dialogOK.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                    }
                    else
                    {
                        formDialogFail fail = new formDialogFail
                            ($"فشل تعديل التذكرة {textBoxBillNumber.Text} للأسف");
                        fail.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                        return;
                    }


                }
                else
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                    missInfo.ShowDialog();
                    return;
                }
            }
            // Return borrow
            else if (_borrowID != -1 && buttonAddBorrow.Text == "تسجيل إرجاع")
            {
                if (textBoxBillNumber.Text == string.Empty) textBoxBillNumber.Text = _borrowID.ToString();

                if (textBoxEndBorrow.Text == string.Empty)
                {
                    numericDays.Focus();
                    formDialogMissInfo miss = new formDialogMissInfo("لم يتم تحديد تاريخ نهاية الإعارة");
                    miss.ShowDialog();
                    return;
                }

                if (dataGridViewBooks.Rows.Count > 0)
                {
                    if (textBoxCustomer.Text == string.Empty)
                    {
                        formDialogMissInfo miss = new formDialogMissInfo("اختر الطالب");
                        miss.ShowDialog();
                        dataGridViewCustomers.Focus();
                        return;
                    }

                    string customer = textBoxCustomer.Text;
                    string csMobile = textBoxstMobile.Text;
                    string cstEmail = textBoxstEmail.Text;
                    string endBorro = textBoxEndBorrow.Text;

                    formDialogYESNO dialogAddRecord = new formDialogYESNO
                        ($"تسجيل الإعادة للطالب  {customer} ؟");
                    dialogAddRecord.DataBack += DialogAddRecord_DataBack;
                    dialogAddRecord.ShowDialog();


                    if (!_ConfirmAddRecord)
                    {
                        formDialogCanceledOnRequest frm = new formDialogCanceledOnRequest();
                        frm.ShowDialog();
                        this.Close();
                        return;
                    }

                    clBorrow = new clsBorrow();
                    clBorrow.borrowID = Convert.ToInt16(textBoxBillNumber.Text);
                    clBorrow.borrowDate = dtPSaleDate.Value.ToLongDateString();
                    clBorrow.borrowMan = labelUser.Text;
                    clBorrow.CustomerName = customer;
                    clBorrow.CustomerMobile = csMobile;
                    clBorrow.CustomerEmail = cstEmail;
                    clBorrow.EndBorrowDate = endBorro;
                    clBorrow.borrowDays = Convert.ToInt16(numericDays.Value);

                    if (clBorrow.Returned(clBorrow))
                    {
                        for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
                        {
                            int rborrowID = Convert.ToInt16(textBoxBillNumber.Text);
                            int rbookID = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[0].Value);
                            clsBorrowDetail.ReturnBooks(rborrowID, rbookID);
                        }
                        int RowCounts = dataGridViewBooks.Rows.Count;
                        formDialogOK done = new formDialogOK($"أعيدت محتويات التذكرة {textBoxBillNumber.Text} وعدد {RowCounts} كتب بنجاح");
                        done.ShowDialog();
                        
                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                    }
                    else
                    {
                        formDialogFail fail = new formDialogFail($"فشل إعادة التذكرة {textBoxBillNumber.Text} ");
                        fail.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                        return;
                    }

                }
                else
                {
                    formDialogMissInfo miss = new formDialogMissInfo("لم نجد الكتب التي استعيرت");
                    miss.ShowDialog();
                    return;
                }
            }
            else
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmAddRecord;

        private void DialogAddRecord_DataBack(object sender, bool Answer)
        {
            _ConfirmAddRecord = Answer;
        }

        private void buttonRemoveBook_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل ترغب بحذف الكتاب الحالي من الجدول؟");
                dialogYESNO.DataBack += DialogYESNO_DataBack;
                dialogYESNO.ShowDialog();
                
                if (!_ConfirmDeleteBook) return;
                else
                {
                    // to remove from Product table
                    dataGridViewBooks.Rows.RemoveAt(dataGridViewBooks.CurrentRow.Index);
                    textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
                }
            }
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();
                return;
            }
        }

        bool _ConfirmDeleteBook;

        private void DialogYESNO_DataBack(object sender, bool Answer)
        {
            _ConfirmDeleteBook = Answer;
        }

        private void buttonRemoveAll_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل ترغب بحذف الكتب كلها من الجدول؟");
                dialogYESNO.DataBack += DialogYESNO_DataBack;
                dialogYESNO.ShowDialog();

                if (!_ConfirmDeleteBook) return;
                else
                {
                    // to Clear Product table
                    dataGridViewBooks.Columns.Clear();

                    table.Rows.Clear();
                    dataGridViewBooks.Refresh();

                    textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
                }
            }
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();
                return;
            }
        }

        private void dataGridViewBooks_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            buttonRemoveBook.Enabled = buttonRemoveAll.Enabled =
                (dataGridViewBooks.Rows.Count > 0);

            textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
        }

        private void dataGridViewBooks_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            buttonRemoveBook.Enabled = buttonRemoveAll.Enabled =
                (dataGridViewBooks.Rows.Count > 0);

            textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
        }

        private void numericDays_ValueChanged(object sender, EventArgs e)
        {
            // to add Weeks 
            textBoxEndBorrow.Text = dtPSaleDate.Value.AddDays(Convert.ToInt16(numericDays.Value) * 7).ToShortDateString();
            if (textBoxBookID.Text != string.Empty)
            {
                textBoxPrice.Text = Convert.ToDecimal(3 * numericDays.Value).ToString();
            }

            if (textBoxPrice.Text != string.Empty || dataGridViewBooks.Rows.Count > 0)
            {
                textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[2].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[2].FormattedValue)).Sum().ToString();
            }
        }

        private void dataGridViewCustomers_Click(object sender, EventArgs e)
        {
            textBoxCustomer.Text = dataGridViewCustomers.CurrentRow.Cells["اسم الطالب"].Value.ToString();
            textBoxstMobile.Text = dataGridViewCustomers.CurrentRow.Cells["جواله"].Value.ToString();
            textBoxstEmail.Text = dataGridViewCustomers.CurrentRow.Cells["الايميل"].Value.ToString();
        }

        private void dataGridViewCustomers_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }
    }
}
