﻿namespace WFBookManagment.PRL
{
    partial class formStarter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formStarter));
            this.Startertimer = new System.Windows.Forms.Timer(this.components);
            this.uImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.uImage)).BeginInit();
            this.SuspendLayout();
            // 
            // Startertimer
            // 
            this.Startertimer.Enabled = true;
            this.Startertimer.Interval = 5000;
            this.Startertimer.Tick += new System.EventHandler(this.Startertimer_Tick);
            // 
            // uImage
            // 
            this.uImage.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.uImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uImage.Image = global::WFBookManagment.Properties.Resources.LibraryLoading;
            this.uImage.Location = new System.Drawing.Point(0, 0);
            this.uImage.Name = "uImage";
            this.uImage.Size = new System.Drawing.Size(450, 250);
            this.uImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.uImage.TabIndex = 15;
            this.uImage.TabStop = false;
            // 
            // formStarter
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(450, 250);
            this.Controls.Add(this.uImage);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(120, 180);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formStarter";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "شاشة الدخول";
            ((System.ComponentModel.ISupportInitialize)(this.uImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.PictureBox uImage;
        private System.Windows.Forms.Timer Startertimer;
    }
}