﻿namespace WFBookManagment.PRL
{
    partial class formAddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddStudent));
            this.labelAddress = new System.Windows.Forms.Label();
            this.textBoxstAddress = new System.Windows.Forms.TextBox();
            this.labelSchool = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabelCover = new System.Windows.Forms.LinkLabel();
            this.textBoxstEmail = new System.Windows.Forms.TextBox();
            this.textBoxstName = new System.Windows.Forms.TextBox();
            this.textBoxstMobile = new System.Windows.Forms.TextBox();
            this.comboBoxSchools = new System.Windows.Forms.ComboBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAddSchool = new System.Windows.Forms.Button();
            this.stImage = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stImage)).BeginInit();
            this.SuspendLayout();
            // 
            // labelAddress
            // 
            this.labelAddress.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddress.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelAddress.Location = new System.Drawing.Point(56, 250);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(330, 36);
            this.labelAddress.TabIndex = 3;
            this.labelAddress.Text = "عنوان الطالب :";
            this.labelAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxstAddress
            // 
            this.textBoxstAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstAddress.Location = new System.Drawing.Point(56, 289);
            this.textBoxstAddress.Multiline = true;
            this.textBoxstAddress.Name = "textBoxstAddress";
            this.textBoxstAddress.Size = new System.Drawing.Size(330, 120);
            this.textBoxstAddress.TabIndex = 2;
            // 
            // labelSchool
            // 
            this.labelSchool.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSchool.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelSchool.Location = new System.Drawing.Point(414, 43);
            this.labelSchool.Name = "labelSchool";
            this.labelSchool.Size = new System.Drawing.Size(330, 36);
            this.labelSchool.TabIndex = 5;
            this.labelSchool.Text = "المدرسة أو  الكلية :";
            this.labelSchool.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelName
            // 
            this.labelName.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.SaddleBrown;
            this.labelName.Location = new System.Drawing.Point(56, 42);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(330, 36);
            this.labelName.TabIndex = 7;
            this.labelName.Text = "اسم الطالب :";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(56, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "رقم الهاتف الجوال :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label6.Location = new System.Drawing.Point(56, 426);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(330, 36);
            this.label6.TabIndex = 12;
            this.label6.Text = "البريد الالكتروني :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabelCover
            // 
            this.linkLabelCover.AutoSize = true;
            this.linkLabelCover.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabelCover.Location = new System.Drawing.Point(414, 146);
            this.linkLabelCover.Name = "linkLabelCover";
            this.linkLabelCover.Size = new System.Drawing.Size(181, 36);
            this.linkLabelCover.TabIndex = 6;
            this.linkLabelCover.TabStop = true;
            this.linkLabelCover.Text = "اضغط لتحميل صورة";
            this.linkLabelCover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabelCover.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // textBoxstEmail
            // 
            this.textBoxstEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstEmail.Location = new System.Drawing.Point(56, 465);
            this.textBoxstEmail.Name = "textBoxstEmail";
            this.textBoxstEmail.Size = new System.Drawing.Size(330, 43);
            this.textBoxstEmail.TabIndex = 3;
            this.textBoxstEmail.Validated += new System.EventHandler(this.textBoxstEmail_Validated);
            // 
            // textBoxstName
            // 
            this.textBoxstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstName.Location = new System.Drawing.Point(56, 82);
            this.textBoxstName.Name = "textBoxstName";
            this.textBoxstName.Size = new System.Drawing.Size(330, 43);
            this.textBoxstName.TabIndex = 0;
            // 
            // textBoxstMobile
            // 
            this.textBoxstMobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstMobile.Font = new System.Drawing.Font("Simplified Arabic Fixed", 18F);
            this.textBoxstMobile.Location = new System.Drawing.Point(56, 186);
            this.textBoxstMobile.Name = "textBoxstMobile";
            this.textBoxstMobile.Size = new System.Drawing.Size(330, 34);
            this.textBoxstMobile.TabIndex = 1;
            this.textBoxstMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxstMobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxstMobile_KeyPress);
            // 
            // comboBoxSchools
            // 
            this.comboBoxSchools.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSchools.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxSchools.FormattingEnabled = true;
            this.comboBoxSchools.Location = new System.Drawing.Point(414, 87);
            this.comboBoxSchools.Name = "comboBoxSchools";
            this.comboBoxSchools.Size = new System.Drawing.Size(285, 38);
            this.comboBoxSchools.TabIndex = 4;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddStudent.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddStudent.FlatAppearance.BorderSize = 0;
            this.buttonAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddStudent.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddStudent.ForeColor = System.Drawing.Color.Black;
            this.buttonAddStudent.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(414, 468);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddStudent.Size = new System.Drawing.Size(330, 40);
            this.buttonAddStudent.TabIndex = 7;
            this.buttonAddStudent.Text = "طالب";
            this.buttonAddStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddStudent.UseVisualStyleBackColor = false;
            this.buttonAddStudent.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAddSchool
            // 
            this.buttonAddSchool.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAddSchool.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddSchool.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSchool.FlatAppearance.BorderSize = 0;
            this.buttonAddSchool.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSchool.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSchool.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSchool.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddSchool.ForeColor = System.Drawing.Color.Black;
            this.buttonAddSchool.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddSchool.Image")));
            this.buttonAddSchool.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddSchool.Location = new System.Drawing.Point(705, 87);
            this.buttonAddSchool.Name = "buttonAddSchool";
            this.buttonAddSchool.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddSchool.Size = new System.Drawing.Size(38, 38);
            this.buttonAddSchool.TabIndex = 5;
            this.buttonAddSchool.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddSchool.UseVisualStyleBackColor = false;
            this.buttonAddSchool.Click += new System.EventHandler(this.buttonAddSchool_Click);
            // 
            // stImage
            // 
            this.stImage.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.stImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stImage.Image = global::WFBookManagment.Properties.Resources.افريقية;
            this.stImage.Location = new System.Drawing.Point(414, 190);
            this.stImage.Name = "stImage";
            this.stImage.Size = new System.Drawing.Size(330, 219);
            this.stImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stImage.TabIndex = 15;
            this.stImage.TabStop = false;
            this.stImage.Click += new System.EventHandler(this.BookCover_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.LinkColor = System.Drawing.Color.Navy;
            this.linkLabel1.Location = new System.Drawing.Point(694, 146);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(51, 36);
            this.linkLabel1.TabIndex = 17;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "إزالة";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // formAddStudent
            // 
            this.AcceptButton = this.buttonAddStudent;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.buttonAddSchool);
            this.Controls.Add(this.comboBoxSchools);
            this.Controls.Add(this.textBoxstMobile);
            this.Controls.Add(this.textBoxstName);
            this.Controls.Add(this.textBoxstEmail);
            this.Controls.Add(this.linkLabelCover);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.stImage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelSchool);
            this.Controls.Add(this.buttonAddStudent);
            this.Controls.Add(this.labelAddress);
            this.Controls.Add(this.textBoxstAddress);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(215, 100);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddStudent";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            this.Activated += new System.EventHandler(this.formAddBook_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label labelAddress;
        public System.Windows.Forms.Button buttonAddStudent;
        public System.Windows.Forms.TextBox textBoxstAddress;
        public System.Windows.Forms.Label labelSchool;
        public System.Windows.Forms.Label labelName;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.PictureBox stImage;
        public System.Windows.Forms.LinkLabel linkLabelCover;
        public System.Windows.Forms.TextBox textBoxstEmail;
        public System.Windows.Forms.TextBox textBoxstName;
        public System.Windows.Forms.TextBox textBoxstMobile;
        public System.Windows.Forms.Button buttonAddSchool;
        public System.Windows.Forms.ComboBox comboBoxSchools;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        public System.Windows.Forms.LinkLabel linkLabel1;
    }
}