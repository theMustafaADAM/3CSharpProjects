﻿namespace WFBookManagment.PRL
{
    partial class formAddJob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddJob));
            this.buttonExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxJobTitle = new System.Windows.Forms.TextBox();
            this.buttonAddBook = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSalary = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxDepartments = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonAddCateg = new System.Windows.Forms.Button();
            this.textBoxPublish = new System.Windows.Forms.TextBox();
            this.textBoxDepartments = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxDepID = new System.Windows.Forms.TextBox();
            this.groupBoxStudyYears = new System.Windows.Forms.GroupBox();
            this.rBstd17YearsPlus = new System.Windows.Forms.RadioButton();
            this.rBstd1016Years = new System.Windows.Forms.RadioButton();
            this.rBstd09Years = new System.Windows.Forms.RadioButton();
            this.groupBoxExpertYears = new System.Windows.Forms.GroupBox();
            this.rBexp8YearsPlus = new System.Windows.Forms.RadioButton();
            this.rBexp47Years = new System.Windows.Forms.RadioButton();
            this.rBexp03Years = new System.Windows.Forms.RadioButton();
            this.groupBoxStudyYears.SuspendLayout();
            this.groupBoxExpertYears.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label2.Location = new System.Drawing.Point(60, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(680, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "المنصب الوظيفي :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxJobTitle
            // 
            this.textBoxJobTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxJobTitle.Location = new System.Drawing.Point(60, 192);
            this.textBoxJobTitle.Name = "textBoxJobTitle";
            this.textBoxJobTitle.Size = new System.Drawing.Size(678, 43);
            this.textBoxJobTitle.TabIndex = 0;
            // 
            // buttonAddBook
            // 
            this.buttonAddBook.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddBook.FlatAppearance.BorderSize = 0;
            this.buttonAddBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddBook.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddBook.ForeColor = System.Drawing.Color.Black;
            this.buttonAddBook.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddBook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddBook.Location = new System.Drawing.Point(60, 555);
            this.buttonAddBook.Name = "buttonAddBook";
            this.buttonAddBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddBook.Size = new System.Drawing.Size(680, 40);
            this.buttonAddBook.TabIndex = 1;
            this.buttonAddBook.Text = "وظيفة";
            this.buttonAddBook.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddBook.UseVisualStyleBackColor = false;
            this.buttonAddBook.Click += new System.EventHandler(this.buttonAddBook_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label1.Location = new System.Drawing.Point(60, 447);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "الراتب الشهري ابتداء من :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxSalary
            // 
            this.textBoxSalary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSalary.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxSalary.Location = new System.Drawing.Point(60, 490);
            this.textBoxSalary.Name = "textBoxSalary";
            this.textBoxSalary.ReadOnly = true;
            this.textBoxSalary.Size = new System.Drawing.Size(329, 37);
            this.textBoxSalary.TabIndex = 4;
            this.textBoxSalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSalary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPrice_KeyPress);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label4.Location = new System.Drawing.Point(60, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "قائمة الأقسام :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBoxDepartments
            // 
            this.comboBoxDepartments.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDepartments.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxDepartments.FormattingEnabled = true;
            this.comboBoxDepartments.Location = new System.Drawing.Point(60, 99);
            this.comboBoxDepartments.Name = "comboBoxDepartments";
            this.comboBoxDepartments.Size = new System.Drawing.Size(285, 38);
            this.comboBoxDepartments.TabIndex = 8;
            this.comboBoxDepartments.SelectedIndexChanged += new System.EventHandler(this.comboBoxDepartments_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label6.Location = new System.Drawing.Point(410, 447);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(330, 36);
            this.label6.TabIndex = 12;
            this.label6.Text = "ملاحظة :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonAddCateg
            // 
            this.buttonAddCateg.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddCateg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddCateg.FlatAppearance.BorderSize = 0;
            this.buttonAddCateg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCateg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddCateg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCateg.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCateg.ForeColor = System.Drawing.Color.Black;
            this.buttonAddCateg.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddCateg.Image")));
            this.buttonAddCateg.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCateg.Location = new System.Drawing.Point(350, 99);
            this.buttonAddCateg.Name = "buttonAddCateg";
            this.buttonAddCateg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddCateg.Size = new System.Drawing.Size(39, 40);
            this.buttonAddCateg.TabIndex = 18;
            this.buttonAddCateg.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddCateg.UseVisualStyleBackColor = false;
            // 
            // textBoxPublish
            // 
            this.textBoxPublish.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPublish.Font = new System.Drawing.Font("Cairo", 11F);
            this.textBoxPublish.Location = new System.Drawing.Point(410, 489);
            this.textBoxPublish.Name = "textBoxPublish";
            this.textBoxPublish.ReadOnly = true;
            this.textBoxPublish.Size = new System.Drawing.Size(329, 35);
            this.textBoxPublish.TabIndex = 19;
            this.textBoxPublish.Text = "الراتب الشهري للعرض ولن يسجل في قاعدة البيانات";
            this.textBoxPublish.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDepartments
            // 
            this.textBoxDepartments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDepartments.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxDepartments.Location = new System.Drawing.Point(473, 98);
            this.textBoxDepartments.Name = "textBoxDepartments";
            this.textBoxDepartments.ReadOnly = true;
            this.textBoxDepartments.Size = new System.Drawing.Size(265, 40);
            this.textBoxDepartments.TabIndex = 23;
            this.textBoxDepartments.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.SaddleBrown;
            this.label9.Location = new System.Drawing.Point(410, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(330, 36);
            this.label9.TabIndex = 26;
            this.label9.Text = "القسم :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxDepID
            // 
            this.textBoxDepID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDepID.Font = new System.Drawing.Font("Simplified Arabic Fixed", 22F);
            this.textBoxDepID.Location = new System.Drawing.Point(410, 98);
            this.textBoxDepID.Name = "textBoxDepID";
            this.textBoxDepID.ReadOnly = true;
            this.textBoxDepID.Size = new System.Drawing.Size(60, 40);
            this.textBoxDepID.TabIndex = 27;
            this.textBoxDepID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBoxStudyYears
            // 
            this.groupBoxStudyYears.Controls.Add(this.rBstd17YearsPlus);
            this.groupBoxStudyYears.Controls.Add(this.rBstd1016Years);
            this.groupBoxStudyYears.Controls.Add(this.rBstd09Years);
            this.groupBoxStudyYears.ForeColor = System.Drawing.Color.SaddleBrown;
            this.groupBoxStudyYears.Location = new System.Drawing.Point(61, 244);
            this.groupBoxStudyYears.Name = "groupBoxStudyYears";
            this.groupBoxStudyYears.Size = new System.Drawing.Size(330, 186);
            this.groupBoxStudyYears.TabIndex = 35;
            this.groupBoxStudyYears.TabStop = false;
            this.groupBoxStudyYears.Text = "سنوات الدراسة";
            // 
            // rBstd17YearsPlus
            // 
            this.rBstd17YearsPlus.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBstd17YearsPlus.Location = new System.Drawing.Point(40, 130);
            this.rBstd17YearsPlus.Name = "rBstd17YearsPlus";
            this.rBstd17YearsPlus.Size = new System.Drawing.Size(250, 40);
            this.rBstd17YearsPlus.TabIndex = 2;
            this.rBstd17YearsPlus.Text = "17 سنة فأعلى (دبلوم عالي)";
            this.rBstd17YearsPlus.UseVisualStyleBackColor = true;
            this.rBstd17YearsPlus.CheckedChanged += new System.EventHandler(this.rBstd17YearsPlus_CheckedChanged);
            // 
            // rBstd1016Years
            // 
            this.rBstd1016Years.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBstd1016Years.Checked = true;
            this.rBstd1016Years.Location = new System.Drawing.Point(40, 86);
            this.rBstd1016Years.Name = "rBstd1016Years";
            this.rBstd1016Years.Size = new System.Drawing.Size(250, 40);
            this.rBstd1016Years.TabIndex = 1;
            this.rBstd1016Years.TabStop = true;
            this.rBstd1016Years.Text = "16 سنة فأقل (بكالوريوس)";
            this.rBstd1016Years.UseVisualStyleBackColor = true;
            this.rBstd1016Years.CheckedChanged += new System.EventHandler(this.rBstd1016Years_CheckedChanged);
            // 
            // rBstd09Years
            // 
            this.rBstd09Years.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBstd09Years.Location = new System.Drawing.Point(40, 42);
            this.rBstd09Years.Name = "rBstd09Years";
            this.rBstd09Years.Size = new System.Drawing.Size(250, 40);
            this.rBstd09Years.TabIndex = 0;
            this.rBstd09Years.Text = "9 سنوات فأقل (متوسط)";
            this.rBstd09Years.UseVisualStyleBackColor = true;
            this.rBstd09Years.CheckedChanged += new System.EventHandler(this.rBstd09Years_CheckedChanged);
            // 
            // groupBoxExpertYears
            // 
            this.groupBoxExpertYears.Controls.Add(this.rBexp8YearsPlus);
            this.groupBoxExpertYears.Controls.Add(this.rBexp47Years);
            this.groupBoxExpertYears.Controls.Add(this.rBexp03Years);
            this.groupBoxExpertYears.ForeColor = System.Drawing.Color.SaddleBrown;
            this.groupBoxExpertYears.Location = new System.Drawing.Point(410, 244);
            this.groupBoxExpertYears.Name = "groupBoxExpertYears";
            this.groupBoxExpertYears.Size = new System.Drawing.Size(330, 186);
            this.groupBoxExpertYears.TabIndex = 36;
            this.groupBoxExpertYears.TabStop = false;
            this.groupBoxExpertYears.Text = "سنوات الخبرة";
            // 
            // rBexp8YearsPlus
            // 
            this.rBexp8YearsPlus.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBexp8YearsPlus.Location = new System.Drawing.Point(40, 130);
            this.rBexp8YearsPlus.Name = "rBexp8YearsPlus";
            this.rBexp8YearsPlus.Size = new System.Drawing.Size(250, 40);
            this.rBexp8YearsPlus.TabIndex = 2;
            this.rBexp8YearsPlus.Text = "8 سنوات فأكثر (خبير)";
            this.rBexp8YearsPlus.UseVisualStyleBackColor = true;
            this.rBexp8YearsPlus.CheckedChanged += new System.EventHandler(this.rBexp8YearsPlus_CheckedChanged);
            // 
            // rBexp47Years
            // 
            this.rBexp47Years.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBexp47Years.Location = new System.Drawing.Point(40, 86);
            this.rBexp47Years.Name = "rBexp47Years";
            this.rBexp47Years.Size = new System.Drawing.Size(250, 40);
            this.rBexp47Years.TabIndex = 1;
            this.rBexp47Years.Text = "4 - 7 سنوات (متوسط)";
            this.rBexp47Years.UseVisualStyleBackColor = true;
            this.rBexp47Years.CheckedChanged += new System.EventHandler(this.rBexp47Years_CheckedChanged);
            // 
            // rBexp03Years
            // 
            this.rBexp03Years.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rBexp03Years.Checked = true;
            this.rBexp03Years.Location = new System.Drawing.Point(40, 42);
            this.rBexp03Years.Name = "rBexp03Years";
            this.rBexp03Years.Size = new System.Drawing.Size(250, 40);
            this.rBexp03Years.TabIndex = 0;
            this.rBexp03Years.TabStop = true;
            this.rBexp03Years.Text = "0 - 3 سنوات (مبتدئ)";
            this.rBexp03Years.UseVisualStyleBackColor = true;
            this.rBexp03Years.CheckedChanged += new System.EventHandler(this.rBexp03Years_CheckedChanged);
            // 
            // formAddJob
            // 
            this.AcceptButton = this.buttonAddBook;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(800, 651);
            this.Controls.Add(this.groupBoxExpertYears);
            this.Controls.Add(this.groupBoxStudyYears);
            this.Controls.Add(this.textBoxDepID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxDepartments);
            this.Controls.Add(this.textBoxPublish);
            this.Controls.Add(this.buttonAddCateg);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxDepartments);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxSalary);
            this.Controls.Add(this.buttonAddBook);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxJobTitle);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(215, 100);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddJob";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "إضافة فئة";
            this.Load += new System.EventHandler(this.formAddJob_Load);
            this.groupBoxStudyYears.ResumeLayout(false);
            this.groupBoxExpertYears.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button buttonAddBook;
        public System.Windows.Forms.TextBox textBoxJobTitle;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBoxSalary;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button buttonAddCateg;
        public System.Windows.Forms.ComboBox comboBoxDepartments;
        public System.Windows.Forms.TextBox textBoxPublish;
        public System.Windows.Forms.TextBox textBoxDepartments;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox textBoxDepID;
        private System.Windows.Forms.GroupBox groupBoxStudyYears;
        private System.Windows.Forms.RadioButton rBstd09Years;
        private System.Windows.Forms.RadioButton rBstd17YearsPlus;
        private System.Windows.Forms.RadioButton rBstd1016Years;
        private System.Windows.Forms.GroupBox groupBoxExpertYears;
        private System.Windows.Forms.RadioButton rBexp8YearsPlus;
        private System.Windows.Forms.RadioButton rBexp47Years;
        private System.Windows.Forms.RadioButton rBexp03Years;
    }
}