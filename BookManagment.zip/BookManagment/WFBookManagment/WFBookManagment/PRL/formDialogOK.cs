﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFBookManagment.PRL
{
    public partial class formDialogOK : Form
    {
        public formDialogOK()
        {
            InitializeComponent();
        }

        public formDialogOK(string msg)
        {
            InitializeComponent();
            labelMsg.Text = msg;
        }
        private void timerNotification_Tick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
