﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;

namespace WFBookManagment.PRL
{
    public partial class formAddBookSale : Form
    {
        DataTable table = new DataTable();
        private void _CreateDataTable()
        {
            table.Columns.Add("المعرف");
            table.Columns.Add("الكتاب");
            table.Columns.Add("الكمية");
            table.Columns.Add("السعر");

            dataGridViewBooks.DataSource = table;
        }

        private void _ResizeDataGridView()
        {
            dataGridViewBooks.RowHeadersWidth = 15;
            dataGridViewBooks.Columns[0].Width = 60;
            dataGridViewBooks.Columns[1].Width = 230;
            dataGridViewBooks.Columns[2].Width = 65;
            dataGridViewBooks.Columns[3].Width = 100;
        }

        public formAddBookSale(int saleID)
        {
            InitializeComponent();
            _FillDataGridViewWithStudents();
            labelUser.Text = Program.UserName;
            _saleID = saleID;
        }

        private void _FillDataGridViewWithSoledBooks()
        {
            DataTable dtSaleDetails = clsSaleDetail.GetSaleDetails(_saleID);
            dataGridViewBooks.DataSource = dtSaleDetails;
            dataGridViewBooks.RowHeadersWidth = 20;
            dataGridViewBooks.Columns["ت"].Width = 70;
            dataGridViewBooks.Columns["الكتاب"].Width = 240;
        }

        int _saleID = -1;

        private void _FillDataGridViewWithStudents()
        {
            DataTable data = clsStudent.LoadStudents();
            dataGridViewCustomers.DataSource = data;
            dataGridViewCustomers.RowHeadersWidth = 20;
            dataGridViewCustomers.Columns["ت"].Width = 35;
            dataGridViewCustomers.Columns["اسم الطالب"].Width = 120;
            dataGridViewCustomers.Columns["عنوانه"].Visible = false;
            dataGridViewCustomers.Columns["الايميل"].Visible = false;
            dataGridViewCustomers.Columns["الكلية"].Visible = false;
            dataGridViewCustomers.Columns["الصورة"].Visible = false;
        }


        public decimal bookPrice;
        public int bookQty;
        clsStudents clsStudent = new clsStudents();
        clsSales clsSale = new clsSales();
        clsSaleDetails clsSaleDetail = new clsSaleDetails();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)
                && e.KeyChar != Convert.ToChar(CurrentCulture.NumberFormat.NumberDecimalSeparator);
        }

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddStudent addstudent = new formAddStudent(0, false);
            addstudent.ShowDialog();
        }

        private void formAddBook_Activated(object sender, EventArgs e)
        {
            _FillDataGridViewWithStudents();

            if (_saleID != -1)
            {
                _FillDataGridViewWithSoledBooks();
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void formAddBookSale_Load(object sender, EventArgs e)
        {
            _CreateDataTable();
            _ResizeDataGridView();
            // أعلى تاريخ متاح أسبوعين للأمام مثلا لصلاحية عرض سعر
            dtPSaleDate.MaxDate = DateTime.Now.AddDays(14);
            //  أقل تاريخ متاح للخلف مثلا لفاتورة يفترض أن تصدر قبل عطلة الأسبوع مثلا
            dtPSaleDate.MinDate = DateTime.Now.AddDays(-3);

            if (_saleID == -1)
                buttonRemoveBook.Enabled = buttonClearTable.Enabled =
                    (dataGridViewBooks.Rows.Count > 0);
        }

        private void buttonSetBook_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text != string.Empty) return;

            if (textBoxBillNumber.Text == string.Empty) buttonNewBill.PerformClick();

            formBooksList booksList = new formBooksList();
            booksList.ShowDialog();

            textBoxID.Text = booksList.dataGridViewBooks.CurrentRow.Cells["ت"].Value.ToString();
            textBoxBookTitle.Text = booksList.dataGridViewBooks.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
            bookPrice = Convert.ToDecimal(booksList.dataGridViewBooks.CurrentRow.Cells["السعر"].Value);
            bookQty = Convert.ToInt32(booksList.dataGridViewBooks.CurrentRow.Cells["الكمية"].Value);
            textBoxPrice.Text = (bookPrice * numericQty.Value).ToString();
        }

        private void buttonAddToList_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text == string.Empty)
            {
                buttonSetBook.PerformClick();
                return;
            }

            // to check if Product been added
            for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
            {
                if (dataGridViewBooks.Rows[i].Cells["المعرف"].Value.ToString() == textBoxID.Text)
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء اختيار كتاب آخر أو التعديل على جدول الكتب");
                    missInfo.ShowDialog();
                    return;
                }
            }

            //StateMode = "AddDgv";
            DataRow drow = table.NewRow();
            drow[0] = textBoxID.Text;
            drow[1] = textBoxBookTitle.Text;
            drow[2] = numericQty.Value;
            drow[3] = textBoxPrice.Text;

            table.Rows.Add(drow);
            dataGridViewBooks.DataSource = table;

            _ClearAfterAddDgv();

            textBoxTotal.Text =
                (from DataGridViewRow rw in dataGridViewBooks.Rows
                 where rw.Cells[3].FormattedValue.ToString() != string.Empty
                 select Convert.ToDouble(rw.Cells[3].FormattedValue)).Sum().ToString();
        }

        private void _ClearAfterAddDgv()
        {
            textBoxID.Clear();
            textBoxBookTitle.Clear();
            textBoxPrice.Clear();
            numericQty.Value = 1;
        }

        private void numericQty_ValueChanged(object sender, EventArgs e)
        {
            textBoxPrice.Text = (bookPrice * numericQty.Value).ToString();
        }

        private void comboBoxStudent_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxStudent_SelectionChangeCommitted(object sender, EventArgs e)
        {
        }

        private void buttonNewBill_Click(object sender, EventArgs e)
        {
            if (textBoxBillNumber.Text != string.Empty) return;
            textBoxBillNumber.Text = clsSale.GetLastSaleID().Rows[0][0].ToString();
            //textBoxBillNumber.Text = clsSale.GetLastSaleSCOPEIDENTITY().Rows[0][0].ToString();
        }

        private void buttonAddSale_Click(object sender, EventArgs e)
        {
            if (textBoxBillNumber.Text == string.Empty) buttonNewBill.PerformClick();

            if (_saleID == -1)
            {

                if (dataGridViewBooks.Rows.Count > 0)
                {
                    if (textBoxstName.Text == string.Empty)
                    {
                        formDialogMissInfo missInfo = new formDialogMissInfo("اختر الطالب");
                        missInfo.ShowDialog();
                        dataGridViewCustomers.Focus();
                        return;
                    }

                    string customer = textBoxstName.Text.ToString();

                    formDialogYESNO dialogAddRecord = new formDialogYESNO($"إنشاء فاتورة باسم {customer} ؟");
                    dialogAddRecord.DataBack += DialogAddRecord_DataBack;
                    dialogAddRecord.ShowDialog();

                    if (!_ConfirmAddRecord)
                    {
                        dataGridViewCustomers.Focus(); return;
                    }

                    clsSale = new clsSales();
                    clsSale.saleID = Convert.ToInt16(textBoxBillNumber.Text);
                    clsSale.saleDate = dtPSaleDate.Value.ToLongDateString();
                    clsSale.saleMan = labelUser.Text;
                    clsSale.CustomerName = textBoxstName.Text;
                    clsSale.CustomerMobile = textBoxstMobile.Text;
                    clsSale.CustomerEmail = textBoxstEmail.Text;
                    clsSale.SaleTotalAmount = Convert.ToDecimal(textBoxTotal.Text);
                    clsSale.IsCanceled = false;

                    if (clsSale.Insert(clsSale))
                    {
                        for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
                        {
                            clsSaleDetail = new clsSaleDetails
                            {
                                saleID = Convert.ToInt16(textBoxBillNumber.Text),
                                bookID = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[0].Value),
                                bookTitle = Convert.ToString(dataGridViewBooks.Rows[i].Cells[1].Value),
                                bookQty = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[2].Value),
                                bookPrice = Convert.ToDecimal(dataGridViewBooks.Rows[i].Cells[3].Value)
                            };
                            clsSaleDetail.Insert(clsSaleDetail);
                        }
                        
                        int RowCounts = dataGridViewBooks.Rows.Count;
                        
                        formDialogOK dialogOK = new formDialogOK
                            ($"تم حفظ الفاتورة {textBoxBillNumber.Text} وعدد {RowCounts} كتب بنجاح");
                        dialogOK.ShowDialog();
                        
                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                    }
                    else
                    {
                        formDialogFail fail = new formDialogFail
                            ($"فشل حفظ الفاتورة {textBoxBillNumber.Text} للأسف");
                        fail.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                        return;
                    }
                }
                else
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتب إلى الجدول أولاً");
                    missInfo.ShowDialog();
                    return;
                }
            }
            // to Cancele Sale
            else if (_saleID != -1)
            {
                if (dataGridViewBooks.Rows.Count > 0)
                {
                    string customer = textBoxstName.Text.ToString();



                    if (DialogResult.No == MessageBox.Show($"إلغاء فاتورة باسم {customer} ؟", "", MessageBoxButtons.YesNo))
                    {
                        formDialogCanceledOnRequest frm = new formDialogCanceledOnRequest();
                        frm.ShowDialog();
                        this.Close();
                        return;
                    }

                    if (clsSale.Cancele(_saleID))
                    {
                        for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
                        {
                            int cbookID = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[0].Value);
                            int cbookQty = Convert.ToInt16(dataGridViewBooks.Rows[i].Cells[2].Value);
                            clsSaleDetail.Cancele(cbookID, cbookQty);
                        }
                        
                        int RowCounts = dataGridViewBooks.Rows.Count;

                        formDialogOK dialogOK = new formDialogOK
                            ($"تم إلغاء الفاتورة {textBoxBillNumber.Text} وعدد {RowCounts} كتب بنجاح");
                        dialogOK.ShowDialog();

                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                    }
                    else
                    {
                        formDialogFail fail = new formDialogFail
                            ($"فشل إلغاء الفاتورة {textBoxBillNumber.Text} للأسف");
                        fail.ShowDialog();
                        
                        _ClearAfterAddDgv();
                        table.Clear();
                        dataGridViewBooks.Refresh();
                        dtPSaleDate.ResetText();
                        return;
                    }
                }
                else
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("لم نجد كتبك التي بعتها");
                    missInfo.ShowDialog();
                    return;
                }
            }
            else
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmAddRecord;

        private void DialogAddRecord_DataBack(object sender, bool Answer)
        {
            _ConfirmAddRecord = Answer;
        }

        private void buttonRemoveBook_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {
                formDialogYESNO deleteYesNo = new formDialogYESNO("هل ترغب بحذف الكتاب الحالي من الجدول؟");
                deleteYesNo.DataBack += DeleteYesNo_DataBack;
                deleteYesNo.ShowDialog();

                if (!_ConfirmDelete) return;
                else
                {
                    // to remove from Product table
                    dataGridViewBooks.Rows.RemoveAt(dataGridViewBooks.CurrentRow.Index);
                }
            }
            // already handeled , but just in case somthing goes wrong
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();

                return;
            }
        }

        bool _ConfirmDelete;

        private void DeleteYesNo_DataBack(object sender, bool Answer)
        {
            _ConfirmDelete = Answer;
        }

        private void buttonClearTable_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {

                formDialogYESNO dialogYESNO = new formDialogYESNO("هل ترغب بإفراغ الجدول؟");

                //  to Subscribe the Event and Get the Data to Private Method
                dialogYESNO.DataBack += ClearTable_DataBack;

                dialogYESNO.ShowDialog();

                if (!_ClearTable) return;
                else
                {
                    // to Clear Product table
                    table.Clear();
                    dataGridViewBooks.Refresh();
                }
            }
            // already handeled , but just in case somthing goes wrong
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();
                return;
            }
        }

        bool _ClearTable;

        private void ClearTable_DataBack(object sender, bool Answer)
        {
            _ClearTable = Answer;
        }

        private void dataGridViewBooks_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            // Handel if No Rows in DataGridView
            if (_saleID == -1)
                buttonRemoveBook.Enabled = buttonClearTable.Enabled =
                (dataGridViewBooks.Rows.Count > 0);

            textBoxTotal.Text = (from DataGridViewRow rw in dataGridViewBooks.Rows
                                 where rw.Cells[3].FormattedValue.ToString() != string.Empty
                                 select Convert.ToDouble(rw.Cells[3].FormattedValue)).Sum().ToString();
        }

        private void dataGridViewBooks_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            // Handel if No Rows in DataGridView
            if (_saleID == -1)
                buttonRemoveBook.Enabled = buttonClearTable.Enabled =
                (dataGridViewBooks.Rows.Count > 0);

            textBoxTotal.Text = (from DataGridViewRow rw in dataGridViewBooks.Rows
                                 where rw.Cells[3].FormattedValue.ToString() != string.Empty
                                 select Convert.ToDouble(rw.Cells[3].FormattedValue)).Sum().ToString();
        }

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            formAddBook addBook = new formAddBook(0, false);
            addBook.ShowDialog();
        }

        private void buttonAddStudent_Click(object sender, EventArgs e)
        {
            formAddStudent addStudent = new formAddStudent();
            addStudent.ShowDialog();
        }

        private void dataGridViewCustomers_Click(object sender, EventArgs e)
        {
            textBoxstName.Text = dataGridViewCustomers.CurrentRow.Cells["اسم الطالب"].Value.ToString();
            textBoxstMobile.Text = dataGridViewCustomers.CurrentRow.Cells["جواله"].Value.ToString();
            textBoxstEmail.Text = dataGridViewCustomers.CurrentRow.Cells["الايميل"].Value.ToString();
        }
    }
}