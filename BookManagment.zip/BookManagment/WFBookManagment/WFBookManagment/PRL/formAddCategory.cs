﻿using System;
using System.Windows.Forms;
using WFBookManagment.BLL;

namespace WFBookManagment.PRL
{
    public partial class formAddCategory : Form
    {
        public formAddCategory(int ID, bool Stt)
        {
            InitializeComponent();
            _ID = ID;
            _Delstate = Stt;
        }

        public formAddCategory()
        {
            InitializeComponent();
        }

        private bool _Delstate;
        private int _ID;
        clsCategories clsCategory = new clsCategories();
        clsBooks clsBook = new clsBooks();
        clsStudents clsStudent = new clsStudents();
        clsDepartments clsDepartment = new clsDepartments();
        clsJobs clsJob = new clsJobs();
        clsUsers clsUser = new clsUsers();
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (textBoxCategory.Text == string.Empty)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo("العنوان مفقود");
                missInfo.ShowDialog();
                return;
            }

            if (_ID == 0)
            {
                clsCategory.Insert(textBoxCategory.Text.Trim());
                formDialogOK done = new formDialogOK("حُفظت الفئة");
                done.ShowDialog();
                this.Close();
            }
            else if (_ID == -3)
            {
                clsUser.InsertSpecialty(textBoxCategory.Text);
                formDialogOK done = new formDialogOK("حُفظ التخصص");
                done.ShowDialog();
                this.Close();
            }

            else if (_ID == -5)
            {
                clsBook.InsertAuthor(textBoxCategory.Text);
                formDialogOK done = new formDialogOK("حُفظ المؤلف");
                done.ShowDialog();
                this.Close();
            }
            else if (_ID == -7)
            {
                clsDepartment.Insert(textBoxCategory.Text);
                formDialogOK done = new formDialogOK("حُفظ القسم");
                done.ShowDialog();
                this.Close();
            }
            else if (_ID == -9)
            {
                clsStudent.InsertSchool(textBoxCategory.Text);
                formDialogOK done = new formDialogOK("حُفظت المدرسة");
                done.ShowDialog();
                this.Close();
            }
            else if (_ID == -11)
            {
                clsUser.InsertPermission(textBoxCategory.Text);
                formDialogOK done = new formDialogOK("حُفظت الصلاحية");
                done.ShowDialog();
                this.Close();
            }

            else if (_ID != 0 && !_Delstate)
            {
                clsCategory.Update(_ID, textBoxCategory.Text.Trim());
                formDialogOK done = new formDialogOK("عُدلت الفئة");
                done.ShowDialog();
                this.Close();
            }

            else if (_ID != 0 && _Delstate)
            {
                formDialogYESNO dialog = new formDialogYESNO($"تأكيد حذف الفئة {textBoxCategory.Text} ؟");
                dialog.DataBack += Dialog_DataBack;
                dialog.ShowDialog();

                if (_ConfirmDelete)
                {
                    clsCategory.Delete(_ID);
                    formDialogOK done = new formDialogOK();
                    done.ShowDialog();
                    this.Close();
                }
            }
            else 
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmDelete;

        private void Dialog_DataBack(object sender, bool Answer)
        {
            _ConfirmDelete = Answer;
        }
    }
}
