﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using static System.Globalization.CultureInfo;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WFBookManagment.PRL
{
    public partial class formShowBookBorrow : Form
    {
        DataTable table = new DataTable();
        private void _CreateDataTable()
        {
            table.Columns.Add("المعرف");
            table.Columns.Add("الكتاب");

            dataGridViewBooks.DataSource = table;
        }

        private void _ResizeDataGridView()
        {
            dataGridViewBooks.RowHeadersWidth = 15;
            dataGridViewBooks.Columns[0].Width = 85;
        }

        int _borrowID;

        public formShowBookBorrow(int borrowID)
        {
            InitializeComponent();
            labelUser.Text = Program.UserName;
            _borrowID = borrowID;
            

        }


        clsStudents clsStudent = new clsStudents();
        clsBorrow clBorrow = new clsBorrow();
        clsBorrowDetails clsBorrowDetail = new clsBorrowDetails();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
               

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddStudent addstudent = new formAddStudent(0, false);
            addstudent.ShowDialog();
        }

        private void buttonAddCateg_Click(object sender, EventArgs e)
        {
            if (textBoxBookID.Text != string.Empty) return;

            if (textBoxBillNumber.Text == string.Empty) buttonNewBill.PerformClick();

            formBooksList booksList = new formBooksList();
            booksList.ShowDialog();

            textBoxBookID.Text = booksList.dataGridViewBooks.CurrentRow.Cells["ت"].Value.ToString();
            textBoxBookTitle.Text = booksList.dataGridViewBooks.CurrentRow.Cells["عنوان الكتاب"].Value.ToString();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            formAddBook addBook = new formAddBook(0, false);
            addBook.ShowDialog();
        }

        private void buttonNewBill_Click(object sender, EventArgs e)
        {
            textBoxBillNumber.Text = clBorrow.GetLastBorrowID().Rows[0][0].ToString();
        }

        private void buttonAddToList_Click(object sender, EventArgs e)
        {
            if (textBoxBookID.Text == string.Empty)
            {
                buttonSetBook.PerformClick();
                return;
            }

            // to check if Product been added
            for (int i = 0; i < dataGridViewBooks.Rows.Count; ++i)
            {
                if (dataGridViewBooks.Rows[i].Cells["المعرف"].Value.ToString() == textBoxBookID.Text)
                {
                    formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء اختيار كتاب آخر أو التعديل على جدول الكتب");
                    missInfo.ShowDialog();
                    return;
                }
            }

            //StateMode = "AddDgv";
            DataRow drow = table.NewRow();
            drow[0] = textBoxBookID.Text;
            drow[1] = textBoxBookTitle.Text;

            table.Rows.Add(drow);
            dataGridViewBooks.DataSource = table;

            _ClearAfterAddDgv();

        }

        private void _ClearAfterAddDgv()
        {
            textBoxBookID.Clear();
            textBoxBookTitle.Clear();
        }

        private void formAddBookBorrow_Load(object sender, EventArgs e)
        {
            _CreateDataTable();
            _ResizeDataGridView();
            // أعلى تاريخ متاح أسبوعين للأمام مثلا لصلاحية الاستعارة
            dtPSaleDate.MaxDate = DateTime.Now.AddDays(14);
            //  أقل تاريخ متاح للخلف مثلا لاستعارة يفترض أنها صدرت قبل عطلة الأسبوع مثلا
            dtPSaleDate.MinDate = DateTime.Now.AddDays(-3);
        }

        private void formAddBookBorrow_Activated(object sender, EventArgs e)
        {
            DataTable dtBorrowDetails = clsBorrowDetail.GetBorrowDetails(_borrowID);
            dataGridViewBooks.DataSource = dtBorrowDetails;
            dataGridViewBooks.RowHeadersWidth = 30;
            dataGridViewBooks.Columns["المعرف"].Width = 70;
        }


        private void buttonRemoveBook_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل ترغب بحذف الكتاب الحالي من الجدول؟");
                dialogYESNO.DataBack += DialogYESNO_DataBack;
                dialogYESNO.ShowDialog();

                if (!_ConfirmDeleteBook) return;
                else
                {
                    // to remove from Product table
                    dataGridViewBooks.Rows.RemoveAt(dataGridViewBooks.CurrentRow.Index);
                }
            }
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();
                return;
            }
        }

        bool _ConfirmDeleteBook;
        private void DialogYESNO_DataBack(object sender, bool Answer)
        {
            _ConfirmDeleteBook = Answer;
        }

        private void buttonRemoveAll_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.Rows.Count > 0)
            {
                formDialogYESNO dialogYESNO = new formDialogYESNO("هل ترغب بحذف الكتب كلها من الجدول؟");
                dialogYESNO.DataBack += DialogYESNO_DataBack;
                dialogYESNO.ShowDialog();

                if (!_ConfirmDeleteBook) return;
                else
                {
                    // to Clear Product table
                    table.Clear();
                    dataGridViewBooks.Refresh();
                }
            }
            else
            {
                formDialogMissInfo missInfo = new formDialogMissInfo
                    ("الرجاء إضافة كتاب إلى الجدول أولاً");
                missInfo.ShowDialog();
                return;
            }
        }

        private void dataGridViewBooks_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            buttonRemoveBook.Enabled = buttonRemoveAll.Enabled =
                (dataGridViewBooks.Rows.Count > 0);
        }

        private void dataGridViewBooks_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            buttonRemoveBook.Enabled = buttonRemoveAll.Enabled =
                (dataGridViewBooks.Rows.Count > 0);
        }

        private void numericDays_ValueChanged(object sender, EventArgs e)
        {
            textBoxEndBorrow.Text = dtPSaleDate.Value.AddDays(Convert.ToInt16(numericDays.Value)+1).ToShortDateString();
        }
    }
}
