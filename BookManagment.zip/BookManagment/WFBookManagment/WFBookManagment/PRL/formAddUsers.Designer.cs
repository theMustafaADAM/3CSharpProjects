﻿namespace WFBookManagment.PRL
{
    partial class formAddUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddUsers));
            this.textBoxJobs = new System.Windows.Forms.TextBox();
            this.labelSchool = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabeluImage = new System.Windows.Forms.LinkLabel();
            this.textBoxstEmail = new System.Windows.Forms.TextBox();
            this.textBoxuName = new System.Windows.Forms.TextBox();
            this.textBoxuMobile = new System.Windows.Forms.TextBox();
            this.comboBoxJob = new System.Windows.Forms.ComboBox();
            this.comboBoxPermissions = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxPermissions = new System.Windows.Forms.TextBox();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxConfirmPassword = new System.Windows.Forms.TextBox();
            this.checkBoxStates = new System.Windows.Forms.CheckBox();
            this.textBoxDepartments = new System.Windows.Forms.TextBox();
            this.comboBoxDepartments = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelRemove = new System.Windows.Forms.LinkLabel();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.uImage = new System.Windows.Forms.PictureBox();
            this.textBoxStdSpecialty = new System.Windows.Forms.TextBox();
            this.comboBoxSpecialtyStd = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxSpecialtyExp = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxExpSpecialty = new System.Windows.Forms.TextBox();
            this.numericStdYears = new System.Windows.Forms.NumericUpDown();
            this.numericExpYears = new System.Windows.Forms.NumericUpDown();
            this.textBoxSalary = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAddSpecialty = new System.Windows.Forms.Button();
            this.buttonAddSpecialties = new System.Windows.Forms.Button();
            this.buttonAddDepartment = new System.Windows.Forms.Button();
            this.buttonAddPersmission = new System.Windows.Forms.Button();
            this.buttonAddJobs = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericStdYears)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericExpYears)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxJobs
            // 
            this.textBoxJobs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxJobs.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxJobs.Location = new System.Drawing.Point(148, 437);
            this.textBoxJobs.Name = "textBoxJobs";
            this.textBoxJobs.ReadOnly = true;
            this.textBoxJobs.Size = new System.Drawing.Size(220, 40);
            this.textBoxJobs.TabIndex = 24;
            this.textBoxJobs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelSchool
            // 
            this.labelSchool.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSchool.ForeColor = System.Drawing.Color.SandyBrown;
            this.labelSchool.Location = new System.Drawing.Point(32, 439);
            this.labelSchool.Name = "labelSchool";
            this.labelSchool.Size = new System.Drawing.Size(115, 36);
            this.labelSchool.TabIndex = 21;
            this.labelSchool.Text = "الوظائف :";
            this.labelSchool.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelSchool.Click += new System.EventHandler(this.labelSchool_Click);
            // 
            // labelName
            // 
            this.labelName.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.SandyBrown;
            this.labelName.Location = new System.Drawing.Point(32, 64);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(115, 36);
            this.labelName.TabIndex = 16;
            this.labelName.Text = "الاسم :";
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SandyBrown;
            this.label4.Location = new System.Drawing.Point(32, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 36);
            this.label4.TabIndex = 19;
            this.label4.Text = "الجوال :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SandyBrown;
            this.label6.Location = new System.Drawing.Point(32, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 36);
            this.label6.TabIndex = 18;
            this.label6.Text = "الايميل :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabeluImage
            // 
            this.linkLabeluImage.AutoSize = true;
            this.linkLabeluImage.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabeluImage.LinkColor = System.Drawing.Color.Navy;
            this.linkLabeluImage.Location = new System.Drawing.Point(141, 327);
            this.linkLabeluImage.Name = "linkLabeluImage";
            this.linkLabeluImage.Size = new System.Drawing.Size(181, 36);
            this.linkLabeluImage.TabIndex = 12;
            this.linkLabeluImage.TabStop = true;
            this.linkLabeluImage.Text = "اضغط لتحميل صورة";
            this.linkLabeluImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabeluImage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // textBoxstEmail
            // 
            this.textBoxstEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxstEmail.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxstEmail.Location = new System.Drawing.Point(148, 170);
            this.textBoxstEmail.MaxLength = 49;
            this.textBoxstEmail.Name = "textBoxstEmail";
            this.textBoxstEmail.Size = new System.Drawing.Size(220, 40);
            this.textBoxstEmail.TabIndex = 2;
            this.textBoxstEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxstEmail.Validated += new System.EventHandler(this.textBoxstEmail_Validated);
            // 
            // textBoxuName
            // 
            this.textBoxuName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxuName.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxuName.Location = new System.Drawing.Point(148, 62);
            this.textBoxuName.MaxLength = 199;
            this.textBoxuName.Name = "textBoxuName";
            this.textBoxuName.Size = new System.Drawing.Size(220, 40);
            this.textBoxuName.TabIndex = 0;
            this.textBoxuName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxuMobile
            // 
            this.textBoxuMobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxuMobile.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxuMobile.Location = new System.Drawing.Point(148, 224);
            this.textBoxuMobile.MaxLength = 19;
            this.textBoxuMobile.Name = "textBoxuMobile";
            this.textBoxuMobile.Size = new System.Drawing.Size(220, 37);
            this.textBoxuMobile.TabIndex = 3;
            this.textBoxuMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxuMobile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxstMobile_KeyPress);
            // 
            // comboBoxJob
            // 
            this.comboBoxJob.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxJob.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxJob.FormattingEnabled = true;
            this.comboBoxJob.Location = new System.Drawing.Point(439, 442);
            this.comboBoxJob.Name = "comboBoxJob";
            this.comboBoxJob.Size = new System.Drawing.Size(180, 38);
            this.comboBoxJob.TabIndex = 8;
            this.comboBoxJob.SelectedIndexChanged += new System.EventHandler(this.comboBoxJob_SelectedIndexChanged);
            this.comboBoxJob.SelectionChangeCommitted += new System.EventHandler(this.comboBoxJob_SelectionChangeCommitted);
            // 
            // comboBoxPermissions
            // 
            this.comboBoxPermissions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPermissions.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxPermissions.FormattingEnabled = true;
            this.comboBoxPermissions.Location = new System.Drawing.Point(439, 496);
            this.comboBoxPermissions.Name = "comboBoxPermissions";
            this.comboBoxPermissions.Size = new System.Drawing.Size(180, 38);
            this.comboBoxPermissions.TabIndex = 10;
            this.comboBoxPermissions.SelectedIndexChanged += new System.EventHandler(this.comboBoxPermissions_SelectedIndexChanged);
            this.comboBoxPermissions.SelectionChangeCommitted += new System.EventHandler(this.comboBoxPermissions_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SandyBrown;
            this.label1.Location = new System.Drawing.Point(32, 493);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 36);
            this.label1.TabIndex = 22;
            this.label1.Text = "الصلاحيات :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxPermissions
            // 
            this.textBoxPermissions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPermissions.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxPermissions.Location = new System.Drawing.Point(148, 491);
            this.textBoxPermissions.Name = "textBoxPermissions";
            this.textBoxPermissions.ReadOnly = true;
            this.textBoxPermissions.Size = new System.Drawing.Size(220, 40);
            this.textBoxPermissions.TabIndex = 25;
            this.textBoxPermissions.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxUsername.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxUsername.Location = new System.Drawing.Point(148, 116);
            this.textBoxUsername.MaxLength = 49;
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(220, 40);
            this.textBoxUsername.TabIndex = 1;
            this.textBoxUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxUsername.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxUsername_Validating);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SandyBrown;
            this.label3.Location = new System.Drawing.Point(32, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 36);
            this.label3.TabIndex = 17;
            this.label3.Text = "المستخدم :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxPassword.Font = new System.Drawing.Font("Cairo", 10F);
            this.textBoxPassword.Location = new System.Drawing.Point(399, 115);
            this.textBoxPassword.MaxLength = 19;
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(220, 32);
            this.textBoxPassword.TabIndex = 4;
            this.textBoxPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxPassword.UseSystemPasswordChar = true;
            this.textBoxPassword.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxPassword_Validating);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SandyBrown;
            this.label8.Location = new System.Drawing.Point(399, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(220, 40);
            this.label8.TabIndex = 15;
            this.label8.Text = "كلمة المرور والتأكيد :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxConfirmPassword
            // 
            this.textBoxConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxConfirmPassword.Font = new System.Drawing.Font("Cairo", 10F);
            this.textBoxConfirmPassword.Location = new System.Drawing.Point(399, 155);
            this.textBoxConfirmPassword.MaxLength = 19;
            this.textBoxConfirmPassword.Name = "textBoxConfirmPassword";
            this.textBoxConfirmPassword.Size = new System.Drawing.Size(220, 32);
            this.textBoxConfirmPassword.TabIndex = 5;
            this.textBoxConfirmPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxConfirmPassword.UseSystemPasswordChar = true;
            this.textBoxConfirmPassword.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxConfirmPassword_Validating);
            // 
            // checkBoxStates
            // 
            this.checkBoxStates.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.checkBoxStates.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBoxStates.Checked = true;
            this.checkBoxStates.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxStates.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.checkBoxStates.ForeColor = System.Drawing.Color.SandyBrown;
            this.checkBoxStates.Location = new System.Drawing.Point(80, 390);
            this.checkBoxStates.Name = "checkBoxStates";
            this.checkBoxStates.Size = new System.Drawing.Size(180, 36);
            this.checkBoxStates.TabIndex = 14;
            this.checkBoxStates.Text = "حالة المستخدم";
            this.checkBoxStates.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxStates.UseVisualStyleBackColor = false;
            // 
            // textBoxDepartments
            // 
            this.textBoxDepartments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxDepartments.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxDepartments.Location = new System.Drawing.Point(148, 383);
            this.textBoxDepartments.Name = "textBoxDepartments";
            this.textBoxDepartments.ReadOnly = true;
            this.textBoxDepartments.Size = new System.Drawing.Size(220, 40);
            this.textBoxDepartments.TabIndex = 23;
            this.textBoxDepartments.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxDepartments
            // 
            this.comboBoxDepartments.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxDepartments.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxDepartments.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDepartments.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxDepartments.FormattingEnabled = true;
            this.comboBoxDepartments.Location = new System.Drawing.Point(439, 388);
            this.comboBoxDepartments.Name = "comboBoxDepartments";
            this.comboBoxDepartments.Size = new System.Drawing.Size(180, 38);
            this.comboBoxDepartments.TabIndex = 6;
            this.comboBoxDepartments.SelectedIndexChanged += new System.EventHandler(this.comboBoxDepartments_SelectedIndexChanged);
            this.comboBoxDepartments.SelectionChangeCommitted += new System.EventHandler(this.comboBoxDepartments_SelectionChangeCommitted);
            this.comboBoxDepartments.SelectedValueChanged += new System.EventHandler(this.comboBoxDepartments_SelectedValueChanged);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SandyBrown;
            this.label7.Location = new System.Drawing.Point(32, 385);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 36);
            this.label7.TabIndex = 20;
            this.label7.Text = "الأقسام :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Goldenrod;
            this.panel1.Controls.Add(this.linkLabelRemove);
            this.panel1.Controls.Add(this.buttonAddStudent);
            this.panel1.Controls.Add(this.linkLabeluImage);
            this.panel1.Controls.Add(this.uImage);
            this.panel1.Controls.Add(this.checkBoxStates);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(652, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(348, 578);
            this.panel1.TabIndex = 27;
            // 
            // linkLabelRemove
            // 
            this.linkLabelRemove.AutoSize = true;
            this.linkLabelRemove.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold);
            this.linkLabelRemove.LinkColor = System.Drawing.Color.Navy;
            this.linkLabelRemove.Location = new System.Drawing.Point(24, 329);
            this.linkLabelRemove.Name = "linkLabelRemove";
            this.linkLabelRemove.Size = new System.Drawing.Size(51, 36);
            this.linkLabelRemove.TabIndex = 16;
            this.linkLabelRemove.TabStop = true;
            this.linkLabelRemove.Text = "إزالة";
            this.linkLabelRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabelRemove.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.buttonAddStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddStudent.FlatAppearance.BorderSize = 0;
            this.buttonAddStudent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddStudent.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddStudent.ForeColor = System.Drawing.Color.Peru;
            this.buttonAddStudent.Image = global::WFBookManagment.Properties.Resources.Add;
            this.buttonAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddStudent.Location = new System.Drawing.Point(47, 453);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddStudent.Size = new System.Drawing.Size(254, 67);
            this.buttonAddStudent.TabIndex = 13;
            this.buttonAddStudent.Text = "أمين المكتبة";
            this.buttonAddStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddStudent.UseVisualStyleBackColor = false;
            this.buttonAddStudent.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // uImage
            // 
            this.uImage.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.uImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uImage.Image = global::WFBookManagment.Properties.Resources.guy_reader;
            this.uImage.Location = new System.Drawing.Point(24, 59);
            this.uImage.Name = "uImage";
            this.uImage.Size = new System.Drawing.Size(300, 260);
            this.uImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.uImage.TabIndex = 15;
            this.uImage.TabStop = false;
            this.uImage.Click += new System.EventHandler(this.BookCover_Click);
            // 
            // textBoxStdSpecialty
            // 
            this.textBoxStdSpecialty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxStdSpecialty.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxStdSpecialty.Location = new System.Drawing.Point(148, 275);
            this.textBoxStdSpecialty.Name = "textBoxStdSpecialty";
            this.textBoxStdSpecialty.ReadOnly = true;
            this.textBoxStdSpecialty.Size = new System.Drawing.Size(220, 40);
            this.textBoxStdSpecialty.TabIndex = 34;
            // 
            // comboBoxSpecialtyStd
            // 
            this.comboBoxSpecialtyStd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpecialtyStd.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxSpecialtyStd.FormattingEnabled = true;
            this.comboBoxSpecialtyStd.Location = new System.Drawing.Point(439, 280);
            this.comboBoxSpecialtyStd.Name = "comboBoxSpecialtyStd";
            this.comboBoxSpecialtyStd.Size = new System.Drawing.Size(180, 38);
            this.comboBoxSpecialtyStd.TabIndex = 28;
            this.comboBoxSpecialtyStd.SelectedIndexChanged += new System.EventHandler(this.comboBoxSpecialtyStd_SelectedIndexChanged);
            this.comboBoxSpecialtyStd.SelectionChangeCommitted += new System.EventHandler(this.comboBoxSpecialtyStd_SelectionChangeCommitted);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SandyBrown;
            this.label2.Location = new System.Drawing.Point(32, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 36);
            this.label2.TabIndex = 32;
            this.label2.Text = "الدراسة :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxSpecialtyExp
            // 
            this.comboBoxSpecialtyExp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpecialtyExp.Font = new System.Drawing.Font("Cairo", 12F);
            this.comboBoxSpecialtyExp.FormattingEnabled = true;
            this.comboBoxSpecialtyExp.Location = new System.Drawing.Point(439, 334);
            this.comboBoxSpecialtyExp.Name = "comboBoxSpecialtyExp";
            this.comboBoxSpecialtyExp.Size = new System.Drawing.Size(180, 38);
            this.comboBoxSpecialtyExp.TabIndex = 30;
            this.comboBoxSpecialtyExp.SelectedIndexChanged += new System.EventHandler(this.comboBoxSpecialtyExp_SelectedIndexChanged);
            this.comboBoxSpecialtyExp.SelectionChangeCommitted += new System.EventHandler(this.comboBoxSpecialtyExp_SelectionChangeCommitted);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SandyBrown;
            this.label5.Location = new System.Drawing.Point(32, 331);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 36);
            this.label5.TabIndex = 33;
            this.label5.Text = "الخبرة :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxExpSpecialty
            // 
            this.textBoxExpSpecialty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxExpSpecialty.Font = new System.Drawing.Font("Cairo", 13F);
            this.textBoxExpSpecialty.Location = new System.Drawing.Point(148, 329);
            this.textBoxExpSpecialty.Name = "textBoxExpSpecialty";
            this.textBoxExpSpecialty.ReadOnly = true;
            this.textBoxExpSpecialty.Size = new System.Drawing.Size(220, 40);
            this.textBoxExpSpecialty.TabIndex = 35;
            // 
            // numericStdYears
            // 
            this.numericStdYears.Font = new System.Drawing.Font("Simplified Arabic Fixed", 15F);
            this.numericStdYears.Location = new System.Drawing.Point(306, 281);
            this.numericStdYears.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericStdYears.Name = "numericStdYears";
            this.numericStdYears.Size = new System.Drawing.Size(56, 29);
            this.numericStdYears.TabIndex = 36;
            this.numericStdYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericStdYears.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericStdYears.ValueChanged += new System.EventHandler(this.numericStdYears_ValueChanged);
            // 
            // numericExpYears
            // 
            this.numericExpYears.Font = new System.Drawing.Font("Simplified Arabic Fixed", 15F);
            this.numericExpYears.Location = new System.Drawing.Point(306, 335);
            this.numericExpYears.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericExpYears.Name = "numericExpYears";
            this.numericExpYears.Size = new System.Drawing.Size(56, 29);
            this.numericExpYears.TabIndex = 37;
            this.numericExpYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericExpYears.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericExpYears.ValueChanged += new System.EventHandler(this.numericExpYears_ValueChanged);
            // 
            // textBoxSalary
            // 
            this.textBoxSalary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxSalary.Font = new System.Drawing.Font("Simplified Arabic Fixed", 20F);
            this.textBoxSalary.Location = new System.Drawing.Point(399, 228);
            this.textBoxSalary.MaxLength = 19;
            this.textBoxSalary.Name = "textBoxSalary";
            this.textBoxSalary.ReadOnly = true;
            this.textBoxSalary.Size = new System.Drawing.Size(220, 37);
            this.textBoxSalary.TabIndex = 38;
            this.textBoxSalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.SandyBrown;
            this.label9.Location = new System.Drawing.Point(399, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(220, 36);
            this.label9.TabIndex = 39;
            this.label9.Text = "راتب التعيين :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonExit
            // 
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonExit.Image = global::WFBookManagment.Properties.Resources.Close;
            this.buttonExit.Location = new System.Drawing.Point(12, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(30, 30);
            this.buttonExit.TabIndex = 26;
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAddSpecialty
            // 
            this.buttonAddSpecialty.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddSpecialty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSpecialty.FlatAppearance.BorderSize = 0;
            this.buttonAddSpecialty.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSpecialty.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSpecialty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSpecialty.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddSpecialty.ForeColor = System.Drawing.Color.Black;
            this.buttonAddSpecialty.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddSpecialty.Image")));
            this.buttonAddSpecialty.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddSpecialty.Location = new System.Drawing.Point(399, 280);
            this.buttonAddSpecialty.Name = "buttonAddSpecialty";
            this.buttonAddSpecialty.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddSpecialty.Size = new System.Drawing.Size(38, 38);
            this.buttonAddSpecialty.TabIndex = 29;
            this.buttonAddSpecialty.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddSpecialty.UseVisualStyleBackColor = false;
            this.buttonAddSpecialty.Click += new System.EventHandler(this.buttonAddSpecialty_Click);
            // 
            // buttonAddSpecialties
            // 
            this.buttonAddSpecialties.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddSpecialties.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSpecialties.FlatAppearance.BorderSize = 0;
            this.buttonAddSpecialties.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSpecialties.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddSpecialties.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSpecialties.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddSpecialties.ForeColor = System.Drawing.Color.Black;
            this.buttonAddSpecialties.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddSpecialties.Image")));
            this.buttonAddSpecialties.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddSpecialties.Location = new System.Drawing.Point(399, 334);
            this.buttonAddSpecialties.Name = "buttonAddSpecialties";
            this.buttonAddSpecialties.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddSpecialties.Size = new System.Drawing.Size(38, 38);
            this.buttonAddSpecialties.TabIndex = 31;
            this.buttonAddSpecialties.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddSpecialties.UseVisualStyleBackColor = false;
            this.buttonAddSpecialties.Click += new System.EventHandler(this.buttonAddSpecialties_Click);
            // 
            // buttonAddDepartment
            // 
            this.buttonAddDepartment.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddDepartment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddDepartment.FlatAppearance.BorderSize = 0;
            this.buttonAddDepartment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddDepartment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddDepartment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddDepartment.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddDepartment.ForeColor = System.Drawing.Color.Black;
            this.buttonAddDepartment.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddDepartment.Image")));
            this.buttonAddDepartment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddDepartment.Location = new System.Drawing.Point(399, 388);
            this.buttonAddDepartment.Name = "buttonAddDepartment";
            this.buttonAddDepartment.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddDepartment.Size = new System.Drawing.Size(38, 38);
            this.buttonAddDepartment.TabIndex = 7;
            this.buttonAddDepartment.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddDepartment.UseVisualStyleBackColor = false;
            this.buttonAddDepartment.Click += new System.EventHandler(this.buttonAddDepartment_Click);
            // 
            // buttonAddPersmission
            // 
            this.buttonAddPersmission.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddPersmission.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddPersmission.FlatAppearance.BorderSize = 0;
            this.buttonAddPersmission.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddPersmission.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddPersmission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddPersmission.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddPersmission.ForeColor = System.Drawing.Color.Black;
            this.buttonAddPersmission.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddPersmission.Image")));
            this.buttonAddPersmission.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddPersmission.Location = new System.Drawing.Point(399, 496);
            this.buttonAddPersmission.Name = "buttonAddPersmission";
            this.buttonAddPersmission.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddPersmission.Size = new System.Drawing.Size(38, 38);
            this.buttonAddPersmission.TabIndex = 11;
            this.buttonAddPersmission.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddPersmission.UseVisualStyleBackColor = false;
            this.buttonAddPersmission.Click += new System.EventHandler(this.buttonAddPersmission_Click);
            // 
            // buttonAddJobs
            // 
            this.buttonAddJobs.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonAddJobs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddJobs.FlatAppearance.BorderSize = 0;
            this.buttonAddJobs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Bisque;
            this.buttonAddJobs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Bisque;
            this.buttonAddJobs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddJobs.Font = new System.Drawing.Font("Cairo", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddJobs.ForeColor = System.Drawing.Color.Black;
            this.buttonAddJobs.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddJobs.Image")));
            this.buttonAddJobs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddJobs.Location = new System.Drawing.Point(399, 442);
            this.buttonAddJobs.Name = "buttonAddJobs";
            this.buttonAddJobs.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.buttonAddJobs.Size = new System.Drawing.Size(38, 38);
            this.buttonAddJobs.TabIndex = 9;
            this.buttonAddJobs.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonAddJobs.UseVisualStyleBackColor = false;
            this.buttonAddJobs.Click += new System.EventHandler(this.buttonAddSchool_Click);
            // 
            // formAddUsers
            // 
            this.AcceptButton = this.buttonAddStudent;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.CancelButton = this.buttonExit;
            this.ClientSize = new System.Drawing.Size(1000, 578);
            this.Controls.Add(this.textBoxSalary);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.numericExpYears);
            this.Controls.Add(this.numericStdYears);
            this.Controls.Add(this.textBoxStdSpecialty);
            this.Controls.Add(this.buttonAddSpecialty);
            this.Controls.Add(this.comboBoxSpecialtyStd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonAddSpecialties);
            this.Controls.Add(this.comboBoxSpecialtyExp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxExpSpecialty);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxDepartments);
            this.Controls.Add(this.buttonAddDepartment);
            this.Controls.Add(this.comboBoxDepartments);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxConfirmPassword);
            this.Controls.Add(this.textBoxPassword);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxUsername);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxPermissions);
            this.Controls.Add(this.buttonAddPersmission);
            this.Controls.Add(this.comboBoxPermissions);
            this.Controls.Add(this.buttonAddJobs);
            this.Controls.Add(this.comboBoxJob);
            this.Controls.Add(this.textBoxuMobile);
            this.Controls.Add(this.textBoxuName);
            this.Controls.Add(this.textBoxstEmail);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelSchool);
            this.Controls.Add(this.textBoxJobs);
            this.Font = new System.Drawing.Font("Cairo", 14.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(120, 180);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "formAddUsers";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "الأمناء";
            this.Activated += new System.EventHandler(this.formAddUsers_Activated);
            this.Load += new System.EventHandler(this.formAddUsers_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericStdYears)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericExpYears)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        public System.Windows.Forms.Button buttonAddStudent;
        public System.Windows.Forms.TextBox textBoxJobs;
        public System.Windows.Forms.Label labelSchool;
        public System.Windows.Forms.Label labelName;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.PictureBox uImage;
        public System.Windows.Forms.LinkLabel linkLabeluImage;
        public System.Windows.Forms.TextBox textBoxstEmail;
        public System.Windows.Forms.TextBox textBoxuName;
        public System.Windows.Forms.TextBox textBoxuMobile;
        public System.Windows.Forms.Button buttonAddJobs;
        public System.Windows.Forms.ComboBox comboBoxJob;
        public System.Windows.Forms.TextBox textBoxUsername;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox textBoxPermissions;
        public System.Windows.Forms.Button buttonAddPersmission;
        public System.Windows.Forms.ComboBox comboBoxPermissions;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBoxConfirmPassword;
        public System.Windows.Forms.TextBox textBoxPassword;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox textBoxDepartments;
        public System.Windows.Forms.Button buttonAddDepartment;
        public System.Windows.Forms.ComboBox comboBoxDepartments;
        public System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.CheckBox checkBoxStates;
        public System.Windows.Forms.TextBox textBoxStdSpecialty;
        public System.Windows.Forms.Button buttonAddSpecialty;
        public System.Windows.Forms.ComboBox comboBoxSpecialtyStd;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button buttonAddSpecialties;
        public System.Windows.Forms.ComboBox comboBoxSpecialtyExp;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox textBoxExpSpecialty;
        public System.Windows.Forms.NumericUpDown numericStdYears;
        public System.Windows.Forms.NumericUpDown numericExpYears;
        public System.Windows.Forms.TextBox textBoxSalary;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.LinkLabel linkLabelRemove;
    }
}