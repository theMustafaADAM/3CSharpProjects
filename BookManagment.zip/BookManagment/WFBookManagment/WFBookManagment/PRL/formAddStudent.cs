﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using WFBookManagment.BLL;
using WFBookManagment.DAL;
using static System.Globalization.CultureInfo;


namespace WFBookManagment.PRL
{
    public partial class formAddStudent : Form
    {
        public formAddStudent(int ID, bool Stt)
        {
            if (ID == 0)
            {
                InitializeComponent();
                _FillComboWithSchools();
                _ID = ID;
                _Delstate = Stt;
            }
            else
            {
                InitializeComponent();
                _FillComboWithSchools();
                _ID = ID;
                _Delstate = Stt;

                if (_Delstate)
                {
                    comboBoxSchools.Enabled = buttonAddSchool.Enabled = textBoxstEmail.Enabled =
                        linkLabelCover.Enabled = stImage.Enabled = false;
                    comboBoxSchools.Text = string.Empty;
                }
            }
        }
        public formAddStudent()
        {
            InitializeComponent();
            _FillComboWithSchools();
        }

        private void _FillComboWithSchools()
        {
            comboBoxSchools.DataSource = clsStudent.LoadSchools();
            comboBoxSchools.DisplayMember = "scName";
            comboBoxSchools.ValueMember = "scID";

        }

        private bool _Delstate;
        private int _ID;
        MemoryStream stream;
        byte[] byteImg;
        clsStudents clsStudent = new clsStudents();

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (textBoxstAddress.Text == string.Empty || textBoxstName.Text == string.Empty
                || textBoxstMobile.Text == string.Empty || textBoxstEmail.Text == string.Empty)
            {
                formDialogMissInfo missInfo = new formDialogMissInfo();
                missInfo.ShowDialog();
                return;
            }
            // INSERT With Image
            if (_ID == 0 && stImage.Image != null)
            {
                stream = new MemoryStream();
                stImage.Image.Save(stream, stImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsStudent = new clsStudents();
                clsStudent.stName = textBoxstName.Text;
                clsStudent.stMobile = textBoxstMobile.Text;
                clsStudent.stAddress = textBoxstAddress.Text;
                clsStudent.stEmail = textBoxstEmail.Text;
                clsStudent.stSchool = comboBoxSchools.Text;
                clsStudent.stImage = byteImg;
                clsStudent.Insert(clsStudent, "Full");
                formDialogOK done = new formDialogOK("حُفظ الطالب");
                done.ShowDialog();
                this.Close();
            }
            // Inset With No Image
            else if (_ID == 0 && stImage.Image == null)
            {
                byteImg = new byte[0];

                clsStudent = new clsStudents();
                clsStudent.stName = textBoxstName.Text;
                clsStudent.stMobile = textBoxstMobile.Text;
                clsStudent.stAddress = textBoxstAddress.Text;
                clsStudent.stEmail = textBoxstEmail.Text;
                clsStudent.stSchool = comboBoxSchools.Text;
                clsStudent.stImage = byteImg;
                clsStudent.Insert(clsStudent, "NoImg");
                formDialogOK done = new formDialogOK("حُفظ الطالب بلا صورة");
                done.ShowDialog();
                this.Close();
            }
            // UPDATE Full
            else if ((_ID != 0 && !_Delstate) && stImage.Image != null)
            {
                stream = new MemoryStream();
                stImage.Image.Save(stream, stImage.Image.RawFormat);
                byteImg = stream.ToArray();

                clsStudent = new clsStudents();
                clsStudent.stName = textBoxstName.Text;
                clsStudent.stMobile = textBoxstMobile.Text;
                clsStudent.stAddress = textBoxstAddress.Text;
                clsStudent.stEmail = textBoxstEmail.Text;
                clsStudent.stSchool = comboBoxSchools.Text;
                clsStudent.stImage = byteImg;
                clsStudent.stID = _ID;
                clsStudent.Update(clsStudent, "Full");
                formDialogOK done = new formDialogOK("عُدل الطالب");
                done.ShowDialog();
                this.Close();
            }
            // Update No Image
            else if ((_ID != 0 && !_Delstate) && stImage.Image == null)
            {
                byteImg = new byte[0];

                clsStudent = new clsStudents();
                clsStudent.stName = textBoxstName.Text;
                clsStudent.stMobile = textBoxstMobile.Text;
                clsStudent.stAddress = textBoxstAddress.Text;
                clsStudent.stEmail = textBoxstEmail.Text;
                clsStudent.stSchool = comboBoxSchools.Text;
                clsStudent.stImage = byteImg;
                clsStudent.stID = _ID;
                clsStudent.Update(clsStudent, "NoImg");
                formDialogOK done = new formDialogOK("عُدل الطالب بلا صورة");
                done.ShowDialog();
                this.Close();
            }
            // DELETE
            else if (_ID != 0 && _Delstate)
            {
                formDialogYESNO dialog = new formDialogYESNO($"تأكيد حذف الطالب {textBoxstName.Text} ؟");
                dialog.DataBack += Dialog_DataBack;
                dialog.ShowDialog();

                if (_ConfirmDelete)
                {
                    clsStudent.Delete(_ID);
                    formDialogOK done = new formDialogOK();
                    done.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                formDialogNotAllowed frm = new formDialogNotAllowed();
                frm.ShowDialog();
                this.Close();
                return;
            }
        }

        bool _ConfirmDelete;

        private void Dialog_DataBack(object sender, bool Answer)
        {
            _ConfirmDelete = Answer;
        }

        private void BookCover_Click(object sender, EventArgs e)
        {
            linkLabel1_LinkClicked(null, null);
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)
                && e.KeyChar != Convert.ToChar(CurrentCulture.NumberFormat.NumberDecimalSeparator);
        }

        private void buttonAddAuth_Click(object sender, EventArgs e)
        {
            formAddCategory addAuthor = new formAddCategory(-5, false);
            addAuthor.labelTitle.Text = "اسم المؤلف";
            addAuthor.buttonAddCategory.Text = "مؤلف";
            addAuthor.ShowDialog();
        }

        private void formAddBook_Activated(object sender, EventArgs e)
        {
            if (_ID == 0)
            {
                _FillComboWithSchools();
            }
            else return;
        }

        private void buttonAddCateg_Click(object sender, EventArgs e)
        {
            formAddCategory addcateg = new formAddCategory();
            addcateg.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "ملفات الصور | *.JPG; *.PNG; *.GIF; *.PMB;";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                stImage.Image = Image.FromFile(dialog.FileName);
            }
        }

        private void buttonAddSchool_Click(object sender, EventArgs e)
        {
            formAddCategory addSchool = new formAddCategory(-9, false);
            addSchool.labelTitle.Text = "اسم المدرسة :";
            addSchool.buttonAddCategory.Text = "مدرسة";
            addSchool.ShowDialog();
        }

        private void textBoxstMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void textBoxstEmail_Validated(object sender, EventArgs e)
        {
            if (!clsDataAccess.EmailCheck(textBoxstEmail.Text.Trim()))
            {
                errorProvider1.SetError(textBoxstEmail, "صيغة بريد الكتروني خاطئة!!");
                // txtEmail.Focus();
                textBoxstEmail.SelectionStart = 0;
                textBoxstEmail.SelectionLength = textBoxstEmail.TextLength;
            }
            else
            {
                errorProvider1.SetError(textBoxstEmail, null);
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            stImage.Image = null;
        }
    }
}
