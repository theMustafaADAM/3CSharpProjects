﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms.VisualStyles;

namespace WFBookManagment.BLL
{
    public class clsUsers
    {

        public int uID { get; set; }
        public string uName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string uPermissions { get; set; }
        public bool uStates { get; set; }
        public byte[] uImage { get; set; }
        public string uJob { get; set; }
        public string uDepartment { get; set; }
        public string uMobile { get; set; }
        public string uEmail { get; set; }
        public string SpecialtySTD { get; set; }
        public string SpecialtyEXP { get; set; }
        public int STDYears { get; set; }
        public int EXPYears { get; set; }
        public decimal HireSalary { get; set; }

        public clsUsers(int uID, string uName, string username, string password, 
            string uPermissions, bool uStates, byte[] image, string job, 
            string department, string mobile, string email,
            int stdyears, int expyears, string stdspc, string expspc, decimal hireSalary)
        {
            this.uID = uID;
            this.uName = uName;
            Username = username;
            Password = password;
            this.uPermissions = uPermissions;
            this.uStates = uStates;
            this.uImage = image;
            this.uJob = job;
            this.uDepartment = department;
            this.uMobile = mobile;
            this.uEmail = email;
            this.STDYears = stdyears;
            this.EXPYears = expyears;
            this.SpecialtySTD = stdspc;
            this.SpecialtyEXP = expspc;
            this.HireSalary = hireSalary;
        }  
        
        public clsUsers()
        {
            this.uID = -1;
            this.uName = string.Empty;
            Username = string.Empty;
            Password = string.Empty;
            this.uPermissions = string.Empty;
            this.uStates = false;
            this.uImage = null;
            this.uJob = string.Empty;
            this.uDepartment = string.Empty;
            this.uMobile = string.Empty;
            this.uEmail = string.Empty;
            this.STDYears = 0;
            this.EXPYears = 0;
            this.SpecialtySTD = string.Empty;
            this.SpecialtyEXP = string.Empty;
            this.HireSalary = 0;
        }

        public DataTable LoadUsers()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetUsers", pr);

            return table;
        }

        public DataTable StartLibrarySystem()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_StartLibrarySystem", pr);

            return table;
        }

        public static DataTable LoadDepartments()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetDepartments", pr);

            return table;
        }

        public DataTable LoadJobsByDepartmentID(int depID)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("depID", depID);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetJobsByDepartmentID", pr);

            return table;
        }

        public static DataTable FindData(string user)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("user", user);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindConcatUserInfo", pr);

            return table;
        }

        public Boolean Insert(clsUsers user, string nullState)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[16];

                pr[0] = new SqlParameter("uName", user.uName);
                pr[1] = new SqlParameter("Username", user.Username);
                pr[2] = new SqlParameter("Password", user.Password );
                pr[3] = new SqlParameter("uPermissions", user.uPermissions);
                pr[4] = new SqlParameter("uStates", user.uStates);
                pr[5] = new SqlParameter("uImage", user.uImage);
                pr[6] = new SqlParameter("uJob", user.uJob);
                pr[7] = new SqlParameter("uDepartment", user.uDepartment);
                pr[8] = new SqlParameter("uMobile", user.uMobile);
                pr[9] = new SqlParameter("uEmail", user.uEmail);
                pr[10] = new SqlParameter("STDYears", user.STDYears);
                pr[11] = new SqlParameter("SpecialtySTD", user.SpecialtySTD);
                pr[12] = new SqlParameter("EXPYears", user.EXPYears);
                pr[13] = new SqlParameter("SpecialtyEXP", user.SpecialtyEXP);
                pr[14] = new SqlParameter("HireSalary", user.HireSalary);
                pr[15] = new SqlParameter("nState", nullState);

                if (clsDataAccess.ExecuteNonQuery("Pr_Add_User", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Update(clsUsers user, string nullState)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[17];

                pr[0] = new SqlParameter("uName", user.uName);
                pr[1] = new SqlParameter("Username", user.Username);
                pr[2] = new SqlParameter("Password", user.Password);
                pr[3] = new SqlParameter("uPermissions", user.uPermissions);
                pr[4] = new SqlParameter("uStates", user.uStates);
                pr[5] = new SqlParameter("uImage", user.uImage);
                pr[6] = new SqlParameter("uJob", user.uJob);
                pr[7] = new SqlParameter("uDepartment", user.uDepartment);
                pr[8] = new SqlParameter("uMobile", user.uMobile);
                pr[9] = new SqlParameter("uEmail", user.uEmail);
                pr[10] = new SqlParameter("uID", user.uID);
                pr[11] = new SqlParameter("STDYears", user.STDYears);
                pr[12] = new SqlParameter("SpecialtySTD", user.SpecialtySTD);
                pr[13] = new SqlParameter("EXPYears", user.EXPYears);
                pr[14] = new SqlParameter("SpecialtyEXP", user.SpecialtyEXP);
                pr[15] = new SqlParameter("HireSalary", user.HireSalary);
                pr[16] = new SqlParameter("nState", nullState);

                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateUser", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Delete(int uID)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("uID", uID);

                if (clsDataAccess.ExecuteNonQuery("Pr_DeleteUser", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean LogOut()
        {
            bool Done = false;
            try
            {
                SqlParameter[] pr = null;
                if (clsDataAccess.ExecuteNonQuery("Pr_LogOut", pr)) Done = true;
            }
            catch { Done = false; }
            return Done;
        }

        public Boolean UpdateLogInState(string username, string password)
        {
            bool Done = false;
            try
            {
                SqlParameter[] pr = new SqlParameter[2];
                pr[0] = new SqlParameter("Username", username);
                pr[1] = new SqlParameter("Password", password);
                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateLogInState", pr)) Done = true;
            }
            catch { Done = false; }
            return Done;
        }

        public DataTable LogIn(string username, string password)
        {
            SqlParameter[] pr = new SqlParameter[2];
            pr[0] = new SqlParameter("Username", username);
            pr[1] = new SqlParameter("Password", password);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_LogIn", pr);

            return table;
        }

        public static DataTable LoadPermissions()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetPermissions", pr);

            return table;
        }

        public static DataTable LoadSpecialties()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetSpecialties", pr);

            return table;
        }

        public Boolean InsertPermission(string name)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("name", name);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddPermission", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean InsertSpecialty(string name)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("name", name);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddSpecialty", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
