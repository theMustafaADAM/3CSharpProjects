﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using  System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;

namespace WFBookManagment.BLL
{
    public class clsCategories
    {
        clsDataAccess dataAccess = new clsDataAccess();

        public string Category { get; set; } = string.Empty;
        public int ID { get; set; } = -1;

        public clsCategories()
        {
            Category = string.Empty;
            ID = -1;
        }

        public clsCategories(string category, int id)
        {
            Category = category;
            ID = id;
        }

        public DataTable LoadData()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetCategories", pr);

            return table;
        }

        public static DataTable FindData(string category)
        {
            SqlParameter[] pr = new  SqlParameter[1];
            pr[0] = new SqlParameter("category", category);


            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindCategory", pr);

            return table;
        }

        public static clsCategories Find(int categID)
        {
            string category = string.Empty;

            if (clsCategoriesData.GetCategoryByID(categID, ref category))
            
                return new clsCategories(category, categID);
            
            else
            
                return null;
        }

        public Boolean Insert(string category)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("category", category);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddCategory", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Update(int id, string category)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[2];

                pr[0] = new SqlParameter("id", id);
                pr[1] = new SqlParameter("category", category);

                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateCategory", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Delete(int id)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("id", id);

                if (clsDataAccess.ExecuteNonQuery("Pr_DeleteCategory", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
