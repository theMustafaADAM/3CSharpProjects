﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;
using static WFBookManagment.DAL.clsDepartmentData;

namespace WFBookManagment.BLL
{
    public class clsDepartments
    {
        public int depID { get; set; }
        public string depName { get; set; }

        public clsDepartments()
        {
            depID = -1;
            depName = string.Empty;
        }

        public clsDepartments(int depID, string depName)
        {
            this.depID = depID;
            this.depName = depName;
        }

        public static clsDepartments Find(int depid)
        {
            string depname = string.Empty;

            if (GetDepartmentByID(depid, ref depname))
                return new clsDepartments(depid, depname);
            else
                return null;
        }

        public static clsDepartments Find(string depname)
        {
            int depid = -1;

            if (GetDepartmentByName(ref depid, depname))
                return new clsDepartments(depid, depname);
            else
                return null;
        }

        public Boolean Insert(string name)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("name", name);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddDepartment", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
