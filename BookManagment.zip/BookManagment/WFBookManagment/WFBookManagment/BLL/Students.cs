﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;
using System.Xml.Linq;

namespace WFBookManagment.BLL
{
    public class clsStudents
    {
        public int stID { get; set; }
        public string stName { get; set; }
        public string stAddress { get; set; }
        public string stMobile { get; set; }
        public string stEmail { get; set; }
        public string stSchool { get; set; }
        public byte[] stImage { get; set; }

        public clsStudents()
        {
            stID = -1;
            stName = string.Empty;
            stAddress = string.Empty;
            stMobile = string.Empty;
            stEmail = string.Empty;
            stSchool = string.Empty;
            stImage = null;
        }

        public clsStudents(int stID, string stName, string stAddress, string stMobile, string stEmail, string stSchool, byte[] stImage)
        {
            this.stID = stID;
            this.stName = stName;
            this.stAddress = stAddress;
            this.stMobile = stMobile;
            this.stEmail = stEmail;
            this.stSchool = stSchool;
            this.stImage = stImage;
        }

        public DataTable LoadStudents()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            /*string textQuery = @"SELECT TbStudents TbStudents.stName as 'اسم الطالب', 
                TbStudents.stMobile as 'جواله', TbStudents.stEmail as 'الايميل', 
                TbStudents.stAddress as 'عنوانه', TbStudents.stSchool as 'الكلية', 
                TbStudents.stImage as 'الصورة' From TbStudents";*/


            table = clsDataAccess.ReadData("Pr_GetStudents", pr);

            return table;
        }

        public static DataTable FindStudent(string stinfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("info", stinfo);

            /*string textQuery = @"SELECT TbStudents.stID as 'ت', TbStudents.stName as 'اسم الطالب', 
             * TbStudents.stMobile as 'جواله', TbStudents.stEmail as 'الايميل', 
             * TbStudents.stAddress as 'عنوانه', TbStudents.stSchool as 'الكلية', 
             * TbStudents.stImage as 'الصورة' From TbStudents WHERE 
             * CONCAT(stID, stName, stAddress, stMobile, stEmail, stSchool) 
             * LIKE '%' + @info + '%';";*/

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindStudentInfo", pr);

            return table;
        }

        public Boolean Insert(clsStudents student, string state)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[7];

                pr[0] = new SqlParameter("stName", student.stName);
                pr[1] = new SqlParameter("stAddress", student.stAddress);
                pr[2] = new SqlParameter("stMobile", student.stMobile);
                pr[3] = new SqlParameter("stEmail", student.stEmail);
                pr[4] = new SqlParameter("stSchool", student.stSchool);
                pr[5] = new SqlParameter("stImage", student.stImage);
                pr[6] = new SqlParameter("state", state);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddStudent", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Update(clsStudents student, string state)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[8];

                pr[0] = new SqlParameter("stName", student.stName);
                pr[1] = new SqlParameter("stAddress", student.stAddress);
                pr[2] = new SqlParameter("stMobile", student.stMobile);
                pr[3] = new SqlParameter("stEmail", student.stEmail);
                pr[4] = new SqlParameter("stSchool", student.stSchool);
                pr[5] = new SqlParameter("stImage", student.stImage);
                pr[6] = new SqlParameter("stID", student.stID);
                pr[7] = new SqlParameter("state", state);

                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateStudent", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Delete(int sID)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("stID", sID);

                if (clsDataAccess.ExecuteNonQuery("Pr_DeleteStudent", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean InsertSchool(string name)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("name", name);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddSchool", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public DataTable LoadSchools()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetSchools", pr);

            return table;
        }
    }
}
