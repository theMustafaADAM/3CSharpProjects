﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;

namespace WFBookManagment.BLL
{
    public class clsBorrow
    {
        public int borrowID { get; internal set; }
        public string borrowDate { get; internal set; }
        public string borrowMan { get; internal set; }
        public string CustomerName { get; internal set; }
        public string CustomerMobile { get; internal set; }
        public string EndBorrowDate { get; internal set; }
        public string CustomerEmail { get; internal set; }
        public short borrowDays { get; internal set; }
        public decimal borrowPrice { get; internal set; }
        public decimal TotalAmount { get; internal set; }
        public bool IsReturned { get; internal set; }

        public clsBorrow()
        {
            this.borrowID = -1;
            this.borrowDate = string.Empty;
            this.borrowMan = string.Empty;
            CustomerName = string.Empty;
            CustomerMobile = string.Empty;
            CustomerEmail = string.Empty;
            EndBorrowDate = string.Empty;
            this.borrowDays = 0;
            this.borrowPrice = 0;
            this.TotalAmount = 0;
            this.IsReturned = false;
        }

        public clsBorrow(int borrowID, string borrowDate, string borrowMan, 
            string customerName, string customerMobile, string endBorrowDate, 
            string customerEmail, short borrowDays, 
            decimal borrowPrice, decimal totalAmount, bool IsReturned)
        {
            this.borrowID = borrowID;
            this.borrowDate = borrowDate;
            this.borrowMan = borrowMan;
            CustomerName = customerName;
            CustomerMobile = customerMobile;
            EndBorrowDate = endBorrowDate;
            CustomerEmail = customerEmail;
            this.borrowDays = borrowDays;
            this.borrowPrice = borrowPrice;
            this.TotalAmount = totalAmount;
            this.IsReturned = IsReturned;
        }

        public DataTable GetLastBorrowID()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetLastBorrowID", pr);

            return table;
        }

        public Boolean Insert(clsBorrow clBorrow)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[11];

                pr[0] = new SqlParameter("borrowID",        clBorrow.borrowID);
                pr[1] = new SqlParameter("borrowDate",      clBorrow.borrowDate);
                pr[2] = new SqlParameter("borrowMan",       clBorrow.borrowMan);
                pr[3] = new SqlParameter("borrowDays",      clBorrow.borrowDays);
                pr[4] = new SqlParameter("CustomerName",    clBorrow.CustomerName);
                pr[5] = new SqlParameter("CustomerMobile",  clBorrow.CustomerMobile);
                pr[6] = new SqlParameter("CustomerEmail",   clBorrow.CustomerEmail);
                pr[7] = new SqlParameter("EndBorrowDate",   clBorrow.EndBorrowDate);
                pr[8] = new SqlParameter("borrowPrice",     clBorrow.borrowPrice);
                pr[9] = new SqlParameter("TotalAmount",     clBorrow.TotalAmount);
                pr[10] = new SqlParameter("IsReturned",      clBorrow.IsReturned);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddBorrow", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Update(clsBorrow clBorrow)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[11];

                pr[0] = new SqlParameter("borrowID", clBorrow.borrowID);
                pr[1] = new SqlParameter("borrowDate", clBorrow.borrowDate);
                pr[2] = new SqlParameter("borrowMan", clBorrow.borrowMan);
                pr[3] = new SqlParameter("borrowDays", clBorrow.borrowDays);
                pr[4] = new SqlParameter("CustomerName", clBorrow.CustomerName);
                pr[5] = new SqlParameter("CustomerMobile", clBorrow.CustomerMobile);
                pr[6] = new SqlParameter("CustomerEmail", clBorrow.CustomerEmail);
                pr[7] = new SqlParameter("EndBorrowDate", clBorrow.EndBorrowDate);
                pr[8] = new SqlParameter("borrowPrice", clBorrow.borrowPrice);
                pr[9] = new SqlParameter("IsReturned", clBorrow.IsReturned);
                pr[10] = new SqlParameter("TotalAmount", clBorrow.TotalAmount);

                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateBorrowRecord", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Returned(clsBorrow clBorrow)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("borrowID", clBorrow.borrowID);

                if (clsDataAccess.ExecuteNonQuery("Pr_ReturnedBorrow", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public DataTable GetBorrows()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetBorrows", pr);

            return table;
        }

        public static DataTable FindBorrow(string binfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("binfo", binfo);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindBorrowInfo", pr);

            return table;
        }

        public static DataTable FindConcatBorrow(string binfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("binfo", binfo);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindConcatBorrowInfo", pr);

            return table;
        }
    }
}
