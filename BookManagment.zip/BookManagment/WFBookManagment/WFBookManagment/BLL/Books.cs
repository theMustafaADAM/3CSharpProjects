﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;
using System.IO;

namespace WFBookManagment.BLL
{
    public class clsBooks
    {
        public int bookID { get; set; }
        public string bookTitle { get; set; }

        public int AuthID { get; set; }
        public string AuthName { get; set; }

        public int bookCategID { get; set; }
        public string bookCategName { get; set; }
        public clsCategories CategoriesInfo;

        public int bookQty { get; set; }

        public decimal bookPrice { get; set; }
        public byte[] bookCover {  get; set; }

        public string PublishDate { get; set; } 
        public int bookRate { get; set; }

        public clsBooks()
        {
            bookID = -1;
            bookTitle = string.Empty;
            AuthID = -1;
            AuthName = string.Empty;
            bookCategID = -1;
            bookCategName = string.Empty;
            bookQty = 0;
            bookPrice = 0;
            bookCover = null;
            PublishDate = string.Empty;
            bookRate = 0;
        }

        public clsBooks(int bookID, string bookTitle, int authID, string authName, 
            int bookCategID, string bookCategName, int bookQty, decimal bookPrice, 
            byte[] bookCover, string publishDate, int bookRate)
        {
            this.bookID = bookID;
            this.bookTitle = bookTitle;
            AuthID = authID;
            AuthName = authName;
            this.bookCategID = bookCategID;
            this.bookCategName = bookCategName;
            this.CategoriesInfo = clsCategories.Find(this.bookCategID);
            this.bookQty = bookQty;
            this.bookPrice = bookPrice;
            this.bookCover = bookCover;
            this.PublishDate = publishDate;
            this.bookRate = bookRate;
        }

        public DataTable LoadAuthors()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetAuthors", pr);

            return table;
        }

        public DataTable GetAuthorByBookID(int ID)
        {
            SqlParameter[] pr = new  SqlParameter[1];
            pr[0] = new SqlParameter("bID", ID);


            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetAuthorByBookID", pr);

            return table;
        }

        public DataTable GetCategoryByBookID(int ID)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("bID", ID);


            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetCategoryByBookID", pr);

            return table;
        }

        public DataTable LoadFullBooks()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            /*string query = @" SELECT TbBooks.bookID as 'ت', TbBooks.bookTitle as 'عنوان الكتاب', 
            TbBooks.AuthName as 'اسم المؤلف', TbBooks.bookCategName as 'الفئة', TbBooks.bookCover as 'غلاف الكتاب', 
            TbBooks.bookPrice as 'السعر', TbBooks.PublishDate as 'النشر', TbBooks.bookRate as 'التقييم'
	        From TbBooks	Inner Join TbAuthors	On TbBooks.AuthID = TbAuthors.AuthID 
					        Inner Join TbCategories On TbBooks.bookCategID = TbCategories.Id";*/

            table = clsDataAccess.ReadData("Pr_GetFullBooks", pr);

            return table;
        }

        public DataTable LoadBooksInfoOnly()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetBooksInfoOnly", pr);

            return table;
        }

        public static DataTable FindBook(string bookinfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("info", bookinfo);

           /* string txtProc = @"SELECT TbBooks.bookID as 'ت', TbBooks.bookTitle as 'عنوان الكتاب', TbBooks.AuthName as 'اسم المؤلف',
	            TbBooks.bookCategName as 'الفئة', TbBooks.bookCover as 'غلاف الكتاب', TbBooks.bookPrice as 'السعر',
	            TbBooks.PublishDate as 'النشر', TbBooks.bookRate as 'التقييم'
	            From TbBooks	Inner Join TbAuthors	On TbBooks.AuthID = TbAuthors.AuthID 
					Inner Join TbCategories On TbBooks.bookCategID = TbCategories.Id
	            WHERE TbBooks.bookTitle + TbBooks.AuthName + TbBooks.bookCategName + TbBooks.PublishDate +
	                Convert(nvarchar, TbBooks.bookPrice) + Convert(nvarchar, TbBooks.bookRate) LIKE '%' + @info + '%';";*/

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindBooksInfo", pr);

            return table;
        }

        public DataTable SearchFullBookByBookID(int bID)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("bID", bID);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_SearchFullBook", pr);

            return table;
        }

        public Boolean Insert(clsBooks book)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[10];

                pr[0] = new SqlParameter("bookTitle", book.bookTitle);
                pr[1] = new SqlParameter("AuthID", book.AuthID);
                pr[2] = new SqlParameter("AuthName", book.AuthName);
                pr[3] = new SqlParameter("bookCategID", book.bookCategID);
                pr[4] = new SqlParameter("bookCategName", book.bookCategName);
                pr[5] = new SqlParameter("bookPrice", book.bookPrice);
                pr[6] = new SqlParameter("PublishDate", book.PublishDate);
                pr[7] = new SqlParameter("bookCover", book.bookCover);
                pr[8] = new SqlParameter("bookRate", book.bookRate);
                pr[9] = new SqlParameter("bookQty", book.bookQty);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddBook", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Update(clsBooks book)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[11];

                pr[0] = new SqlParameter("bookTitle", book.bookTitle);
                pr[1] = new SqlParameter("AuthID", book.AuthID);
                pr[2] = new SqlParameter("AuthName", book.AuthName);
                pr[3] = new SqlParameter("bookCategID", book.bookCategID);
                pr[4] = new SqlParameter("bookCategName", book.bookCategName);
                pr[5] = new SqlParameter("bookPrice", book.bookPrice);
                pr[6] = new SqlParameter("PublishDate", book.PublishDate);
                pr[7] = new SqlParameter("bookCover", book.bookCover);
                pr[8] = new SqlParameter("bookRate", book.bookRate);
                pr[9] = new SqlParameter("bookID", book.bookID);
                pr[10] = new SqlParameter("bookQty", book.bookQty);

                if (clsDataAccess.ExecuteNonQuery("Pr_UpdateBook", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Delete(int id)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];
                pr[0] = new SqlParameter("bookID", id);

                if (clsDataAccess.ExecuteNonQuery("Pr_DeleteBook", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean InsertAuthor(string name)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("name", name);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddAuthor", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
