﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;
using static WFBookManagment.DAL.clsJobData;

namespace WFBookManagment.BLL
{
    public class clsJobs
    {
        public int jobID { get; set; }
        public int depID { get; set; }
        public string jobName { get; set; }
        public clsDepartments departmentInfo { get; set; }

        public clsJobs()
        {
            jobID = -1;
            depID = -1;
            jobName = string.Empty;
        }

        public clsJobs(int jobID,int depid, string jobName)
        {
            this.jobID = jobID;
            this.depID = depid;
            this.jobName = jobName;
            this.departmentInfo = clsDepartments.Find(depID);
        }

        public static clsJobs Find(int jobid)
        {
            string jobname = string.Empty;
            int depID = -1;

            if (GetJobByID(jobid, ref depID , ref jobname))
                return new clsJobs(jobid, depID ,jobname);
            else
                return null;
        }

        public static clsJobs Find(string jobname)
        {
            int jobid = -1;
            int depid = -1;

            if (GetJobByName(ref jobid, ref depid, jobname))
                return new clsJobs(jobid, depid , jobname);
            else
                return null;
        }

        public Boolean Insert(clsJobs job)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[2];

                pr[0] = new SqlParameter("name", job.jobName);
                pr[1] = new SqlParameter("depID", job.depID);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddJob", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
