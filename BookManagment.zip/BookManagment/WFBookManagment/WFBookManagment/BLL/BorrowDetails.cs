﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;

namespace WFBookManagment.BLL
{
    public class clsBorrowDetails
    {
        public int borrowID { get; internal set; }
        public int bookID { get; internal set; }
        public string bookTitle { get; internal set; }
        public decimal borrowPrice { get; internal set; }

        public clsBorrowDetails()
        {
            borrowID = -1;
            bookID = -1;
            bookTitle = string.Empty;
            borrowPrice = 0;
        }

        public clsBorrowDetails(int borrowID, int bookID, string bookTitle, decimal borrowPrice)
        {
            this.borrowID = borrowID;
            this.bookID = bookID;
            this.bookTitle = bookTitle;
            this.borrowPrice = borrowPrice;
        }   

        public Boolean Insert(clsBorrowDetails detail)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[4];

                pr[0] = new SqlParameter("borrowID", detail.borrowID);
                pr[1] = new SqlParameter("bookID", detail.bookID);
                pr[2] = new SqlParameter("bookTitle", detail.bookTitle);
                pr[3] = new SqlParameter("borrowPrice", detail.borrowPrice);

                // to Insert and Update Qty book
                if (clsDataAccess.ExecuteNonQuery("Pr_AddBorrowDetails", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean ReturnBooks(int borrowID, int bookID)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[2];

                pr[0] = new SqlParameter("borrowID", borrowID);
                pr[1] = new SqlParameter("bookID", bookID);

                // to UPDATE Qty & book
                if (clsDataAccess.ExecuteNonQuery("Pr_ReturnBorrowDetails", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public DataTable GetBorrowDetails(int borrowID)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("bID", borrowID);


            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetBorrowDetailsByID", pr);

            return table;
        }

        public Boolean Update(clsBorrowDetails detail)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[4];

                pr[0] = new SqlParameter("borrowID", detail.borrowID);
                pr[1] = new SqlParameter("bookID", detail.bookID);
                pr[2] = new SqlParameter("bookTitle", detail.bookTitle);
                pr[3] = new SqlParameter("borrowPrice", detail.borrowPrice);


                // to delete old data and insert new one
                if (clsDataAccess.ExecuteNonQuery("Pr_DeleteOldAddNewBorrowDetails", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }
    }
}
