﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;

namespace WFBookManagment.BLL
{
    public class clsSaleDetails
    {
        public int saleID { get; set; }
        public int bookID { get; set; }
        public string bookTitle { get; set; }
        public int bookQty { get; set; }
        public decimal bookPrice { get; set; }
        public clsSaleDetails()
        {
            saleID = -1;
            bookID = -1;
            bookTitle = string.Empty;
            bookQty = 0;
            bookPrice = 0;
        }

        public clsSaleDetails(int saleID, int bookID, string bookTitle, int bookQty, decimal bookPrice)
        {
            this.saleID = saleID;
            this.bookID = bookID;
            this.bookTitle = bookTitle;
            this.bookQty = bookQty;
            this.bookPrice = bookPrice;
        }

        public Boolean Insert(clsSaleDetails detail)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[5];

                pr[0] = new SqlParameter("saleID", detail.saleID);
                pr[1] = new SqlParameter("bookID", detail.bookID);
                pr[2] = new SqlParameter("bookTitle", detail.bookTitle);
                pr[3] = new SqlParameter("bookQty", detail.bookQty);
                pr[4] = new SqlParameter("bookPrice", detail.bookPrice);

                // to Insert and Update Qty book
                if (clsDataAccess.ExecuteNonQuery("Pr_AddSaleDetails", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Cancele(int bookID, int bookQty)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[2];

                pr[0] = new SqlParameter("bookID", bookID);
                pr[1] = new SqlParameter("bookQty", bookQty);

                // to Update sale and Qty book
                if (clsDataAccess.ExecuteNonQuery("Pr_CanceleSaleDetails", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public DataTable GetSaleDetails(int saleID)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("sID", saleID);


            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetSaleDetailsByID", pr);

            return table;
        }

    }
}
