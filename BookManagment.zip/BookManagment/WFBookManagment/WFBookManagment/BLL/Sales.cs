﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WFBookManagment.DAL;

namespace WFBookManagment.BLL
{
    public class clsSales
    {
        public int saleID { get; set; }
        public string saleDate { get; set; }
        public string saleMan { get; set; }
        public string CustomerName { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerEmail { get; set; }
        public decimal SaleTotalAmount { get; set; }
        public bool IsCanceled { get; set; }

        public clsSales()
        {
            saleID = -1;
            saleDate = string.Empty;
            saleMan = string.Empty;
            CustomerName = string.Empty;
            CustomerMobile = string.Empty;
            CustomerEmail = string.Empty;
            SaleTotalAmount = 0;
            IsCanceled = false;
        }

        public clsSales(int saleID, string saleDate, string saleMan, 
            string customerName, string customerMobile, string customerEmail, 
            decimal saleTotalAmount, bool iscanceled)
        {
            this.saleID = saleID;
            this.saleDate = saleDate;
            this.saleMan = saleMan;
            CustomerName = customerName;
            CustomerMobile = customerMobile;
            CustomerEmail = customerEmail;
            SaleTotalAmount = saleTotalAmount;
            IsCanceled = iscanceled;
        }   

        public DataTable GetLastSaleID()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetLastSaleID", pr);

            return table;
        }

        public DataTable GetLastSaleSCOPEIDENTITY()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetLastSaleSCOPE_IDENTITY", pr);

            return table;
        }

        public DataTable GetSales()
        {
            SqlParameter[] pr = null;

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_GetSales", pr);

            return table;
        }        

        public Boolean Insert(clsSales sale)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[8];
                
                pr[0] = new SqlParameter("saleID", sale.saleID);
                pr[1] = new SqlParameter("saleDate", sale.saleDate);
                pr[2] = new SqlParameter("saleUser", sale.saleMan);
                pr[3] = new SqlParameter("SaleTotalAmount", sale.SaleTotalAmount);
                pr[4] = new SqlParameter("CustomerName", sale.CustomerName);
                pr[5] = new SqlParameter("CustomerMobile", sale.CustomerMobile);
                pr[6] = new SqlParameter("CustomerEmail", sale.CustomerEmail);
                pr[7] = new SqlParameter("IsCanceled", sale.IsCanceled);

                if (clsDataAccess.ExecuteNonQuery("Pr_AddSale", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public Boolean Cancele(int saleID)
        {
            bool Done = false;

            try
            {
                SqlParameter[] pr = new SqlParameter[1];

                pr[0] = new SqlParameter("sID", saleID);

                if (clsDataAccess.ExecuteNonQuery("Pr_CanceleSale", pr)) Done = true;
            }
            catch
            {
                Done = false;
            }

            return Done;
        }

        public static DataTable FindSale(string sinfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("sinfo", sinfo);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindSaleInfo", pr);

            return table;
        }

        public static DataTable FindConcatSale(string sinfo)
        {
            SqlParameter[] pr = new SqlParameter[1];
            pr[0] = new SqlParameter("sinfo", sinfo);

            DataTable table = new DataTable();

            table = clsDataAccess.ReadData("Pr_FindConcatSaleInfo", pr);

            return table;
        }
    }
}
